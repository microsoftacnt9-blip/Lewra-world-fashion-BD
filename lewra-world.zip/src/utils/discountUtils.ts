import { Product, Coupon, AboutInfo, Order } from '../types';

/**
 * Checks if a product's promotional discount is active and not expired
 */
export function isProductDiscountActive(product: Product): boolean {
  const hasDiscount = Boolean(
    (product.discountPercent && product.discountPercent > 0) ||
    (product.originalPrice && product.originalPrice > product.price)
  );

  if (!hasDiscount) return false;

  if (!product.discountValidUntil) {
    // If no expiration date set, discount is always active
    return true;
  }

  const expiryTime = new Date(product.discountValidUntil).getTime();
  if (isNaN(expiryTime)) return true;

  return expiryTime > Date.now();
}

/**
 * Returns effective price after taking expiration into consideration.
 * If expired and originalPrice is present, reverts to originalPrice.
 */
export function getEffectiveProductPrice(product: Product): { price: number; originalPrice?: number; discountPercent?: number; isExpired: boolean } {
  const active = isProductDiscountActive(product);
  
  if (active) {
    return {
      price: product.price,
      originalPrice: product.originalPrice,
      discountPercent: product.discountPercent || (product.originalPrice && product.originalPrice > product.price ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100) : undefined),
      isExpired: false
    };
  }

  // If discount has expired, price is originalPrice (if available and higher) or regular price
  const basePrice = product.originalPrice && product.originalPrice > product.price ? product.originalPrice : product.price;
  return {
    price: basePrice,
    originalPrice: undefined,
    discountPercent: undefined,
    isExpired: Boolean(product.discountValidUntil && new Date(product.discountValidUntil).getTime() <= Date.now())
  };
}

/**
 * Calculates remaining time for a discount validity date
 */
export function getRemainingTime(validUntil?: string): {
  isExpired: boolean;
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
  formattedText: string;
  badgeText: string;
} | null {
  if (!validUntil) return null;

  const expiry = new Date(validUntil).getTime();
  if (isNaN(expiry)) return null;

  const now = Date.now();
  const diff = expiry - now;

  if (diff <= 0) {
    return {
      isExpired: true,
      days: 0,
      hours: 0,
      minutes: 0,
      seconds: 0,
      formattedText: 'অফারের মেয়াদ শেষ (Expired)',
      badgeText: 'Expired'
    };
  }

  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
  const seconds = Math.floor((diff % (1000 * 60)) / 1000);

  let formattedText = '';
  let badgeText = '';

  if (days > 0) {
    formattedText = `${days} দিন ${hours} ঘণ্টা বাকি`;
    badgeText = `${days}d ${hours}h left`;
  } else if (hours > 0) {
    formattedText = `${hours} ঘণ্টা ${minutes} মিনিট বাকি (Flash Deal)`;
    badgeText = `${hours}h ${minutes}m left`;
  } else {
    formattedText = `${minutes} মিনিট ${seconds} সেকেন্ড বাকি!`;
    badgeText = `${minutes}m ${seconds}s left`;
  }

  return {
    isExpired: false,
    days,
    hours,
    minutes,
    seconds,
    formattedText,
    badgeText
  };
}

/**
 * Generates an ISO string for X days from now
 */
export function getExpiryDateFromDays(days: number): string {
  const d = new Date();
  d.setDate(d.getDate() + days);
  // Set to end of day 23:59:59
  d.setHours(23, 59, 59, 999);
  return d.toISOString();
}

/**
 * Checks if a coupon is currently valid (active & not expired)
 */
export function checkCouponValidity(coupon: Coupon): { isValid: boolean; valid: boolean; message?: string } {
  if (!coupon.active) {
    return { isValid: false, valid: false, message: 'কুপনটি বর্তমানে নিষ্ক্রিয় রয়েছে (Coupon is inactive).' };
  }

  if (coupon.validUntil) {
    const expiry = new Date(coupon.validUntil).getTime();
    if (!isNaN(expiry) && expiry <= Date.now()) {
      const expDate = new Date(coupon.validUntil).toLocaleDateString('bn-BD', { day: 'numeric', month: 'short', year: 'numeric' });
      return { isValid: false, valid: false, message: `এই কুপনের মেয়াদ ${expDate} তারিখে শেষ হয়ে গেছে (Coupon expired).` };
    }
  }

  return { isValid: true, valid: true };
}

/**
 * Checks if store-wide flash sale is currently active
 */
export function checkFlashSaleActive(aboutInfo?: AboutInfo): boolean {
  if (!aboutInfo?.flashSaleActive) return false;
  if (!aboutInfo.flashSaleValidUntil) return true;

  const expiry = new Date(aboutInfo.flashSaleValidUntil).getTime();
  if (isNaN(expiry)) return true;

  return expiry > Date.now();
}

/**
 * Extracts ONLY clean digits from bKash / Nagad / Rocket / Phone number string.
 * Strips out "(Personal)", "(Send Money)", "(বিকাশ পার্সোনাল)", spaces, dashes, parentheses, text.
 * Ensures the copied string contains only the actual dialable / mobile transfer digits (e.g. "01700000000").
 */
export function extractCleanPhoneNumber(rawNumber?: string): string {
  if (!rawNumber) return '';
  
  // 1. Remove anything in brackets/parentheses e.g. (Personal), (Agent), (বিকাশ)
  let clean = rawNumber.replace(/\(.*?\)/g, '').replace(/\[.*?\]/g, '');
  
  // 2. Remove common words in Bangla and English
  clean = clean.replace(/(personal|agent|merchant|send money|পার্সোনাল|মার্চেন্ট|এজেন্ট|বিকাশ|নগদ|রকেট|bkash|nagad|rocket|phone|mobile|no|num)/gi, '');
  
  // 3. Remove hyphens, spaces, dots, commas, colons
  const noSpace = clean.replace(/[-.\s,:+]/g, '');
  
  // 4. Match standard Bangladesh 11-digit mobile number pattern (e.g. 013, 014, 015, 016, 017, 018, 019)
  const bdMatch = noSpace.match(/(01[3-9]\d{8})/);
  if (bdMatch) {
    return bdMatch[1];
  }
  
  // 5. Match with 880 or +880 country code
  const bdIntlMatch = clean.replace(/[\s-]/g, '').match(/(\+?8801[3-9]\d{8})/);
  if (bdIntlMatch) {
    // If it has +8801..., convert to standard 01... for seamless Send Money in bKash/Nagad app
    const digits = bdIntlMatch[1].replace(/^\+?88/, '');
    if (digits.startsWith('01') && digits.length === 11) {
      return digits;
    }
    return bdIntlMatch[1];
  }

  // 6. Fallback: extract all digits
  const onlyDigits = clean.replace(/\D/g, '');
  if (onlyDigits.length >= 11) {
    if (onlyDigits.startsWith('8801') && onlyDigits.length === 13) {
      return onlyDigits.slice(2);
    }
    return onlyDigits.slice(0, 11);
  }

  return onlyDigits || rawNumber.trim();
}

/**
 * Gets coupon usage count for a user in the current calendar month
 */
export function getUserMonthlyCouponUsage(
  userIdentifier: { email?: string; phone?: string },
  orders: Order[]
): { count: number; lastUsedDate?: string; usedOrders: Order[] } {
  const emailClean = userIdentifier.email?.trim().toLowerCase();
  const phoneClean = userIdentifier.phone?.replace(/\D/g, '');

  if (!emailClean && !phoneClean) {
    return { count: 0, usedOrders: [] };
  }

  const now = new Date();
  const currentYear = now.getFullYear();
  const currentMonth = now.getMonth(); // 0-11

  const usedOrders = orders.filter((order) => {
    // Check if order used a coupon and is not cancelled
    const hasCoupon = Boolean(
      order.couponCode ||
      (order.notes && order.notes.includes('Coupon Applied')) ||
      (order.couponDiscount && order.couponDiscount > 0)
    );

    if (!hasCoupon) return false;
    if (order.status === 'Cancelled') return false;

    // Check if within current calendar month
    const orderDate = new Date(order.createdAt);
    if (isNaN(orderDate.getTime())) return false;
    if (orderDate.getFullYear() !== currentYear || orderDate.getMonth() !== currentMonth) {
      return false;
    }

    // Match by email or phone
    const orderEmail = order.customerEmail?.trim().toLowerCase();
    const orderPhone = order.customerPhone?.replace(/\D/g, '');

    const matchEmail = emailClean && orderEmail && emailClean === orderEmail;
    const matchPhone = phoneClean && orderPhone && (phoneClean === orderPhone || phoneClean.endsWith(orderPhone) || orderPhone.endsWith(phoneClean));

    return matchEmail || matchPhone;
  });

  return {
    count: usedOrders.length,
    lastUsedDate: usedOrders.length > 0 ? usedOrders[0].createdAt : undefined,
    usedOrders
  };
}

/**
 * Checks if a user has exceeded their monthly coupon usage limit
 */
export function checkUserMonthlyCouponLimit(
  userIdentifier: { email?: string; phone?: string },
  orders: Order[],
  maxLimit: number = 1
): { allowed: boolean; usedCount: number; message?: string } {
  const { count } = getUserMonthlyCouponUsage(userIdentifier, orders);

  if (count >= maxLimit) {
    const currentMonthName = new Date().toLocaleString('bn-BD', { month: 'long' });
    return {
      allowed: false,
      usedCount: count,
      message: `আপনি এই মাসে (${currentMonthName}) ইতিমধ্যে কুপন ব্যবহার করেছেন। ১ মাসে ১ বারের বেশি কুপন ব্যবহার করা যাবে না।`
    };
  }

  return { allowed: true, usedCount: count };
}

/**
 * Copies strictly clean digits to clipboard
 */
export function copyCleanPhoneNumber(rawNumber?: string): string {
  const clean = extractCleanPhoneNumber(rawNumber);
  if (clean && typeof navigator !== 'undefined' && navigator.clipboard) {
    navigator.clipboard.writeText(clean);
  }
  return clean;
}


