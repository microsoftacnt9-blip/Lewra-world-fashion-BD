import React, { useState, useEffect } from 'react';
import { Activity, BarChart2, Cpu, Globe, Server, Shield, Zap, Terminal, RefreshCw, Eye, Layers, Settings, Play } from 'lucide-react';

export const DashboardShowcase: React.FC = () => {
  const [viewMode, setViewMode] = useState<'analytics' | 'agent-mesh' | 'spatial-ui'>('analytics');
  const [timeRange, setTimeRange] = useState<'Live' | '1H' | '24H' | '7D'>('Live');
  const [latencyValue, setLatencyValue] = useState(1.18);
  const [throughput, setThroughput] = useState(842);
  const [activeAgentsCount, setActiveAgentsCount] = useState(4820);
  const [logs, setLogs] = useState<string[]>([
    '[SYSTEM] Lewra Mesh Node #802 initialized in us-east-1.',
    '[QUANTUM] Lattice key pair rotated successfully.',
    '[AGENT-04] Executed spatial mesh rendering (0.9ms).',
    '[TELEMETRY] 12,450 events stream synced to Edge Global.'
  ]);

  // Simulate real-time data jitter
  useEffect(() => {
    const interval = setInterval(() => {
      setLatencyValue(Number((1.1 + Math.random() * 0.2).toFixed(2)));
      setThroughput(prev => Math.floor(prev + (Math.random() * 20 - 10)));
      setActiveAgentsCount(prev => Math.floor(prev + (Math.random() * 6 - 3)));

      const agentIds = ['AGENT-01', 'AGENT-09', 'AGENT-14', 'AGENT-88', 'AGENT-102'];
      const actions = [
        'Optimized spatial polygon mesh buffer.',
        'Validated post-quantum token handshake.',
        'Routed edge event stream to EU-Central-1.',
        'Auto-scaled micro-worker instance.',
        'Synthesized 3D spatial node depth map.'
      ];
      const randomAgent = agentIds[Math.floor(Math.random() * agentIds.length)];
      const randomAction = actions[Math.floor(Math.random() * actions.length)];
      const timestamp = new Date().toLocaleTimeString();

      setLogs(prev => [
        `[${timestamp}] [${randomAgent}] ${randomAction}`,
        ...prev.slice(0, 5)
      ]);
    }, 2500);

    return () => clearInterval(interval);
  }, []);

  return (
    <section id="showcase" className="py-24 relative bg-grid-pattern">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-900 border border-cyan-500/30 text-cyan-300 text-xs font-mono font-semibold uppercase tracking-wider mb-4">
            <Activity className="w-3.5 h-3.5 text-cyan-400" />
            LIVE DASHBOARD SHOWCASE
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight font-['Space_Grotesk'] mb-4">
            Command Center for <span className="text-gradient-cyan">Spatial Intelligence</span>
          </h2>
          <p className="text-slate-400 text-base sm:text-lg">
            Experience real-time stream telemetry, hardware cluster tracking, and spatial UI component state in one interactive mockup.
          </p>
        </div>

        {/* Dashboard Mockup Frame */}
        <div className="glass-card rounded-2xl border border-slate-700/80 shadow-2xl overflow-hidden max-w-6xl mx-auto">
          
          {/* Dashboard Bar Top Navigation */}
          <div className="bg-[#090D18] border-b border-slate-800 p-4 flex flex-wrap items-center justify-between gap-4">
            
            {/* View Selectors */}
            <div className="flex items-center gap-2 bg-slate-900/90 p-1 rounded-xl border border-slate-800">
              <button
                onClick={() => setViewMode('analytics')}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                  viewMode === 'analytics' ? 'bg-cyan-500 text-slate-950 shadow-md' : 'text-slate-400 hover:text-white'
                }`}
              >
                <BarChart2 className="w-3.5 h-3.5" /> Real-time Analytics
              </button>
              <button
                onClick={() => setViewMode('agent-mesh')}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                  viewMode === 'agent-mesh' ? 'bg-purple-500 text-white shadow-md' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Cpu className="w-3.5 h-3.5" /> Node Hardware Mesh
              </button>
              <button
                onClick={() => setViewMode('spatial-ui')}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                  viewMode === 'spatial-ui' ? 'bg-indigo-500 text-white shadow-md' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Layers className="w-3.5 h-3.5" /> Spatial UI Inspector
              </button>
            </div>

            {/* Time Range Selector */}
            <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-lg border border-slate-800 text-xs">
              {(['Live', '1H', '24H', '7D'] as const).map((t) => (
                <button
                  key={t}
                  onClick={() => setTimeRange(t)}
                  className={`px-2.5 py-1 rounded font-mono ${
                    timeRange === t ? 'bg-slate-800 text-cyan-300 font-bold' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>

            {/* Status pill */}
            <div className="flex items-center gap-2 text-xs font-mono bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 px-3 py-1 rounded-full">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              Cluster Status: Operational
            </div>

          </div>

          {/* Main Dashboard Content Area */}
          <div className="p-6 bg-[#060913] grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Main Center Panel (2 Columns on desktop) */}
            <div className="lg:col-span-2 space-y-6">
              
              {/* Stat Cards Row */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="bg-[#0D1322] border border-slate-800 rounded-xl p-4">
                  <div className="text-xs font-mono text-slate-400 mb-1 flex justify-between">
                    <span>EDGE LATENCY</span>
                    <Zap className="w-3.5 h-3.5 text-cyan-400" />
                  </div>
                  <div className="text-2xl font-bold font-mono text-white flex items-baseline gap-1">
                    {latencyValue} <span className="text-xs text-cyan-400 font-sans">ms</span>
                  </div>
                  <div className="text-[10px] text-emerald-400 font-mono mt-1">↓ 14% vs last hour</div>
                </div>

                <div className="bg-[#0D1322] border border-slate-800 rounded-xl p-4">
                  <div className="text-xs font-mono text-slate-400 mb-1 flex justify-between">
                    <span>THROUGHPUT</span>
                    <Server className="w-3.5 h-3.5 text-purple-400" />
                  </div>
                  <div className="text-2xl font-bold font-mono text-white flex items-baseline gap-1">
                    {throughput} <span className="text-xs text-purple-400 font-sans">Gbps</span>
                  </div>
                  <div className="text-[10px] text-purple-300 font-mono mt-1">Sub-10ms Mesh Sync</div>
                </div>

                <div className="bg-[#0D1322] border border-slate-800 rounded-xl p-4">
                  <div className="text-xs font-mono text-slate-400 mb-1 flex justify-between">
                    <span>ACTIVE AGENTS</span>
                    <Cpu className="w-3.5 h-3.5 text-amber-400" />
                  </div>
                  <div className="text-2xl font-bold font-mono text-white flex items-baseline gap-1">
                    {activeAgentsCount.toLocaleString()}
                  </div>
                  <div className="text-[10px] text-emerald-400 font-mono mt-1">100% Health Score</div>
                </div>
              </div>

              {/* Dynamic View Panel */}
              <div className="bg-[#0D1322] border border-slate-800 rounded-xl p-5 min-h-[280px] flex flex-col justify-between">
                
                {viewMode === 'analytics' && (
                  <div>
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="text-sm font-bold text-white font-['Space_Grotesk']">
                        High-Frequency Stream Telemetry (Events/sec)
                      </h4>
                      <span className="text-xs font-mono text-cyan-400">Peak: 52,000 req/s</span>
                    </div>

                    {/* Simulated SVG Wave Chart */}
                    <div className="h-44 w-full relative flex items-end gap-1.5 pt-4">
                      {[40, 55, 35, 70, 85, 60, 95, 75, 100, 80, 90, 65, 85, 98, 70, 88, 92, 100, 84, 96].map((val, i) => (
                        <div key={i} className="flex-1 bg-slate-900 rounded-t-sm h-full flex items-end">
                          <div
                            className="w-full bg-gradient-to-t from-cyan-600 via-indigo-500 to-cyan-300 rounded-t-sm transition-all duration-500 hover:brightness-125"
                            style={{ height: `${val}%` }}
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {viewMode === 'agent-mesh' && (
                  <div>
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="text-sm font-bold text-white font-['Space_Grotesk']">
                        Autonomous Micro-Agent Cluster Map
                      </h4>
                      <span className="text-xs font-mono text-purple-400">300 Global Nodes</span>
                    </div>

                    {/* Agent Cluster Grid Mock */}
                    <div className="grid grid-cols-4 sm:grid-cols-6 gap-3 py-2">
                      {Array.from({ length: 12 }).map((_, idx) => (
                        <div key={idx} className="bg-slate-900/90 border border-slate-800 p-2.5 rounded-lg text-center hover:border-purple-500/60 transition-colors">
                          <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 mx-auto mb-1 animate-pulse" />
                          <span className="text-[10px] font-mono text-slate-300 block">Node-{idx + 101}</span>
                          <span className="text-[9px] font-mono text-purple-400">0.8ms</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {viewMode === 'spatial-ui' && (
                  <div>
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="text-sm font-bold text-white font-['Space_Grotesk']">
                        Generative Spatial Glassmorphic Component State
                      </h4>
                      <span className="text-xs font-mono text-indigo-400">FPS: 60.0</span>
                    </div>

                    <div className="p-4 rounded-xl bg-gradient-to-br from-indigo-950/40 via-slate-900 to-cyan-950/40 border border-indigo-500/30 flex items-center justify-between">
                      <div>
                        <span className="text-xs font-mono text-cyan-300">Target Component: &lt;LewraGlassCard /&gt;</span>
                        <p className="text-xs text-slate-300 mt-1">Blur: 20px | Refraction Index: 1.45 | Backdrop: Dark Midnight</p>
                      </div>
                      <button className="px-3 py-1.5 bg-indigo-500 text-white rounded-lg text-xs font-semibold">
                        Export JSON
                      </button>
                    </div>
                  </div>
                )}

                <div className="pt-3 border-t border-slate-800/60 flex items-center justify-between text-xs font-mono text-slate-400">
                  <span>Engine: Lewra Spatial v3.4</span>
                  <span className="text-cyan-400">All Nodes In Sync</span>
                </div>

              </div>

            </div>

            {/* Right Column: Live Logs Stream */}
            <div className="bg-[#0D1322] border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-800">
                  <span className="text-xs font-bold font-mono text-cyan-400 flex items-center gap-1.5">
                    <Terminal className="w-3.5 h-3.5" /> EVENT STREAM LOGS
                  </span>
                  <RefreshCw className="w-3 h-3 text-slate-500 animate-spin" />
                </div>

                <div className="space-y-2.5 font-mono text-[11px]">
                  {logs.map((log, index) => (
                    <div key={index} className="p-2 rounded bg-slate-950/70 border border-slate-800/80 text-slate-300 leading-tight">
                      {log}
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800 text-[10px] font-mono text-slate-500 text-center">
                Autosaving stream state to Lewra Cloud
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
