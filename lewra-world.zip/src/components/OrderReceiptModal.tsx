import React, { useState } from 'react';
import { Order, AboutInfo } from '../types';
import { X, CheckCircle2, Clock, Truck, Package, Phone, MapPin, Mail, Calendar, FileText, Sparkles, Printer, Check, AlertCircle, DollarSign, Send, ShieldCheck, QrCode, Receipt } from 'lucide-react';

interface OrderReceiptModalProps {
  order: Order | null;
  aboutInfo?: AboutInfo;
  onClose: () => void;
  onUpdateOrder?: (order: Order) => void;
}

export const OrderReceiptModal: React.FC<OrderReceiptModalProps> = ({ order, aboutInfo, onClose, onUpdateOrder }) => {
  if (!order) return null;

  const [invoiceType, setInvoiceType] = useState<'a4' | 'pos'>('a4');
  const [selectedRefundMethod, setSelectedRefundMethod] = useState<string>(() => {
    return order.customerRefundMethod || order.paymentMethod || 'bKash';
  });
  const [customNumberInput, setCustomNumberInput] = useState<string>(() => {
    return order.refundRequestedNumber || order.paymentSenderPhone || order.customerPhone || '';
  });
  const [customNumberError, setCustomNumberError] = useState('');
  const [isCancellingOrder, setIsCancellingOrder] = useState(false);

  const isConfirmed = order.status !== 'Pending' && order.status !== 'Cancelled';
  const originalPaymentNumber = order.paymentSenderPhone || order.customerPhone || '';

  const hasSubmittedRefundInfo = Boolean(
    order.customerRefundMethod || order.refundRequestedNumber || order.refundSubmittedAt || order.customerRefundChoice
  );

  const handlePrint = () => {
    window.print();
  };

  const handleSubmitRefundRequest = (e: React.FormEvent) => {
    e.preventDefault();
    setCustomNumberError('');
    const cleanNum = customNumberInput.replace(/\D/g, '').trim();

    if (!cleanNum || cleanNum.length < 11) {
      setCustomNumberError('অনুগ্রহ করে সঠিক ১১ ডিজিটের পার্সোনাল নম্বর/অ্যাকাউন্ট নম্বর দিন (যেমন: 01700000000)।');
      return;
    }

    if (!onUpdateOrder) return;
    const updatedOrder: Order = {
      ...order,
      customerRefundMethod: selectedRefundMethod,
      refundRequestedNumber: cleanNum,
      refundSubmittedAt: new Date().toISOString(),
      customerRefundChoice: 'custom',
      refundStatus: 'Awaiting Admin Refund'
    };
    onUpdateOrder(updatedOrder);
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#0E0A07]/85 backdrop-blur-md p-3 sm:p-6 flex items-center justify-center animate-in fade-in overflow-y-auto print:p-0 print:bg-white print:static">
      <div className={`glass-card max-w-xl w-full rounded-2xl border border-[#3D2B22] p-5 sm:p-8 relative text-[#FFF8F2] shadow-2xl my-auto bg-[#140E0A] max-h-[90vh] overflow-y-auto custom-scrollbar print:max-w-none print:w-full print:bg-white print:text-black print:border-none print:shadow-none print:max-h-none print:overflow-visible ${invoiceType === 'pos' ? 'max-w-md' : ''}`}>
        
        {/* Warm Glow background (Hidden on print) */}
        <div className="absolute top-0 right-0 w-48 h-48 bg-[#D4A373]/10 rounded-full blur-3xl pointer-events-none print:hidden" />
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-[#8A5A36]/10 rounded-full blur-3xl pointer-events-none print:hidden" />

        {/* Top Format Selector & Close Button */}
        <div className="flex items-center justify-between gap-2 mb-4 pb-3 border-b border-[#3D2B22] print:hidden">
          <div className="flex items-center gap-1.5 bg-[#1C1410] p-1 rounded-xl border border-[#3D2B22]">
            <button
              type="button"
              onClick={() => setInvoiceType('a4')}
              className={`px-3 py-1 rounded-lg text-xs font-mono font-bold flex items-center gap-1 transition-all ${
                invoiceType === 'a4' ? 'bg-[#D4A373] text-[#140E0A]' : 'text-[#CBB5A1] hover:text-white'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>A4 Invoice</span>
            </button>
            <button
              type="button"
              onClick={() => setInvoiceType('pos')}
              className={`px-3 py-1 rounded-lg text-xs font-mono font-bold flex items-center gap-1 transition-all ${
                invoiceType === 'pos' ? 'bg-[#D4A373] text-[#140E0A]' : 'text-[#CBB5A1] hover:text-white'
              }`}
            >
              <Receipt className="w-3.5 h-3.5" />
              <span>POS Slip</span>
            </button>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full bg-[#281D17]/80 text-[#A88B77] hover:text-[#FFF8F2] hover:bg-[#33231B] border border-[#523A2E] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Company Invoice Header */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 mb-6 pb-5 border-b border-[#3D2B22] print:border-gray-300">
          <div className="text-center sm:text-left">
            <h1 className="text-xl sm:text-2xl font-extrabold font-['Space_Grotesk'] text-[#FFF8F2] print:text-black tracking-tight">
              {aboutInfo?.companyName || 'LEWRA WORLD'}
            </h1>
            <p className="text-xs text-[#A88B77] print:text-gray-600 font-mono">
              {aboutInfo?.tagline || 'Official Hardware & Spatial Ecosystem'}
            </p>
            <p className="text-[11px] text-[#A88B77] print:text-gray-500 font-mono mt-0.5">
              {aboutInfo?.phone || '+880 1700-000000'} • {aboutInfo?.email || 'contact@lewra.world'}
            </p>
          </div>

          <div className="text-center sm:text-right font-mono text-xs">
            <div className="px-3 py-1 rounded-lg bg-[#281D17] print:bg-gray-100 border border-[#523A2E] print:border-gray-300 text-[#D4A373] print:text-black font-extrabold inline-block">
              INVOICE #{order.id}
            </div>
            <div className="text-[11px] text-[#A88B77] print:text-gray-600 mt-1">
              Issued: {new Date(order.createdAt).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}
            </div>
          </div>
        </div>

        {/* Status Notification */}
        <div className="text-center mb-5 pb-4 border-b border-[#3D2B22] print:hidden">
          <div className="flex items-center justify-center gap-2 mb-1">
            {order.status === 'Cancelled' ? (
              <AlertCircle className="w-6 h-6 text-rose-400" />
            ) : isConfirmed ? (
              <CheckCircle2 className="w-6 h-6 text-emerald-400" />
            ) : (
              <Clock className="w-6 h-6 text-amber-400 animate-pulse" />
            )}
            <h2 className="text-lg sm:text-xl font-bold font-['Space_Grotesk'] text-[#FFF8F2]">
              {order.status === 'Cancelled'
                ? `Order Cancelled ${order.cancelledBy === 'Customer' ? '(By Customer)' : '(By Store Admin)'}`
                : isConfirmed
                ? 'Order Confirmed!'
                : 'Order Placed (Awaiting Confirmation)'}
            </h2>
          </div>

          <p className="text-xs text-[#A88B77] font-medium">
            {order.status === 'Cancelled'
              ? order.cancelledBy === 'Customer'
                ? 'এই অর্ডারটি আপনি (কাস্টমার) নিজে বাতিল করেছেন।'
                : 'এই অর্ডারটি বিক্রেতা / স্টোর অ্যাডমিন কর্তৃক বাতিল করা হয়েছে।'
              : isConfirmed
              ? 'আপনার অর্ডারটি সফলভাবে কনফার্ম করা হয়েছে। নিচে বিস্তারিত সময়সূচী ও রসিদ দেওয়া হলো।'
              : 'আপনার অর্ডারটি আমাদের সিস্টেমে যুক্ত হয়েছে। বিক্রেতা কনফার্ম করলেই আপডেট পাবেন।'}
          </p>
        </div>

        {/* Cancellation Notice & Refund Management (Hidden on print) */}
        {order.status === 'Cancelled' && (
          <div className="mb-6 p-4 rounded-xl bg-rose-950/80 border border-rose-500/50 text-rose-200 text-xs font-mono space-y-2.5 animate-in zoom-in-95 shadow-xl print:hidden">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-rose-500/30 pb-2">
              <div className="flex items-center gap-2 font-bold text-rose-300 text-sm">
                <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                <span>Order Cancellation Details:</span>
              </div>
              <span className="px-2.5 py-1 rounded-full bg-rose-900/90 border border-rose-400/50 text-rose-100 text-[11px] font-extrabold flex items-center gap-1 shadow-inner">
                <span>Cancelled By:</span>
                <span className="text-white bg-rose-950 px-2 py-0.5 rounded border border-rose-500/40 font-mono">
                  {order.cancelledBy === 'Customer' ? 'Customer (আপনি নিজে)' : 'Store Admin / Seller (বিক্রেতা)'}
                </span>
              </span>
            </div>

            <p className="text-rose-100 font-semibold text-xs leading-relaxed font-sans">
              {order.cancelledBy === 'Customer'
                ? 'আপনি (কাস্টমার) নিজে এই অর্ডারটি বাতিল করার অনুরোধ নিশ্চিত করেছেন।'
                : 'অনিবার্য কারণবশত স্টোর অ্যাডমিন / বিক্রেতা কর্তৃক এই অর্ডারটি বাতিল করা হয়েছে। আমরা আন্তরিকভাবে দুঃখিত।'}
            </p>

            {order.cancelledBy === 'Customer' ? (
              <div className="p-2.5 rounded-lg bg-rose-900/60 border border-rose-500/40 text-rose-200 font-bold text-[11px] mt-2">
                Note: Since this order was cancelled by you (the customer), no refund will be issued according to store policy.
              </div>
            ) : (
              <>
                {hasSubmittedRefundInfo ? (
                  <div className="p-4 rounded-xl bg-[#1C1410] border border-[#523A2E] text-[#FFF8F2] space-y-3 mt-3 animate-in fade-in">
                    <div className="flex items-center justify-between border-b border-[#3D2B22] pb-2">
                      <div className="flex items-center gap-2 font-bold text-[#E6CCB2] text-xs">
                        <CheckCircle2 className="w-4 h-4 text-[#D4A373] shrink-0" />
                        <span>Refund Information Submitted</span>
                      </div>
                      <span className="px-2 py-0.5 rounded bg-[#281D17] border border-[#523A2E] text-[10px] text-[#D4A373] font-mono font-bold">
                        Submitted Receipt
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs font-mono bg-[#140E0A] p-3 rounded-xl border border-[#3D2B22]">
                      <div>
                        <span className="text-[#A88B77] block text-[10px]">Your Preferred Refund Method:</span>
                        <span className="font-bold text-[#E6CCB2] bg-[#281D17] px-2 py-0.5 rounded border border-[#523A2E] inline-block mt-0.5">
                          {order.customerRefundMethod || order.paymentMethod || 'bKash'}
                        </span>
                      </div>

                      <div>
                        <span className="text-[#A88B77] block text-[10px]">Your Target Refund Number:</span>
                        <span className="font-bold text-amber-300">{order.refundRequestedNumber || originalPaymentNumber}</span>
                      </div>

                      <div>
                        <span className="text-[#A88B77] block text-[10px]">Original Payment Method:</span>
                        <span className="font-semibold text-[#CBB5A1]">{order.paymentMethod || 'Cash on Delivery'}</span>
                      </div>

                      <div>
                        <span className="text-[#A88B77] block text-[10px]">Original Mobile / TrxID:</span>
                        <span className="text-[#CBB5A1]">{originalPaymentNumber || 'N/A'} {order.paymentTrxId ? `(${order.paymentTrxId})` : ''}</span>
                      </div>
                    </div>

                    {order.refundStatus === 'Refund Completed' || order.adminRefundTrxId ? (
                      <div className="p-3.5 rounded-xl bg-emerald-950/90 border border-emerald-500/50 text-emerald-200 space-y-2">
                        <div className="flex items-center gap-2 font-bold text-emerald-300 text-xs">
                          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                          <span>Money Refund Completed</span>
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] font-mono pt-1 border-t border-emerald-500/30">
                          <div>
                            <span className="text-[#A88B77] block text-[10px]">Refund Sent Via:</span>
                            <span className="font-bold text-pink-300">{order.adminRefundMethod || order.customerRefundMethod || 'bKash'}</span>
                          </div>
                          <div>
                            <span className="text-[#A88B77] block text-[10px]">TrxID:</span>
                            <span className="font-bold text-amber-300">{order.adminRefundTrxId}</span>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="p-3 rounded-xl bg-amber-950/80 border border-amber-500/50 text-amber-200 space-y-1.5">
                        <div className="flex items-center gap-2 font-bold text-amber-300 text-xs">
                          <Clock className="w-4 h-4 text-amber-400 shrink-0 animate-pulse" />
                          <span>Awaiting Admin Refund</span>
                        </div>
                        <p className="text-[11px] text-amber-100">
                          Your refund request is queued for processing. TrxID will appear here once transferred.
                        </p>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="p-4 rounded-xl bg-[#1C1410] border border-[#523A2E] text-[#FFF8F2] space-y-3.5 mt-3 animate-in fade-in">
                    <div className="flex items-center gap-2 font-bold text-[#E6CCB2] text-xs">
                      <DollarSign className="w-4 h-4 text-[#D4A373] shrink-0" />
                      <span>Refund Request Option</span>
                    </div>

                    <p className="text-xs text-[#CBB5A1]">
                      Select preferred payment channel and number to claim your refund:
                    </p>

                    <form onSubmit={handleSubmitRefundRequest} className="space-y-3">
                      <div className="grid grid-cols-4 gap-2 text-xs font-mono">
                        {['bKash', 'Nagad', 'Rocket', 'Upay'].map((method) => (
                          <button
                            key={method}
                            type="button"
                            onClick={() => setSelectedRefundMethod(method)}
                            className={`py-2 px-2 rounded-lg font-bold border transition-all text-center ${
                              selectedRefundMethod === method
                                ? 'bg-[#D4A373] text-[#140E0A] border-[#F5EBE0]/80 shadow-md font-extrabold'
                                : 'bg-[#281D17] text-[#CBB5A1] border-[#523A2E] hover:border-[#D4A373]'
                            }`}
                          >
                            {method}
                          </button>
                        ))}
                      </div>

                      <input
                        type="tel"
                        value={customNumberInput}
                        onChange={(e) => {
                          setCustomNumberInput(e.target.value);
                          setCustomNumberError('');
                        }}
                        placeholder="e.g., 01700000000"
                        className="w-full px-3.5 py-2.5 rounded-xl bg-[#140E0A] border border-[#523A2E] focus:border-[#D4A373] focus:outline-none text-[#FFF8F2] font-mono text-sm shadow-inner"
                      />
                      {customNumberError && (
                        <span className="text-rose-400 text-[11px] block">{customNumberError}</span>
                      )}

                      <button
                        type="submit"
                        className="w-full py-2.5 px-4 rounded-xl bg-[#D4A373] hover:bg-[#E6CCB2] text-[#140E0A] font-extrabold text-xs font-mono flex items-center justify-center gap-2"
                      >
                        <Send className="w-3.5 h-3.5" />
                        <span>Submit Refund Details</span>
                      </button>
                    </form>
                  </div>
                )}
              </>
            )}
          </div>
        )}

        {/* Customer & Shipping Details Grid */}
        <div className="p-4 rounded-xl bg-[#1C1410] print:bg-white border border-[#3D2B22] print:border-gray-300 text-xs space-y-3 mb-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs print:text-black">
            <div>
              <span className="text-[#A88B77] print:text-gray-500 block text-[10px]">BILLED TO / CUSTOMER</span>
              <span className="font-bold text-[#FFF8F2] print:text-black text-sm">{order.customerName}</span>
              <span className="block text-[#E6CCB2] print:text-gray-700 font-mono mt-0.5">{order.customerPhone}</span>
              <span className="block text-[#CBB5A1] print:text-gray-600 font-mono text-[11px]">{order.customerEmail}</span>
            </div>

            <div>
              <span className="text-[#A88B77] print:text-gray-500 block text-[10px]">SHIPPING DESTINATION</span>
              <span className="text-[#FFF8F2] print:text-black leading-relaxed">{order.shippingAddress || 'N/A'}</span>
              <span className="block text-[11px] font-mono text-[#D4A373] print:text-black font-bold mt-1">
                Zone: {order.deliveryZone || 'Standard Area'}
              </span>
            </div>

            {/* Payment Info */}
            <div className="col-span-1 sm:col-span-2 pt-2 border-t border-[#3D2B22] print:border-gray-300 grid grid-cols-2 sm:grid-cols-4 gap-2">
              <div>
                <span className="text-[#A88B77] print:text-gray-500 block text-[10px]">PAYMENT METHOD</span>
                <span className="font-mono text-pink-300 print:text-black font-bold">{order.paymentMethod || 'Cash on Delivery'}</span>
              </div>
              {order.paymentSenderPhone && (
                <div>
                  <span className="text-[#A88B77] print:text-gray-500 block text-[10px]">SENDER MOBILE</span>
                  <span className="font-mono text-amber-300 print:text-black font-bold">{order.paymentSenderPhone}</span>
                </div>
              )}
              {order.paymentTrxId ? (
                <div>
                  <span className="text-[#A88B77] print:text-gray-500 block text-[10px]">TRANSACTION ID</span>
                  <span className="font-mono text-[#D4A373] print:text-black font-extrabold uppercase">{order.paymentTrxId}</span>
                </div>
              ) : (
                order.paymentSenderPhone && (
                  <div>
                    <span className="text-[#A88B77] print:text-gray-500 block text-[10px]">VERIFICATION</span>
                    <span className="font-mono text-emerald-400 print:text-black font-medium text-[11px]">Via Mobile No</span>
                  </div>
                )
              )}
              {order.trackingCourier && (
                <div>
                  <span className="text-[#A88B77] print:text-gray-500 block text-[10px]">COURIER PARTNER</span>
                  <span className="font-mono text-emerald-400 print:text-black font-bold">{order.trackingCourier}</span>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Ordered Items Table with Variants */}
        <div className="space-y-3 mb-6">
          <h4 className="text-xs font-mono text-[#E6CCB2] print:text-black uppercase tracking-wider font-bold">
            Itemized Order Breakdown
          </h4>
          <div className="rounded-xl border border-[#3D2B22] print:border-gray-400 bg-[#1C1410] print:bg-white overflow-hidden text-xs">
            <div className="p-3 bg-[#140E0A] print:bg-gray-100 border-b border-[#3D2B22] print:border-gray-300 font-mono text-[10px] text-[#A88B77] print:text-black grid grid-cols-12 font-bold">
              <span className="col-span-6">DESCRIPTION & SPECS</span>
              <span className="col-span-2 text-center">QTY</span>
              <span className="col-span-2 text-right">UNIT PRICE</span>
              <span className="col-span-2 text-right">AMOUNT</span>
            </div>

            {order.items.map((item, idx) => (
              <div key={idx} className="p-3 border-b border-[#3D2B22]/60 print:border-gray-200 grid grid-cols-12 items-center">
                <div className="col-span-6">
                  <div className="font-bold text-[#FFF8F2] print:text-black">{item.productName}</div>
                  {(item.selectedColor || item.selectedSpec || item.selectedSize) && (
                    <div className="text-[10px] text-cyan-400 print:text-gray-600 font-mono mt-0.5">
                      {[item.selectedColor, item.selectedSize, item.selectedSpec].filter(Boolean).join(' • ')}
                    </div>
                  )}
                </div>
                <span className="col-span-2 text-center font-mono text-[#CBB5A1] print:text-black">{item.quantity}</span>
                <span className="col-span-2 text-right font-mono text-[#CBB5A1] print:text-black">৳{item.price.toLocaleString()}</span>
                <span className="col-span-2 text-right font-mono text-[#D4A373] print:text-black font-bold">
                  ৳{(item.price * item.quantity).toLocaleString()}
                </span>
              </div>
            ))}

            {/* Price Calculations */}
            {(() => {
              const itemsSubtotal = order.items.reduce((sum, i) => sum + (i.price * i.quantity), 0);
              const delCharge = order.deliveryCharge ?? (order.deliveryZone?.includes('130') ? 130 : 60);
              const isCOD = order.paymentMethod === 'Cash on Delivery';
              const advancePaid = order.advancePaid !== undefined 
                ? order.advancePaid 
                : (isCOD ? 0 : order.totalAmount);
              const dueAmount = order.dueAmount !== undefined 
                ? order.dueAmount 
                : Math.max(0, order.totalAmount - advancePaid);

              return (
                <div className="p-3.5 bg-[#140E0A] print:bg-white space-y-2 border-t border-[#3D2B22] print:border-gray-300 text-xs font-mono">
                  <div className="flex justify-between items-center text-[#CBB5A1] print:text-gray-700">
                    <span>Products Subtotal:</span>
                    <span>৳{itemsSubtotal.toLocaleString()} BDT</span>
                  </div>

                  <div className="flex justify-between items-center text-[#E6CCB2] print:text-gray-700">
                    <span>Delivery Charge ({order.deliveryZone || 'Standard'}):</span>
                    <span>+৳{delCharge} BDT</span>
                  </div>

                  {itemsSubtotal + delCharge > order.totalAmount && (
                    <div className="flex justify-between items-center text-emerald-400 print:text-gray-800 font-semibold">
                      <span>Applied Promo Discount:</span>
                      <span>-৳{((itemsSubtotal + delCharge) - order.totalAmount).toLocaleString()} BDT</span>
                    </div>
                  )}

                  <div className="pt-2 border-t border-[#3D2B22] print:border-gray-400 flex justify-between items-center font-bold text-sm text-[#FFF8F2] print:text-black">
                    <span>GRAND TOTAL AMOUNT:</span>
                    <span className="text-[#D4A373] print:text-black text-base font-extrabold">৳{order.totalAmount.toLocaleString()} BDT</span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 pt-2 border-t border-[#3D2B22] print:border-gray-200 text-[11px]">
                    <div className="p-2 rounded-lg bg-emerald-950/40 print:bg-gray-50 border border-emerald-500/30 print:border-gray-300 flex items-center justify-between">
                      <span className="text-emerald-300 print:text-black font-bold">Advance Paid:</span>
                      <span className="font-mono font-extrabold text-emerald-400 print:text-black">৳{advancePaid.toLocaleString()} BDT</span>
                    </div>

                    <div className="p-2 rounded-lg bg-amber-950/40 print:bg-gray-50 border border-amber-500/30 print:border-gray-300 flex items-center justify-between">
                      <span className="text-amber-300 print:text-black font-bold">Due On Delivery:</span>
                      <span className="font-mono font-extrabold text-amber-400 print:text-black">৳{dueAmount.toLocaleString()} BDT</span>
                    </div>
                  </div>
                </div>
              );
            })()}
          </div>
        </div>

        {/* Authorized Signature Block on Print View */}
        <div className="hidden print:flex items-center justify-between pt-12 text-xs font-mono text-gray-700">
          <div className="text-center">
            <div className="w-36 border-b border-gray-400 mb-1"></div>
            <span>Customer Signature</span>
          </div>
          <div className="text-center">
            <div className="w-36 border-b border-gray-400 mb-1"></div>
            <span>Authorized Officer</span>
          </div>
        </div>

        {/* Customer Order Cancellation Confirmation Box */}
        {isCancellingOrder && (
          <div className="p-4 rounded-xl bg-rose-950/95 border border-rose-500/60 space-y-2 text-xs font-mono mb-4 animate-in zoom-in-95 shadow-xl print:hidden">
            <div className="flex items-center gap-2 text-rose-300 font-bold text-sm">
              <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />
              <span>Confirm Order Cancellation (অর্ডার বাতিলের নিশ্চিতকরণ)</span>
            </div>
            <p className="text-rose-100 text-xs leading-relaxed font-sans">
              Are you sure you want to cancel this order?
            </p>
            <div className="flex gap-2 pt-1">
              <button
                type="button"
                onClick={() => setIsCancellingOrder(false)}
                className="px-4 py-2 rounded-xl bg-[#281D17] text-[#CBB5A1] text-xs font-mono font-bold border border-[#523A2E]"
              >
                Go Back
              </button>
              <button
                type="button"
                onClick={() => {
                  if (onUpdateOrder) {
                    onUpdateOrder({
                      ...order,
                      status: 'Cancelled',
                      cancelledBy: 'Customer'
                    });
                  }
                  setIsCancellingOrder(false);
                }}
                className="flex-1 py-2 px-4 rounded-xl bg-rose-600 text-white font-extrabold text-xs font-mono"
              >
                Yes, Confirm Cancel
              </button>
            </div>
          </div>
        )}

        {/* Action Buttons (Hidden on Print) */}
        <div className="flex flex-col sm:flex-row items-center gap-3 pt-2 border-t border-[#3D2B22] print:hidden">
          {order.status !== 'Cancelled' && order.status !== 'Completed' && !isCancellingOrder && (
            <button
              type="button"
              onClick={() => setIsCancellingOrder(true)}
              className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors border border-rose-500/30 shrink-0"
            >
              <X className="w-4 h-4 text-rose-400" />
              <span>Cancel Order</span>
            </button>
          )}

          <button
            onClick={handlePrint}
            className="w-full sm:flex-1 py-2.5 rounded-xl bg-[#281D17] hover:bg-[#33231B] text-[#E6CCB2] font-bold text-xs flex items-center justify-center gap-2 transition-colors border border-[#523A2E]"
          >
            <Printer className="w-4 h-4 text-[#D4A373]" />
            Print / Save Invoice (PDF)
          </button>

          <button
            onClick={onClose}
            className="w-full sm:flex-1 py-2.5 rounded-xl bg-gradient-to-r from-[#D4A373] via-[#E6CCB2] to-[#DDB892] hover:from-[#E6CCB2] hover:to-[#D4A373] text-[#140E0A] font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-md shadow-[#140E0A]/50 border border-[#F5EBE0]/60"
          >
            Close Receipt
          </button>
        </div>

      </div>
    </div>
  );
};

