import React, { useState } from 'react';
import { PRICING_PLANS } from '../data/mockData';
import { Check, Zap, Sparkles, ArrowRight, ShieldCheck, HelpCircle, Sliders } from 'lucide-react';

interface PricingSectionProps {
  onOpenGetStarted: () => void;
}

export const PricingSection: React.FC<PricingSectionProps> = ({ onOpenGetStarted }) => {
  const [isAnnual, setIsAnnual] = useState(true);
  const [customRequestsMillions, setCustomRequestsMillions] = useState<number>(2.5);

  const calculateCustomPrice = (millions: number) => {
    const base = 1500;
    const variable = Math.round(millions * 800);
    return isAnnual ? Math.round((base + variable) * 0.8) : base + variable;
  };

  return (
    <section id="pricing" className="py-24 relative bg-[#070A12]">
      {/* Background Accent glow */}
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 w-[500px] h-[500px] bg-cyan-500/10 rounded-full blur-[150px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-900 border border-emerald-500/30 text-emerald-300 text-xs font-mono font-semibold uppercase tracking-wider mb-4">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            TRANSPARENT PRICING
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight font-['Space_Grotesk'] mb-4">
            Simple Plans for <span className="text-gradient-cyan">Infinite Scale</span>
          </h2>
          <p className="text-slate-400 text-base sm:text-lg">
            Start with zero upfront commitment. Scale seamlessly from prototype to globally distributed enterprise matrix.
          </p>

          {/* Billing Toggle Switch */}
          <div className="mt-8 inline-flex items-center gap-3 bg-slate-900/90 border border-slate-800 p-1.5 rounded-full backdrop-blur-md">
            <button
              onClick={() => setIsAnnual(false)}
              className={`px-5 py-2 rounded-full text-xs sm:text-sm font-bold transition-all ${
                !isAnnual ? 'bg-cyan-500 text-slate-950 shadow-lg shadow-cyan-500/20' : 'text-slate-400 hover:text-white'
              }`}
            >
              Monthly Billing
            </button>
            <button
              onClick={() => setIsAnnual(true)}
              className={`px-5 py-2 rounded-full text-xs sm:text-sm font-bold transition-all flex items-center gap-2 ${
                isAnnual ? 'bg-gradient-to-r from-cyan-400 to-indigo-500 text-slate-950 shadow-lg shadow-cyan-500/20' : 'text-slate-400 hover:text-white'
              }`}
            >
              Annual Billing
              <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-extrabold bg-slate-950 text-emerald-300 border border-emerald-400/30">
                SAVE 20%
              </span>
            </button>
          </div>
        </div>

        {/* 3 Pricing Cards Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-16">
          {PRICING_PLANS.map((plan) => {
            const price = isAnnual ? plan.annualPrice : plan.monthlyPrice;

            return (
              <div
                key={plan.id}
                className={`rounded-2xl p-8 flex flex-col justify-between relative transition-all duration-300 ${
                  plan.popular
                    ? 'glass-card border-2 border-cyan-400/80 shadow-2xl shadow-cyan-500/20 scale-105 bg-[#0C1222]'
                    : 'glass-card border border-slate-800 hover:border-slate-700 bg-slate-950/60'
                }`}
              >
                {/* Popular Badge */}
                {plan.popular && (
                  <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full bg-gradient-to-r from-cyan-400 to-purple-500 text-slate-950 font-bold text-xs uppercase font-mono shadow-lg flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5" />
                    {plan.badge}
                  </div>
                )}

                <div>
                  <h3 className="text-2xl font-bold text-white font-['Space_Grotesk'] mb-2">{plan.name}</h3>
                  <p className="text-xs text-slate-400 mb-6 leading-relaxed">{plan.tagline}</p>

                  <div className="mb-6 pb-6 border-b border-slate-800">
                    <div className="flex items-baseline gap-1">
                      <span className="text-3xl sm:text-4xl font-extrabold text-white font-mono">৳{price}</span>
                      <span className="text-xs text-slate-400 font-mono">/ month</span>
                    </div>
                    {isAnnual && (
                      <span className="text-[10px] font-mono text-emerald-400 block mt-1">Billed annually (৳{price * 12}/yr)</span>
                    )}
                  </div>

                  {/* Features List */}
                  <div className="space-y-3 mb-8">
                    <p className="text-xs font-mono font-semibold text-cyan-400 uppercase tracking-wider">INCLUDED CAPABILITIES:</p>
                    {plan.features.map((feature, idx) => (
                      <div key={idx} className="flex items-start gap-2.5 text-xs text-slate-300">
                        <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                        <span>{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* CTA Button */}
                <button
                  onClick={onOpenGetStarted}
                  className={`w-full py-3.5 rounded-xl font-bold text-xs transition-all duration-300 flex items-center justify-center gap-2 ${
                    plan.popular
                      ? 'bg-gradient-to-r from-cyan-400 to-indigo-400 hover:from-cyan-300 hover:to-indigo-300 text-slate-950 shadow-lg shadow-cyan-500/25'
                      : 'bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-700 hover:border-slate-500'
                  }`}
                >
                  {plan.ctaText}
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            );
          })}
        </div>

        {/* Interactive Price Estimator Calculator */}
        <div className="glass-card rounded-2xl p-6 sm:p-8 border border-slate-700/80 max-w-4xl mx-auto">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            
            <div className="flex-1 space-y-3">
              <div className="flex items-center gap-2 text-xs font-mono text-cyan-400 uppercase font-semibold">
                <Sliders className="w-4 h-4" /> CUSTOM ESTIMATOR CALCULATOR
              </div>
              <h3 className="text-xl font-bold text-white font-['Space_Grotesk']">
                Estimate Monthly Infrastructure Usage
              </h3>
              <p className="text-xs text-slate-400">
                Adjust slider to compute predicted spatial API events and agent compute requirements.
              </p>

              {/* Slider Input */}
              <div className="pt-2">
                <div className="flex justify-between text-xs font-mono text-slate-300 mb-2">
                  <span>Target API Volume: <strong className="text-cyan-300">{customRequestsMillions} Million</strong> /mo</span>
                  <span>Max Latency Target: &lt;1.5ms</span>
                </div>
                <input
                  type="range"
                  min="0.5"
                  max="20"
                  step="0.5"
                  value={customRequestsMillions}
                  onChange={(e) => setCustomRequestsMillions(parseFloat(e.target.value))}
                  className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                />
              </div>
            </div>

            {/* Price Output */}
            <div className="bg-[#090D18] border border-slate-800 p-6 rounded-xl text-center min-w-[220px]">
              <span className="text-[10px] font-mono text-slate-400 uppercase block mb-1">PREDICTED MONTHLY COST</span>
              <div className="text-2xl sm:text-3xl font-extrabold font-mono text-cyan-400">
                ৳{calculateCustomPrice(customRequestsMillions).toLocaleString()}
                <span className="text-xs text-slate-400 font-normal"> BDT/mo</span>
              </div>
              <p className="text-[10px] font-mono text-emerald-400 mt-2">Includes 99.99% SLA & Support</p>
              <button
                onClick={onOpenGetStarted}
                className="mt-4 w-full py-2 rounded-lg bg-cyan-400/20 hover:bg-cyan-400/30 text-cyan-300 border border-cyan-400/40 text-xs font-bold font-mono transition-colors"
              >
                Reserve Quota
              </button>
            </div>

          </div>
        </div>

      </div>
    </section>
  );
};
