import React, { useState } from 'react';
import { X, Sparkles, Gift, Trophy, ArrowRight, Copy, Check, Flame } from 'lucide-react';
import { Coupon } from '../types';

interface LuckySpinModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyCoupon: (couponCode: string) => void;
}

interface SpinSegment {
  label: string;
  code: string;
  discountDesc: string;
  color: string;
  textColor: string;
}

const SEGMENTS: SpinSegment[] = [
  { label: '১০% ছাড়', code: 'SPIN10', discountDesc: '10% Instant Discount on All Products', color: '#10B981', textColor: '#022C22' },
  { label: '২০০৳ ক্যাশব্যাক', code: 'LUCKY200', discountDesc: '200 BDT Flat Cashback Voucher', color: '#F59E0B', textColor: '#451A03' },
  { label: 'ফ্রি ডেলিভারি', code: 'FREESHIP', discountDesc: 'Free Home Delivery across Bangladesh', color: '#06B6D4', textColor: '#083344' },
  { label: '১৫% স্পেশাল', code: 'SUPER15', discountDesc: '15% Mega Discount Coupon', color: '#8B5CF6', textColor: '#2E1065' },
  { label: '৫০৳ ছাড়', code: 'WIN50', discountDesc: '50 BDT Instant Cart Discount', color: '#EC4899', textColor: '#500724' },
  { label: '৫% বোনাস', code: 'BONUS5', discountDesc: '5% Extra Cart Discount', color: '#3B82F6', textColor: '#172554' },
];

export const LuckySpinModal: React.FC<LuckySpinModalProps> = ({
  isOpen,
  onClose,
  onApplyCoupon
}) => {
  const [isSpinning, setIsSpinning] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [winningSegment, setWinningSegment] = useState<SpinSegment | null>(null);
  const [copied, setCopied] = useState(false);
  const [hasSpun, setHasSpun] = useState(false);

  if (!isOpen) return null;

  const handleSpin = () => {
    if (isSpinning) return;
    setIsSpinning(true);
    setWinningSegment(null);

    // Pick random segment
    const selectedIndex = Math.floor(Math.random() * SEGMENTS.length);
    const segmentAngle = 360 / SEGMENTS.length;
    // Extra full spins (5 to 8 rotations) + targeted angle
    const extraSpins = 360 * (5 + Math.floor(Math.random() * 3));
    // calculate target rotation such that pointer at top points to the winning segment
    const targetAngle = extraSpins + (360 - (selectedIndex * segmentAngle + segmentAngle / 2));
    
    const finalRotation = rotation + targetAngle;
    setRotation(finalRotation);

    setTimeout(() => {
      setIsSpinning(false);
      setWinningSegment(SEGMENTS[selectedIndex]);
      setHasSpun(true);
    }, 4000);
  };

  const handleCopyCode = () => {
    if (!winningSegment) return;
    navigator.clipboard.writeText(winningSegment.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleApplyAndClose = () => {
    if (winningSegment) {
      onApplyCoupon(winningSegment.code);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-md rounded-3xl bg-[#090D18] border border-amber-500/40 shadow-2xl shadow-amber-500/10 overflow-hidden flex flex-col items-center p-6 text-center">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full bg-slate-800/80 text-slate-400 hover:text-white transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Title Badge */}
        <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-300 font-mono text-xs font-bold mb-2">
          <Flame className="w-4 h-4 text-amber-400 animate-bounce" />
          <span>LUCKY SPIN & WIN (লাকি স্পিন)</span>
        </div>

        <h3 className="text-xl sm:text-2xl font-black text-white font-['Space_Grotesk']">
          স্পিন করুন এবং আকর্ষণীয় ডিসকাউন্ট জিতুন!
        </h3>
        <p className="text-xs text-slate-400 mt-1 max-w-xs">
          চাকা ঘুরিয়ে যেকোনো একটি এক্সক্লুসিভ ভাউচার কোড জিতে নিন এবং চেকআউটে ব্যবহার করুন।
        </p>

        {/* Wheel Container */}
        <div className="relative my-6 w-64 h-64 sm:w-72 sm:h-72 flex items-center justify-center">
          
          {/* Wheel Outer Ring */}
          <div className="absolute inset-0 rounded-full border-4 border-amber-400/80 shadow-[0_0_25px_rgba(251,191,36,0.35)] flex items-center justify-center p-1 bg-slate-900">
            
            {/* Rotating SVG Wheel */}
            <svg
              viewBox="0 0 200 200"
              className="w-full h-full rounded-full transition-transform duration-[4000ms] ease-out"
              style={{ transform: `rotate(${rotation}deg)` }}
            >
              {SEGMENTS.map((seg, i) => {
                const angle = 360 / SEGMENTS.length;
                const startAngle = i * angle;
                const endAngle = (i + 1) * angle;

                const startRad = (startAngle - 90) * (Math.PI / 180);
                const endRad = (endAngle - 90) * (Math.PI / 180);

                const x1 = 100 + 100 * Math.cos(startRad);
                const y1 = 100 + 100 * Math.sin(startRad);
                const x2 = 100 + 100 * Math.cos(endRad);
                const y2 = 100 + 100 * Math.sin(endRad);

                const pathData = `M 100 100 L ${x1} ${y1} A 100 100 0 0 1 ${x2} ${y2} Z`;

                const midAngle = startAngle + angle / 2;
                const midRad = (midAngle - 90) * (Math.PI / 180);
                const textX = 100 + 65 * Math.cos(midRad);
                const textY = 100 + 65 * Math.sin(midRad);

                return (
                  <g key={i}>
                    <path
                      d={pathData}
                      fill={seg.color}
                      stroke="#090D18"
                      strokeWidth="2"
                    />
                    <text
                      x={textX}
                      y={textY}
                      fill={seg.textColor}
                      fontSize="10"
                      fontWeight="bold"
                      textAnchor="middle"
                      dominantBaseline="central"
                      transform={`rotate(${midAngle + 90}, ${textX}, ${textY})`}
                    >
                      {seg.label}
                    </text>
                  </g>
                );
              })}
            </svg>

          </div>

          {/* Center Pin & Spin Button */}
          <button
            type="button"
            onClick={handleSpin}
            disabled={isSpinning}
            className="absolute z-20 w-16 h-16 rounded-full bg-gradient-to-tr from-amber-500 to-yellow-300 text-slate-950 font-black font-['Space_Grotesk'] text-xs flex flex-col items-center justify-center shadow-lg shadow-amber-500/50 hover:scale-105 active:scale-95 transition-transform border-2 border-white disabled:opacity-80"
          >
            <span>{isSpinning ? 'SPINNING' : 'SPIN'}</span>
            <Sparkles className="w-3.5 h-3.5" />
          </button>

          {/* Pointer Needle at Top */}
          <div className="absolute -top-3 left-1/2 -translate-x-1/2 z-30 w-0 h-0 border-l-[10px] border-l-transparent border-r-[10px] border-r-transparent border-t-[20px] border-t-amber-400 filter drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]"></div>

        </div>

        {/* Winning Result Display */}
        {winningSegment && !isSpinning && (
          <div className="w-full p-4 rounded-2xl bg-gradient-to-r from-amber-500/10 via-yellow-500/20 to-amber-500/10 border border-amber-500/50 space-y-2.5 animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-center gap-1.5 text-amber-400 font-bold text-sm">
              <Trophy className="w-5 h-5" />
              <span>অভিনন্দন! আপনি জিতেছেন: {winningSegment.label}</span>
            </div>
            
            <p className="text-xs text-slate-300">
              {winningSegment.discountDesc}
            </p>

            <div className="flex items-center justify-center gap-2">
              <div className="px-4 py-2 rounded-xl bg-slate-950 border border-amber-500/40 text-amber-300 font-mono font-black text-sm tracking-wider">
                {winningSegment.code}
              </div>
              <button
                type="button"
                onClick={handleCopyCode}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-mono flex items-center gap-1 transition-all"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                <span>{copied ? 'Copied!' : 'Copy'}</span>
              </button>
            </div>

            <button
              type="button"
              onClick={handleApplyAndClose}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 hover:to-yellow-300 text-slate-950 font-black text-xs font-mono flex items-center justify-center gap-1.5 transition-all shadow-md"
            >
              <span>কুপন অ্যাপ্লাই করে কেনাকাটা করুন (Apply & Shop)</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}

        {!winningSegment && !isSpinning && (
          <button
            type="button"
            onClick={handleSpin}
            className="w-full py-3 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 hover:from-amber-400 hover:to-yellow-300 text-slate-950 font-black text-sm font-['Space_Grotesk'] flex items-center justify-center gap-2 shadow-lg shadow-amber-500/25 transition-all hover:scale-[1.02]"
          >
            <Gift className="w-4 h-4" />
            <span>এখনই স্পিন করুন (Spin the Wheel)</span>
          </button>
        )}

      </div>
    </div>
  );
};
