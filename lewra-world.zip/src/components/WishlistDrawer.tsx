import React from 'react';
import { Product } from '../types';
import { X, Heart, ShoppingBag, Trash2, ArrowRight, Sparkles, Star, AlertTriangle, Check } from 'lucide-react';

interface WishlistDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  wishlistIds: string[];
  products: Product[];
  onToggleWishlist: (productId: string | Product) => void;
  onClearWishlist?: () => void;
  onAddToCart: (product: Product, quantity?: number, selectedColor?: string, selectedSpec?: string) => void;
  onOpenProductDetail?: (product: Product) => void;
}

export const WishlistDrawer: React.FC<WishlistDrawerProps> = ({
  isOpen,
  onClose,
  wishlistIds,
  products,
  onToggleWishlist,
  onClearWishlist,
  onAddToCart,
  onOpenProductDetail
}) => {
  if (!isOpen) return null;

  const wishlistProducts = products.filter(p => wishlistIds.includes(p.id));

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="absolute inset-0 bg-black/75 backdrop-blur-sm transition-opacity animate-in fade-in duration-200"
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-[#090D18] border-l border-slate-800 shadow-2xl flex flex-col animate-in slide-in-from-right duration-300">
          
          {/* Header */}
          <div className="p-4 sm:p-5 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400 shrink-0">
                <Heart className="w-5 h-5 fill-rose-500 text-rose-500" />
              </div>
              <div>
                <h2 className="text-base sm:text-lg font-bold text-white font-['Space_Grotesk'] flex items-center gap-2">
                  My Wishlist (পছন্দের তালিকা)
                  <span className="text-xs px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 font-mono font-bold">
                    {wishlistProducts.length}
                  </span>
                </h2>
                <p className="text-xs text-slate-400">
                  আপনার বুকমার্ক করা গ্যাজেট ও হার্ডওয়্যার তালিকা
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1.5">
              {wishlistProducts.length > 0 && onClearWishlist && (
                <button
                  type="button"
                  onClick={onClearWishlist}
                  className="px-2.5 py-1 rounded-lg bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 border border-rose-500/30 text-[11px] font-mono transition-all"
                  title="Clear all wishlist items"
                >
                  Clear All
                </button>
              )}
              <button
                onClick={onClose}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Items List */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {wishlistProducts.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-4">
                <div className="w-16 h-16 rounded-full bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-400">
                  <Heart className="w-8 h-8 text-rose-400 stroke-1" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Your wishlist is empty</h3>
                  <p className="text-xs text-slate-400 mt-1 max-w-xs">
                    পছন্দের পণ্যের পাশের হার্ট (❤️) আইকনে ক্লিক করে সহজেই এখানে সেভ করে রাখতে পারবেন।
                  </p>
                </div>
                <button
                  type="button"
                  onClick={onClose}
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-rose-500 to-pink-600 hover:from-rose-400 text-white font-bold text-xs flex items-center gap-1.5 shadow-lg shadow-rose-500/20 transition-all"
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>Explore Store Products</span>
                </button>
              </div>
            ) : (
              wishlistProducts.map((product) => {
                const isOutOfStock = product.stock === 0;
                const isLowStock = product.stock > 0 && product.stock <= 5;

                return (
                  <div
                    key={product.id}
                    className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-slate-700 transition-all flex gap-3 group relative"
                  >
                    {/* Thumbnail */}
                    <div
                      onClick={() => onOpenProductDetail && onOpenProductDetail(product)}
                      className="w-20 h-20 rounded-xl overflow-hidden bg-slate-950 shrink-0 border border-slate-800 relative cursor-pointer"
                    >
                      <img
                        src={product.image}
                        alt={product.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=400&auto=format&fit=crop&q=80';
                        }}
                      />
                      {product.discountPercent && (
                        <span className="absolute top-1 left-1 px-1.5 py-0.5 rounded bg-rose-500 text-white text-[9px] font-mono font-extrabold">
                          -{product.discountPercent}%
                        </span>
                      )}
                    </div>

                    {/* Details */}
                    <div className="flex-1 flex flex-col justify-between min-w-0">
                      <div>
                        <div className="flex items-start justify-between gap-1">
                          <h4
                            onClick={() => onOpenProductDetail && onOpenProductDetail(product)}
                            className="text-xs font-bold text-white hover:text-cyan-300 transition-colors line-clamp-1 cursor-pointer font-['Space_Grotesk']"
                          >
                            {product.name}
                          </h4>
                          <button
                            type="button"
                            onClick={() => onToggleWishlist(product.id)}
                            className="p-1 text-slate-400 hover:text-rose-400 transition-colors shrink-0"
                            title="Remove from Wishlist"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        {/* Category & Rating */}
                        <div className="flex items-center gap-2 mt-0.5">
                          <span className="text-[10px] text-slate-400 font-mono truncate">{product.category}</span>
                          {product.averageRating && (
                            <span className="text-[10px] text-amber-400 flex items-center gap-0.5 font-mono">
                              <Star className="w-2.5 h-2.5 fill-amber-400" />
                              {product.averageRating}
                            </span>
                          )}
                        </div>

                        {/* Stock status */}
                        {isLowStock && (
                          <div className="text-[10px] text-amber-400 font-mono font-semibold mt-0.5 flex items-center gap-1">
                            <AlertTriangle className="w-2.5 h-2.5" />
                            <span>Only {product.stock} left in stock!</span>
                          </div>
                        )}
                      </div>

                      {/* Price & Action */}
                      <div className="flex items-center justify-between pt-1 mt-1 border-t border-slate-800/80">
                        <div className="font-mono">
                          <span className="text-xs font-bold text-emerald-400">
                            ৳{product.price.toLocaleString()}
                          </span>
                          {product.originalPrice && product.originalPrice > product.price && (
                            <span className="text-[10px] text-slate-500 line-through ml-1.5">
                              ৳{product.originalPrice.toLocaleString()}
                            </span>
                          )}
                        </div>

                        <button
                          type="button"
                          disabled={isOutOfStock}
                          onClick={() => {
                            const defaultColor = product.variants?.colors?.[0]?.name;
                            const defaultSpec = product.variants?.specs?.[0];
                            onAddToCart(product, 1, defaultColor, defaultSpec);
                          }}
                          className={`px-2.5 py-1 rounded-lg text-xs font-mono font-bold flex items-center gap-1 transition-all ${
                            isOutOfStock
                              ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                              : 'bg-emerald-500/20 hover:bg-emerald-500 text-emerald-300 hover:text-slate-950 border border-emerald-500/40'
                          }`}
                        >
                          <ShoppingBag className="w-3 h-3" />
                          <span>{isOutOfStock ? 'Out of Stock' : 'Add to Cart'}</span>
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Footer Actions */}
          {wishlistProducts.length > 0 && (
            <div className="p-4 bg-slate-950 border-t border-slate-800 space-y-2">
              <button
                type="button"
                onClick={() => {
                  wishlistProducts.forEach(p => {
                    if (p.stock > 0) {
                      onAddToCart(p, 1);
                    }
                  });
                }}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-emerald-400 to-cyan-500 hover:from-emerald-300 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-lg shadow-emerald-500/20"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>Move All In-Stock Items to Cart</span>
              </button>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
