import React from 'react';
import { AboutInfo } from '../types';
import { ArrowRight, Play, Sparkles } from 'lucide-react';

interface HeroProps {
  aboutInfo?: AboutInfo;
  onOpenGetStarted: () => void;
  onOpenKeynote: () => void;
}

export const Hero: React.FC<HeroProps> = ({ aboutInfo, onOpenGetStarted, onOpenKeynote }) => {
  const titleText = aboutInfo?.heroTitle || 'Lewra World Tech & Hardware Ecosystem Platform';
  const subtitleText = aboutInfo?.heroSubtitle || 'Discover cutting-edge spatial devices, premium hardware tech, and high-performance digital tools engineered for the future of interactive computing.';

  return (
    <section className="relative pt-32 pb-20 md:pt-44 md:pb-32 overflow-hidden bg-black bg-grid-pattern">
      {/* Background Subtle Glow Orbs */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-white/[0.03] rounded-full blur-[140px] pointer-events-none animate-pulse-glow" />
      <div className="absolute top-1/3 right-10 w-[450px] h-[450px] bg-sky-500/[0.05] rounded-full blur-[150px] pointer-events-none" />
      <div className="absolute bottom-10 left-10 w-[400px] h-[400px] bg-purple-500/[0.05] rounded-full blur-[130px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Top Badge Announcement */}
        <div className="flex justify-center mb-6">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-zinc-900/90 border border-zinc-800 backdrop-blur-xl shadow-2xl hover:border-zinc-600 transition-all cursor-pointer group"
               onClick={onOpenGetStarted}>
            <span className="flex h-2 w-2 rounded-full bg-white animate-pulse" />
            <span className="text-xs font-semibold text-white font-mono tracking-wide">
              {aboutInfo?.heroTopBadgeText || 'LEWRA 3.0 SPATIAL CORE RELEASED'}
            </span>
            <span className="text-xs text-zinc-400 group-hover:text-white flex items-center gap-0.5">
              Explore Specs <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
            </span>
          </div>
        </div>

        {/* Main Headline & Subtitle */}
        <div className="text-center max-w-4xl mx-auto">
          <h1 className="text-4xl sm:text-6xl md:text-7xl font-extrabold tracking-tight font-['Space_Grotesk'] text-white leading-[1.08] mb-6 whitespace-pre-line">
            {titleText.includes('\n') ? (
              titleText
            ) : (
              <>
                {titleText.split(' Tech')[0]} <br className="hidden sm:inline" />
                <span className="text-gradient-primary drop-shadow-sm">
                  {titleText.includes('Tech') ? `Tech${titleText.split('Tech')[1] || ''}` : ''}
                </span>
              </>
            )}
          </h1>
          
          <p className="text-lg sm:text-xl text-zinc-300 max-w-2xl mx-auto font-normal leading-relaxed mb-10 whitespace-pre-line">
            {subtitleText}
          </p>

          {/* Dual Action Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-10">
            <button
              onClick={onOpenGetStarted}
              className="w-full sm:w-auto px-8 py-4 rounded-xl text-sm font-bold text-black bg-white hover:bg-zinc-200 transition-all duration-300 shadow-xl shadow-white/10 transform hover:-translate-y-0.5 flex items-center justify-center gap-2 group border border-white/20"
            >
              <Sparkles className="w-4 h-4 text-black group-hover:rotate-12 transition-transform" />
              Launch Lewra Workspace
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>

            {aboutInfo?.enableKeynote && (
              <button
                onClick={onOpenKeynote}
                className="w-full sm:w-auto px-8 py-4 rounded-xl text-sm font-semibold text-white bg-zinc-900/90 hover:bg-zinc-800 border border-zinc-800 hover:border-zinc-700 transition-all duration-300 backdrop-blur-md flex items-center justify-center gap-2 group shadow-lg"
              >
                <div className="w-6 h-6 rounded-full bg-white/10 flex items-center justify-center text-white group-hover:bg-white group-hover:text-black transition-colors">
                  <Play className="w-3 h-3 fill-current ml-0.5" />
                </div>
                Watch Keynote Demo
              </button>
            )}
          </div>
        </div>

        {/* Product Showcase Canvas */}
        {!aboutInfo?.hideHeroShowcase && (
          <div className="mt-8 relative max-w-5xl mx-auto">
            {/* Glass Card Container */}
            <div className="relative rounded-2xl glass-card border border-zinc-800 p-2 sm:p-4 shadow-2xl overflow-hidden group">
              
              {/* Top Window Bar */}
              {(!aboutInfo?.hideHeroWorkspaceTitle || !aboutInfo?.hideHeroSystemStatus) && (
                <div className="flex items-center justify-between px-4 py-3 bg-zinc-950 rounded-xl mb-3 border border-zinc-800/80">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-red-500/80" />
                    <div className="w-3 h-3 rounded-full bg-yellow-500/80" />
                    <div className="w-3 h-3 rounded-full bg-emerald-500/80" />
                    {!aboutInfo?.hideHeroWorkspaceTitle && (
                      <span className="text-xs font-mono text-zinc-300 ml-2 hidden sm:inline font-semibold">
                        {aboutInfo?.heroWorkspaceTitle || 'Lewra World Workspace'}
                      </span>
                    )}
                  </div>
                  {!aboutInfo?.hideHeroSystemStatus && (
                    <span className="text-xs font-mono text-zinc-300 flex items-center gap-1.5 font-semibold">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                      {aboutInfo?.heroSystemStatus || 'System Active'}
                    </span>
                  )}
                </div>
              )}

              {/* Visual Screen Canvas */}
              <div className="relative rounded-xl overflow-hidden aspect-[16/9] sm:aspect-[21/9] md:aspect-[16/8] border border-zinc-800 bg-black">
                {/* Background Showcase Image */}
                <img
                  src={aboutInfo?.heroShowcaseImage || "/src/assets/images/lewra_hero_3d_1785996301280.jpg"}
                  alt={aboutInfo?.heroShowcaseAlt || "Lewra World Products & Ecosystem"}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover opacity-90 group-hover:scale-105 transition-transform duration-700"
                />

                {/* Overlay Gradient */}
                <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black/30" />
              </div>

            </div>
          </div>
        )}

      </div>
    </section>
  );
};
