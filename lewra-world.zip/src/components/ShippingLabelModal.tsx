import React from 'react';
import { Order, AboutInfo } from '../types';
import { X, Printer, Package, Truck, Phone, MapPin, CheckCircle, ShieldAlert } from 'lucide-react';

interface ShippingLabelModalProps {
  isOpen: boolean;
  onClose: () => void;
  order: Order | null;
  aboutInfo: AboutInfo;
}

export const ShippingLabelModal: React.FC<ShippingLabelModalProps> = ({
  isOpen,
  onClose,
  order,
  aboutInfo
}) => {
  if (!isOpen || !order) return null;

  const handlePrint = () => {
    window.print();
  };

  const isCOD = order.paymentMethod?.toLowerCase().includes('cash') || (order.dueAmount && order.dueAmount > 0);
  const codAmount = order.dueAmount !== undefined ? order.dueAmount : (isCOD ? order.totalAmount : 0);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md overflow-y-auto print:p-0 print:bg-white print:static">
      <div className="relative w-full max-w-xl rounded-2xl bg-[#0B0F1C] border border-cyan-500/40 shadow-2xl overflow-hidden flex flex-col my-auto print:max-w-none print:border-none print:shadow-none print:bg-white print:text-black">
        
        {/* Modal Controls (Hidden in Print) */}
        <div className="p-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between print:hidden">
          <div className="flex items-center gap-2">
            <Package className="w-5 h-5 text-cyan-400" />
            <h3 className="font-bold text-white text-sm font-['Space_Grotesk']">
              পার্সেল শিপিং স্টিকার (Shipping Label Print)
            </h3>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-3.5 py-1.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold font-mono text-xs flex items-center gap-1.5 transition-all shadow-md"
            >
              <Printer className="w-4 h-4" />
              <span>Print Label (প্রিন্ট করুন)</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Label Area */}
        <div id="shipping-label-printable" className="p-6 bg-white text-slate-900 space-y-4 print:p-0">
          
          {/* Label Header */}
          <div className="flex items-center justify-between border-b-2 border-slate-900 pb-3">
            <div>
              <h2 className="text-xl font-black uppercase tracking-tight text-slate-900 font-['Space_Grotesk']">
                {aboutInfo.companyName || 'LEWRA WORLD'}
              </h2>
              <p className="text-[11px] text-slate-600 font-mono">
                Hotline: {aboutInfo.phone || '+880 1700-000000'} • {aboutInfo.address || 'Dhaka, Bangladesh'}
              </p>
            </div>
            <div className="text-right">
              <span className="px-2.5 py-1 rounded bg-slate-900 text-white font-mono font-bold text-xs">
                {order.trackingCourier || (order.deliveryZone === 'inside' ? 'DHAKA EXPRESS' : 'STEADFAST / PATHAO')}
              </span>
              <div className="text-[10px] text-slate-600 font-mono mt-1">
                Date: {new Date(order.createdAt).toLocaleDateString('en-GB')}
              </div>
            </div>
          </div>

          {/* Barcode Mock & Order Tracking ID */}
          <div className="p-3 bg-slate-50 border border-slate-300 rounded-lg flex items-center justify-between">
            <div>
              <span className="text-[10px] uppercase font-mono text-slate-500 font-bold block">
                ORDER ID / TRACKING CODE
              </span>
              <span className="text-lg font-mono font-black text-slate-900">
                #{order.id}
              </span>
            </div>
            
            {/* Barcode visual lines */}
            <div className="flex flex-col items-center">
              <div className="flex items-center gap-[2px] h-8">
                {[3, 1, 2, 4, 1, 3, 2, 1, 4, 2, 1, 3, 1, 2, 4, 1, 2, 3, 2, 1, 3].map((w, i) => (
                  <div
                    key={i}
                    className="bg-slate-900 h-full"
                    style={{ width: `${w * 1.5}px` }}
                  />
                ))}
              </div>
              <span className="text-[9px] font-mono tracking-widest text-slate-600">
                *{order.id.replace(/[^a-zA-Z0-9]/g, '')}*
              </span>
            </div>
          </div>

          {/* Recipient Details */}
          <div className="grid grid-cols-2 gap-3 border border-slate-300 rounded-lg p-3.5">
            <div className="space-y-1.5 border-r border-slate-200 pr-2">
              <span className="text-[10px] font-mono uppercase text-slate-500 font-bold block">
                DELIVER TO (প্রাপক):
              </span>
              <div className="font-black text-base text-slate-900">
                {order.customerName}
              </div>
              <div className="text-xs font-mono font-bold text-slate-800 flex items-center gap-1">
                <Phone className="w-3.5 h-3.5 text-slate-600" />
                <span>{order.customerPhone || 'N/A'}</span>
              </div>
              <div className="text-xs text-slate-700 leading-relaxed flex items-start gap-1">
                <MapPin className="w-3.5 h-3.5 text-slate-600 shrink-0 mt-0.5" />
                <span>{order.shippingAddress || 'Address not provided'}</span>
              </div>
            </div>

            <div className="space-y-2 pl-2 flex flex-col justify-between">
              <div>
                <span className="text-[10px] font-mono uppercase text-slate-500 font-bold block">
                  PAYMENT & COLLECTION:
                </span>
                
                {codAmount > 0 ? (
                  <div className="p-2 rounded bg-amber-100 border border-amber-300 mt-1">
                    <span className="text-[10px] uppercase font-mono font-bold text-amber-900 block">
                      CASH ON DELIVERY (COD):
                    </span>
                    <span className="text-lg font-black font-mono text-amber-950">
                      ৳{codAmount.toLocaleString()} BDT
                    </span>
                  </div>
                ) : (
                  <div className="p-2 rounded bg-emerald-100 border border-emerald-300 mt-1">
                    <span className="text-[10px] uppercase font-mono font-bold text-emerald-900 block">
                      PAYMENT STATUS:
                    </span>
                    <span className="text-sm font-black font-mono text-emerald-950">
                      ✓ FULLY PAID ({order.paymentMethod || 'Online'})
                    </span>
                  </div>
                )}
              </div>

              <div className="text-[10px] font-mono text-slate-500">
                Zone: <span className="font-bold text-slate-800">{order.deliveryZone === 'inside' ? 'Inside Dhaka' : 'Outside Dhaka'}</span>
              </div>
            </div>
          </div>

          {/* Itemized Summary */}
          <div className="border border-slate-300 rounded-lg p-3 text-xs space-y-1.5">
            <span className="text-[10px] font-mono uppercase text-slate-500 font-bold block">
              PARCEL CONTENTS ({order.items.length} Items):
            </span>
            <div className="space-y-1">
              {order.items.map((it, idx) => (
                <div key={idx} className="flex justify-between text-slate-800 text-[11px]">
                  <span>• {it.productName} {[it.selectedColor, it.selectedSize].filter(Boolean).join('/')} (x{it.quantity})</span>
                  <span className="font-mono font-bold">৳{(it.price * it.quantity).toLocaleString()}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Footer Instruction */}
          <div className="text-[10px] text-slate-500 border-t border-slate-200 pt-2 flex items-center justify-between">
            <span>কুরিয়ার সতর্কবার্তা: অনুগ্রহ করে পার্সেলটি সাবধানে হ্যান্ডেল করুন।</span>
            <span className="font-mono font-bold">Authorized Dispatch</span>
          </div>

        </div>

      </div>
    </div>
  );
};
