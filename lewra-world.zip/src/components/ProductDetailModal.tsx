import React, { useState } from 'react';
import { Product, AboutInfo, ProductReview } from '../types';
import { 
  X, 
  ChevronLeft, 
  ChevronRight, 
  Play, 
  Image as ImageIcon, 
  ShoppingBag, 
  ShoppingCart, 
  Check, 
  ShieldCheck, 
  Truck, 
  RotateCcw, 
  Flame, 
  Clock, 
  Package, 
  Layers,
  Sparkles,
  Share2,
  CheckCircle2,
  Star,
  Heart,
  MessageSquarePlus,
  ThumbsUp,
  AlertTriangle
} from 'lucide-react';
import { isProductDiscountActive, getRemainingTime } from '../utils/discountUtils';

interface ProductDetailModalProps {
  product: Product | null;
  aboutInfo?: AboutInfo;
  isOpen: boolean;
  onClose: () => void;
  onAddToCart: (product: Product, quantity?: number, selectedColor?: string, selectedSpec?: string) => void;
  onBuyNow: (product: Product, quantity?: number, selectedColor?: string, selectedSpec?: string) => void;
  addedProductId?: string | null;
  reviews?: ProductReview[];
  onAddReview?: (review: Omit<ProductReview, 'id' | 'createdAt'>) => void;
  isWishlisted?: boolean;
  onToggleWishlist?: (product: Product) => void;
}

const getEmbedVideoUrl = (url?: string) => {
  if (!url) return null;
  const cleanUrl = url.trim();
  if (cleanUrl.includes('youtube.com/watch?v=')) {
    const videoId = cleanUrl.split('v=')[1]?.split('&')[0];
    return `https://www.youtube.com/embed/${videoId}?autoplay=1`;
  }
  if (cleanUrl.includes('youtu.be/')) {
    const videoId = cleanUrl.split('youtu.be/')[1]?.split('?')[0];
    return `https://www.youtube.com/embed/${videoId}?autoplay=1`;
  }
  return cleanUrl;
};

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  aboutInfo,
  isOpen,
  onClose,
  onAddToCart,
  onBuyNow,
  addedProductId,
  reviews = [],
  onAddReview,
  isWishlisted = false,
  onToggleWishlist
}) => {
  const [selectedMediaIndex, setSelectedMediaIndex] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [copiedLink, setCopiedLink] = useState(false);

  // Variant selections
  const [selectedColor, setSelectedColor] = useState<string>(() => {
    return product?.variants?.find(v => v.type === 'color')?.options[0]?.name || '';
  });
  const [selectedSpec, setSelectedSpec] = useState<string>(() => {
    return product?.variants?.find(v => v.type === 'spec' || v.type === 'size')?.options[0]?.name || '';
  });

  // Review Form State
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [reviewerName, setReviewerName] = useState('');
  const [reviewerRating, setReviewerRating] = useState(5);
  const [reviewerComment, setReviewerComment] = useState('');
  const [reviewSubmitted, setReviewSubmitted] = useState(false);

  if (!isOpen || !product) return null;

  // Filter reviews for current product
  const productReviews = reviews.filter(r => r.productId === product.id);
  const avgRating = productReviews.length > 0 
    ? (productReviews.reduce((sum, r) => sum + r.rating, 0) / productReviews.length).toFixed(1)
    : (product.rating || 4.9).toFixed(1);

  // Build full media list: Images + Videos
  const allImages = Array.from(new Set([product.image, ...(product.images || [])].filter(Boolean)));
  const allVideos = Array.from(new Set([product.videoUrl, ...(product.videoUrls || [])].filter(Boolean))) as string[];

  type MediaItem = { type: 'image'; url: string } | { type: 'video'; url: string };

  const mediaList: MediaItem[] = [
    ...allImages.map(url => ({ type: 'image' as const, url })),
    ...allVideos.map(url => ({ type: 'video' as const, url }))
  ];

  const currentMedia = mediaList[selectedMediaIndex] || mediaList[0];

  const handlePrev = () => {
    setSelectedMediaIndex((prev) => (prev === 0 ? mediaList.length - 1 : prev - 1));
  };

  const handleNext = () => {
    setSelectedMediaIndex((prev) => (prev === mediaList.length - 1 ? 0 : prev + 1));
  };

  const handleShare = () => {
    try {
      if (navigator.clipboard) {
        navigator.clipboard.writeText(window.location.href);
        setCopiedLink(true);
        setTimeout(() => setCopiedLink(false), 2500);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reviewerName.trim() || !reviewerComment.trim()) return;

    if (onAddReview) {
      onAddReview({
        productId: product.id,
        userName: reviewerName.trim(),
        rating: reviewerRating,
        comment: reviewerComment.trim(),
        verifiedPurchase: true
      });
    }

    setReviewSubmitted(true);
    setTimeout(() => {
      setShowReviewForm(false);
      setReviewSubmitted(false);
      setReviewerName('');
      setReviewerComment('');
    }, 1800);
  };

  const discountActive = isProductDiscountActive(product);
  const discountPercent = product.discountPercent || (product.originalPrice && product.originalPrice > product.price ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100) : 0);
  const remaining = product.discountValidUntil ? getRemainingTime(product.discountValidUntil) : null;
  const chargeInside = aboutInfo?.deliveryChargeInsideDhaka ?? 60;
  const chargeOutside = aboutInfo?.deliveryChargeOutsideDhaka ?? 130;

  // Variants helpers
  const colorVariant = product.variants?.find(v => v.type === 'color');
  const specVariant = product.variants?.find(v => v.type === 'spec' || v.type === 'size');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 bg-black/90 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
      <div className="glass-card border border-zinc-800 max-w-4xl w-full rounded-2xl sm:rounded-3xl p-4 sm:p-6 md:p-8 relative shadow-2xl bg-zinc-950 text-white max-h-[92vh] overflow-y-auto custom-scrollbar my-auto">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2 rounded-xl bg-zinc-900/80 text-zinc-400 hover:text-white hover:bg-zinc-800 border border-zinc-700 transition-colors"
          title="Close"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-start">
          
          {/* LEFT: Interactive Media Showcase Gallery */}
          <div className="lg:col-span-6 space-y-3">
            
            {/* Main Stage Viewport */}
            <div className="relative aspect-square rounded-2xl overflow-hidden bg-black border border-zinc-800 shadow-xl group">
              {currentMedia?.type === 'image' ? (
                <img
                  src={currentMedia.url}
                  alt={product.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center bg-black">
                  {getEmbedVideoUrl(currentMedia?.url)?.includes('youtube.com/embed') ? (
                    <iframe
                      src={getEmbedVideoUrl(currentMedia.url)!}
                      title={`${product.name} Video`}
                      className="w-full h-full border-0"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen
                    />
                  ) : (
                    <video
                      src={currentMedia.url}
                      controls
                      autoPlay
                      className="w-full h-full object-contain"
                    />
                  )}
                </div>
              )}

              {/* Tag / Discount Badge */}
              <div className="absolute top-3 left-3 flex flex-col gap-1 z-10">
                {product.tag && (
                  <span className="px-2.5 py-1 rounded-full bg-black/95 border border-zinc-700 text-zinc-300 font-mono text-[10px] font-bold shadow-lg backdrop-blur-md">
                    {product.tag}
                  </span>
                )}
                {discountActive && (
                  <span className="px-2.5 py-1 rounded-full bg-rose-500 text-white font-mono text-[10px] font-black shadow-lg flex items-center gap-1 border border-rose-400/60">
                    <Flame className="w-3 h-3 fill-white text-white" />
                    {discountPercent}% OFF
                  </span>
                )}
              </div>

              {/* Wishlist Floating Button on Main Image */}
              {onToggleWishlist && (
                <button
                  type="button"
                  onClick={() => onToggleWishlist(product)}
                  className={`absolute top-3 right-3 z-10 p-2.5 rounded-xl backdrop-blur-md border transition-all duration-200 ${
                    isWishlisted
                      ? 'bg-rose-600 text-white border-rose-400 ring-2 ring-rose-400/50 shadow-lg shadow-rose-600/50 scale-105'
                      : 'bg-black/75 text-zinc-300 hover:text-white border-zinc-700 hover:border-rose-400/60 hover:bg-black/90'
                  }`}
                  title={isWishlisted ? 'Remove from Wishlist (পছন্দের তালিকা থেকে সরান)' : 'Add to Wishlist (পছন্দের তালিকায় রাখুন)'}
                >
                  <Heart className={`w-4 h-4 transition-transform ${isWishlisted ? 'fill-white text-white scale-110' : 'text-zinc-300'}`} />
                </button>
              )}

              {/* Gallery Navigation Arrows (if > 1 item) */}
              {mediaList.length > 1 && (
                <>
                  <button
                    onClick={handlePrev}
                    className="absolute left-3 top-1/2 -translate-y-1/2 p-2 rounded-full bg-black/85 hover:bg-zinc-800 text-white border border-zinc-700 transition-all opacity-80 group-hover:opacity-100 backdrop-blur-md shadow-lg"
                    title="Previous media"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <button
                    onClick={handleNext}
                    className="absolute right-3 top-1/2 -translate-y-1/2 p-2 rounded-full bg-black/85 hover:bg-zinc-800 text-white border border-zinc-700 transition-all opacity-80 group-hover:opacity-100 backdrop-blur-md shadow-lg"
                    title="Next media"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </>
              )}

              {/* Media Counter Indicator */}
              <div className="absolute bottom-3 right-3 px-2.5 py-1 rounded-full bg-black/90 text-zinc-300 border border-zinc-800 text-[10px] font-mono font-bold backdrop-blur-md">
                {selectedMediaIndex + 1} / {mediaList.length}
              </div>
            </div>

            {/* Thumbnail Strip */}
            {mediaList.length > 1 && (
              <div className="flex items-center gap-2 overflow-x-auto pb-1 custom-scrollbar">
                {mediaList.map((item, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setSelectedMediaIndex(idx)}
                    className={`relative w-16 h-16 rounded-xl overflow-hidden border-2 shrink-0 transition-all ${
                      selectedMediaIndex === idx
                        ? 'border-white ring-2 ring-white/30 scale-105'
                        : 'border-zinc-800 hover:border-zinc-700 opacity-70 hover:opacity-100'
                    }`}
                  >
                    {item.type === 'image' ? (
                      <img
                        src={item.url}
                        alt={`Thumbnail ${idx + 1}`}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full bg-zinc-900 flex flex-col items-center justify-center text-white">
                        <Play className="w-5 h-5 fill-white text-white" />
                        <span className="text-[9px] font-mono font-bold mt-0.5">Video</span>
                      </div>
                    )}
                  </button>
                ))}
              </div>
            )}

            {/* Media Count Summary */}
            <div className="flex items-center justify-between text-[11px] font-mono text-zinc-400 px-1">
              <span className="flex items-center gap-1.5">
                <ImageIcon className="w-3.5 h-3.5 text-white" />
                {allImages.length} {allImages.length > 1 ? 'Photos' : 'Photo'}
                {allVideos.length > 0 && (
                  <>
                    <span>•</span>
                    <Play className="w-3 h-3 text-white fill-white" />
                    {allVideos.length} {allVideos.length > 1 ? 'Videos' : 'Video'}
                  </>
                )}
              </span>
              <button
                onClick={handleShare}
                className="hover:text-white flex items-center gap-1 text-[11px] font-mono"
                title="Copy Product Link"
              >
                <Share2 className="w-3 h-3 text-zinc-400" />
                <span>{copiedLink ? 'Link Copied!' : 'Share'}</span>
              </button>
            </div>

          </div>

          {/* RIGHT: Product Details, Variants, Specs & Reviews */}
          <div className="lg:col-span-6 flex flex-col justify-between space-y-5">
            
            <div className="space-y-4">
              
              {/* Category, Rating & Low Stock Badge */}
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono text-zinc-300 uppercase tracking-wider font-semibold px-2.5 py-0.5 rounded-full bg-zinc-900 border border-zinc-800">
                    {product.category}
                  </span>
                  
                  {/* Rating Stars & Count */}
                  <div className="flex items-center gap-1 text-xs font-mono bg-zinc-900/90 px-2 py-0.5 rounded-full border border-zinc-800 text-amber-300 font-bold">
                    <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                    <span>{avgRating}</span>
                    <span className="text-zinc-500 font-normal">({productReviews.length || product.reviewsCount || 12})</span>
                  </div>
                </div>

                <span
                  className={`text-[11px] font-mono font-bold px-2 py-0.5 rounded border ${
                    product.stock > 5
                      ? 'bg-emerald-950/50 text-emerald-300 border-emerald-500/30'
                      : product.stock > 0
                      ? 'bg-amber-950/50 text-amber-300 border-amber-500/30'
                      : 'bg-rose-950/50 text-rose-400 border-rose-500/30 animate-pulse'
                  }`}
                >
                  {product.stock > 5
                    ? `Stock: ${product.stock} Units`
                    : product.stock > 0
                    ? `Only ${product.stock} Left In Stock`
                    : 'OUT OF STOCK (স্টক শেষ)'}
                </span>
              </div>

              {/* Low Stock Alert Urgency Banner */}
              {product.stock > 0 && product.stock <= 5 && (
                <div className="p-2.5 rounded-xl bg-amber-950/70 border border-amber-500/40 text-amber-200 text-xs font-mono flex items-center gap-2 animate-pulse">
                  <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>⚡ <strong>Limited Supply:</strong> Only {product.stock} units remaining in warehouse. Order now to secure priority shipment!</span>
                </div>
              )}

              {/* Product Title */}
              <h2 className="text-xl sm:text-2xl md:text-3xl font-extrabold text-white font-['Space_Grotesk'] leading-tight">
                {product.name}
              </h2>

              {/* Price & Offer Card */}
              <div className="p-4 sm:p-5 rounded-2xl bg-zinc-900 border border-zinc-800 space-y-2 shadow-xl">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-mono font-bold text-zinc-400 uppercase tracking-wider">
                    Official Selling Price (মূল্য)
                  </span>
                  <span
                    className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-md border ${
                      product.stock > 0
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                        : 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                    }`}
                  >
                    {product.stock > 0 ? `In Stock (${product.stock})` : 'Out of Stock'}
                  </span>
                </div>

                <div className="flex items-baseline gap-3 flex-wrap">
                  <span className="text-3xl sm:text-4xl md:text-5xl font-black text-white font-mono tracking-tight drop-shadow-md">
                    ৳{product.price.toLocaleString()}
                  </span>
                  {product.originalPrice && product.originalPrice > product.price && (
                    <span className="text-lg font-mono text-zinc-500 line-through">
                      ৳{product.originalPrice.toLocaleString()}
                    </span>
                  )}
                  {discountActive && (
                    <span className="px-2.5 py-1 rounded-lg bg-rose-950/60 text-rose-300 text-xs font-mono font-bold border border-rose-500/40 animate-pulse">
                      Save ৳{((product.originalPrice || 0) - product.price).toLocaleString()} BDT ({discountPercent}% OFF)
                    </span>
                  )}
                </div>

                {discountActive && remaining && !remaining.isExpired && (
                  <div className="flex items-center gap-1.5 text-xs text-amber-300 font-mono pt-1.5 border-t border-zinc-800">
                    <Clock className="w-3.5 h-3.5 text-amber-400 animate-spin" />
                    <span>Special Discount Valid for: <strong>{remaining.badgeText}</strong></span>
                  </div>
                )}
              </div>

              {/* PRODUCT VARIANTS: COLOR & SPECS SELECTOR */}
              {(colorVariant || specVariant) && (
                <div className="p-3.5 rounded-2xl bg-zinc-900 border border-zinc-800 space-y-3 font-mono text-xs">
                  {colorVariant && (
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between text-zinc-400 text-[11px]">
                        <span>SELECT COLOR / FINISH:</span>
                        <span className="text-white font-bold">{selectedColor || 'Standard'}</span>
                      </div>
                      <div className="flex items-center gap-2 flex-wrap">
                        {colorVariant.options.map((opt) => (
                          <button
                            key={opt.name}
                            type="button"
                            onClick={() => setSelectedColor(opt.name)}
                            className={`px-3 py-1.5 rounded-xl border flex items-center gap-1.5 transition-all ${
                              selectedColor === opt.name
                                ? 'bg-zinc-800 text-white border-white ring-2 ring-white/20 font-bold'
                                : 'bg-black/60 text-zinc-400 border-zinc-800 hover:border-zinc-600'
                            }`}
                          >
                            {opt.colorHex && (
                              <span
                                className="w-3 h-3 rounded-full border border-white/40"
                                style={{ backgroundColor: opt.colorHex }}
                              />
                            )}
                            <span>{opt.name}</span>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {specVariant && (
                    <div className="space-y-1.5 pt-2 border-t border-zinc-800/80">
                      <div className="flex items-center justify-between text-zinc-400 text-[11px]">
                        <span>SELECT HARDWARE SPECIFICATION:</span>
                        <span className="text-cyan-300 font-bold">{selectedSpec || 'Standard'}</span>
                      </div>
                      <div className="flex items-center gap-2 flex-wrap">
                        {specVariant.options.map((opt) => (
                          <button
                            key={opt.name}
                            type="button"
                            onClick={() => setSelectedSpec(opt.name)}
                            className={`px-3 py-1.5 rounded-xl border transition-all ${
                              selectedSpec === opt.name
                                ? 'bg-cyan-950 text-cyan-200 border-cyan-400 font-bold shadow-md shadow-cyan-950/50'
                                : 'bg-black/60 text-zinc-400 border-zinc-800 hover:border-zinc-600'
                            }`}
                          >
                            <span>{opt.name}</span>
                            {opt.priceModifier ? (
                              <span className="text-[10px] ml-1 text-zinc-400">(+৳{opt.priceModifier})</span>
                            ) : null}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Description */}
              <div className="space-y-2">
                <h4 className="text-xs font-mono font-bold text-zinc-300 uppercase tracking-wider">
                  Product Overview & Details (পণ্যের বিবরণ)
                </h4>
                <p className="text-xs sm:text-sm text-zinc-300 leading-relaxed whitespace-pre-line bg-zinc-900 p-3.5 rounded-xl border border-zinc-800">
                  {product.description || 'Premium quality verified product. Tested and guaranteed by our certified quality assurance engineers.'}
                </p>
              </div>

              {/* Delivery info pills */}
              <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                <div className="p-2.5 rounded-xl bg-zinc-900 border border-zinc-800 flex items-center gap-2">
                  <Truck className="w-4 h-4 text-white shrink-0" />
                  <div>
                    <span className="text-[10px] text-zinc-400 block">Dhaka Delivery</span>
                    <span className="text-zinc-200 font-bold">৳{chargeInside} (24-48h)</span>
                  </div>
                </div>
                <div className="p-2.5 rounded-xl bg-zinc-900 border border-zinc-800 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                  <div>
                    <span className="text-[10px] text-zinc-400 block">Quality Check</span>
                    <span className="text-zinc-200 font-bold">100% Genuine</span>
                  </div>
                </div>
              </div>

              {/* REVIEWS & RATINGS ACCORDION / SHOWCASE */}
              <div className="p-4 rounded-2xl bg-zinc-900 border border-zinc-800 space-y-3 font-mono text-xs">
                <div className="flex items-center justify-between border-b border-zinc-800 pb-2">
                  <div className="flex items-center gap-2">
                    <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                    <span className="font-bold text-white text-sm">Verified Customer Reviews ({productReviews.length})</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setShowReviewForm(!showReviewForm)}
                    className="text-xs text-amber-400 hover:text-amber-300 font-bold flex items-center gap-1"
                  >
                    <MessageSquarePlus className="w-3.5 h-3.5" />
                    <span>{showReviewForm ? 'Cancel' : 'Write a Review'}</span>
                  </button>
                </div>

                {/* Submit Review Form */}
                {showReviewForm && (
                  <form onSubmit={handleSubmitReview} className="p-3.5 rounded-xl bg-zinc-950 border border-amber-500/30 space-y-3 animate-in fade-in">
                    <div className="text-amber-300 font-bold text-xs">Write Your Experience:</div>

                    <div className="flex items-center gap-1 text-sm">
                      <span className="text-zinc-400 text-xs mr-2">Your Rating:</span>
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          type="button"
                          onClick={() => setReviewerRating(star)}
                          className="p-1 hover:scale-110 transition-transform"
                        >
                          <Star className={`w-5 h-5 ${star <= reviewerRating ? 'fill-amber-400 text-amber-400' : 'text-zinc-700'}`} />
                        </button>
                      ))}
                    </div>

                    <input
                      type="text"
                      value={reviewerName}
                      onChange={(e) => setReviewerName(e.target.value)}
                      placeholder="Your Full Name / City"
                      required
                      className="w-full px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-700 text-white text-xs focus:border-amber-400 focus:outline-none"
                    />

                    <textarea
                      value={reviewerComment}
                      onChange={(e) => setReviewerComment(e.target.value)}
                      placeholder="Tell us about the build quality, performance, and packaging..."
                      rows={2}
                      required
                      className="w-full px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-700 text-white text-xs focus:border-amber-400 focus:outline-none resize-none"
                    />

                    {reviewSubmitted ? (
                      <div className="p-2 bg-emerald-950 text-emerald-300 border border-emerald-500/40 rounded-lg text-center font-bold flex items-center justify-center gap-1.5">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        <span>Review posted successfully! Thank you.</span>
                      </div>
                    ) : (
                      <button
                        type="submit"
                        className="w-full py-2 bg-amber-500 hover:bg-amber-400 text-black font-extrabold rounded-lg transition-all"
                      >
                        Submit Verified Review
                      </button>
                    )}
                  </form>
                )}

                {/* Reviews List */}
                <div className="space-y-2.5 max-h-48 overflow-y-auto custom-scrollbar pr-1">
                  {productReviews.length === 0 ? (
                    <div className="p-3 bg-zinc-950 rounded-xl text-center text-zinc-500 text-xs">
                      No customer reviews yet. Be the first to review this product!
                    </div>
                  ) : (
                    productReviews.map((rev) => (
                      <div key={rev.id} className="p-3 rounded-xl bg-zinc-950 border border-zinc-800/80 space-y-1.5">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-white text-xs">{rev.userName}</span>
                            {rev.verifiedPurchase && (
                              <span className="px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-400 text-[9px] border border-emerald-500/30 flex items-center gap-0.5">
                                <Check className="w-2.5 h-2.5" /> Verified
                              </span>
                            )}
                          </div>
                          <div className="flex items-center gap-0.5">
                            {[...Array(5)].map((_, i) => (
                              <Star
                                key={i}
                                className={`w-3 h-3 ${i < rev.rating ? 'fill-amber-400 text-amber-400' : 'text-zinc-800'}`}
                              />
                            ))}
                          </div>
                        </div>
                        <p className="text-zinc-300 text-xs leading-relaxed font-sans">{rev.comment}</p>
                        <div className="text-[10px] text-zinc-600 pt-0.5">
                          {new Date(rev.createdAt).toLocaleDateString()}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>

            </div>

            {/* Quantity Selector & Action CTA Bottom Bar */}
            <div className="space-y-3 pt-4 border-t border-zinc-800 bg-zinc-900/80 p-4 rounded-2xl border border-zinc-800 shadow-2xl">
              
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div className="flex items-center gap-3">
                  <span className="text-xs font-mono text-zinc-300 font-bold">Quantity (পরিমাণ):</span>
                  <div className="flex items-center rounded-xl border border-zinc-700 bg-black overflow-hidden shadow-inner">
                    <button
                      type="button"
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      disabled={quantity <= 1}
                      className="px-3.5 py-2 text-zinc-400 hover:text-white disabled:opacity-30 transition-colors font-bold text-base"
                    >
                      -
                    </button>
                    <span className="px-3.5 py-2 text-sm font-mono font-bold text-white min-w-[2.5rem] text-center">
                      {quantity}
                    </span>
                    <button
                      type="button"
                      onClick={() => setQuantity(Math.min(product.stock || 99, quantity + 1))}
                      disabled={quantity >= (product.stock || 1)}
                      className="px-3.5 py-2 text-zinc-400 hover:text-white disabled:opacity-30 transition-colors font-bold text-base"
                    >
                      +
                    </button>
                  </div>
                </div>

                {/* Big Total Price Box */}
                <div className="text-right">
                  <span className="text-[10px] font-mono text-zinc-400 block">TOTAL PAYABLE:</span>
                  <div className="flex items-baseline gap-1">
                    <span className="text-2xl sm:text-3xl font-black text-white font-mono tracking-tight drop-shadow-md">
                      ৳{(product.price * quantity).toLocaleString()}
                    </span>
                    <span className="text-xs font-mono text-zinc-400 font-bold">BDT</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-12 gap-2 pt-1">
                {/* Wishlist Button */}
                {onToggleWishlist && (
                  <button
                    type="button"
                    onClick={() => onToggleWishlist(product)}
                    className={`col-span-3 py-3.5 px-2 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all border ${
                      isWishlisted
                        ? 'bg-rose-600/20 text-rose-300 border-rose-500/70 shadow-md shadow-rose-950/40 ring-1 ring-rose-500/30'
                        : 'bg-zinc-800 text-zinc-300 hover:text-white border-zinc-700 hover:border-zinc-500'
                    }`}
                    title={isWishlisted ? 'Remove from Wishlist' : 'Add to Wishlist'}
                  >
                    <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-rose-500 text-rose-500 scale-110' : 'text-zinc-400'}`} />
                    <span className="hidden sm:inline font-mono">{isWishlisted ? 'Saved' : 'Wishlist'}</span>
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => onAddToCart(product, quantity, selectedColor, selectedSpec)}
                  disabled={product.stock <= 0}
                  className={`${onToggleWishlist ? 'col-span-4' : 'col-span-6'} py-3.5 px-3 rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all border ${
                    addedProductId === product.id
                      ? 'bg-emerald-950/60 text-emerald-300 border-emerald-400/60 shadow-lg shadow-emerald-950/50'
                      : product.stock > 0
                      ? 'bg-zinc-800 text-zinc-200 hover:bg-zinc-700 border-zinc-700 hover:border-zinc-500 shadow-md'
                      : 'bg-zinc-900/40 text-zinc-600 border-zinc-800 cursor-not-allowed'
                  }`}
                >
                  {addedProductId === product.id ? (
                    <>
                      <Check className="w-4 h-4 text-emerald-400" />
                      <span>Added!</span>
                    </>
                  ) : (
                    <>
                      <ShoppingCart className="w-4 h-4 text-white" />
                      <span>Add to Cart</span>
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onBuyNow(product, quantity, selectedColor, selectedSpec);
                  }}
                  className={`${onToggleWishlist ? 'col-span-5' : 'col-span-6'} py-3.5 px-3 rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all shadow-lg ${
                    product.stock > 0
                      ? 'bg-white hover:bg-zinc-200 text-black shadow-white/10'
                      : 'bg-zinc-800 hover:bg-zinc-700 text-zinc-400'
                  }`}
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>{product.stock > 0 ? 'Buy Now' : 'Pre-Order'}</span>
                </button>
              </div>

            </div>

          </div>

        </div>

      </div>
    </div>
  );
};

