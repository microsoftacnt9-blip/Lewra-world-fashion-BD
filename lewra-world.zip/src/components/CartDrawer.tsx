import React, { useState, useEffect } from 'react';
import { Product, Order, Coupon, AboutInfo, UserAccount, CartItem } from '../types';
import { 
  ShoppingCart, 
  X, 
  Trash2, 
  Plus, 
  Minus, 
  ArrowRight, 
  Tag, 
  Percent, 
  Check, 
  Copy, 
  CreditCard, 
  Smartphone, 
  Truck, 
  ShoppingBag, 
  AlertCircle, 
  CheckCircle2, 
  User, 
  MapPin, 
  Phone, 
  Mail, 
  FileText,
  Clock,
  Flame,
  Lock
} from 'lucide-react';
import { 
  checkCouponValidity, 
  getRemainingTime, 
  copyCleanPhoneNumber, 
  extractCleanPhoneNumber,
  checkUserMonthlyCouponLimit,
  getUserMonthlyCouponUsage
} from '../utils/discountUtils';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  coupons?: Coupon[];
  aboutInfo?: AboutInfo;
  currentUser?: UserAccount | null;
  orders?: Order[];
  onUpdateQuantity: (productId: string, quantity: number) => void;
  onRemoveItem: (productId: string) => void;
  onClearCart: () => void;
  onPlaceOrder: (order: Order) => void;
  onOrderSuccess?: (order: Order) => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cart,
  coupons = [],
  aboutInfo,
  currentUser,
  orders = [],
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  onPlaceOrder,
  onOrderSuccess,
}) => {
  const [step, setStep] = useState<'cart' | 'checkout'>('cart');
  const [customerName, setCustomerName] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [shippingAddress, setShippingAddress] = useState('');
  const [notes, setNotes] = useState('');

  // Coupon state
  const [couponCode, setCouponCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(null);
  const [couponMsg, setCouponMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Payment method & Delivery state
  const [paymentMethod, setPaymentMethod] = useState<'bKash' | 'Nagad' | 'Rocket' | 'Cash on Delivery' | 'Card / Bank Transfer'>('bKash');
  const [paymentTrxId, setPaymentTrxId] = useState('');
  const [paymentSenderPhone, setPaymentSenderPhone] = useState('');
  const [advancePaymentInput, setAdvancePaymentInput] = useState<string>('');
  const [copiedNumber, setCopiedNumber] = useState<string | null>(null);
  const [deliveryZone, setDeliveryZone] = useState<'Inside Dhaka' | 'Outside Dhaka'>('Inside Dhaka');

  // Auto-fill customer details when logged in
  useEffect(() => {
    if (currentUser) {
      if (!customerName) setCustomerName(currentUser.name);
      if (!customerEmail) setCustomerEmail(currentUser.email);
      if (!customerPhone && currentUser.phone) setCustomerPhone(currentUser.phone);
    }
  }, [currentUser, isOpen]);

  // Reset to cart view when drawer opens with items
  useEffect(() => {
    if (isOpen) {
      setStep('cart');
      setCouponMsg(null);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const totalItemsCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const subtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);

  const chargeInside = aboutInfo?.deliveryChargeInsideDhaka ?? 60;
  const chargeOutside = aboutInfo?.deliveryChargeOutsideDhaka ?? 130;
  const deliveryCharge = deliveryZone === 'Inside Dhaka' ? chargeInside : chargeOutside;

  // Coupon enablement check
  const isCouponFeatureEnabled = aboutInfo?.enableCoupons !== false;
  const maxCouponLimit = aboutInfo?.maxCouponsPerUserPerMonth ?? 1;

  let discountAmount = 0;
  if (appliedCoupon && subtotal > 0 && isCouponFeatureEnabled) {
    if (appliedCoupon.discountPercent) {
      discountAmount = Math.round((subtotal * appliedCoupon.discountPercent) / 100);
    } else if (appliedCoupon.discountBDT) {
      discountAmount = Math.min(subtotal, appliedCoupon.discountBDT);
    }
  }

  const finalTotalAmount = Math.max(0, subtotal - discountAmount) + deliveryCharge;

  const effectiveAdvancePaid = advancePaymentInput !== ''
    ? Math.min(finalTotalAmount, Math.max(0, parseInt(advancePaymentInput) || 0))
    : (paymentMethod === 'Cash on Delivery' ? 0 : finalTotalAmount);
  const effectiveDueAmount = Math.max(0, finalTotalAmount - effectiveAdvancePaid);

  const handleApplyCoupon = () => {
    setCouponMsg(null);
    if (!couponCode.trim()) return;

    if (!isCouponFeatureEnabled) {
      setAppliedCoupon(null);
      setCouponMsg({ type: 'error', text: 'বর্তমানে স্টোরে কুপন অপশন বন্ধ রয়েছে (Coupons disabled by admin).' });
      return;
    }

    const clean = couponCode.trim().toUpperCase();
    const found = coupons.find(c => c.code.toUpperCase() === clean);
    if (found) {
      const check = checkCouponValidity(found);
      if (!check.isValid) {
        setAppliedCoupon(null);
        setCouponMsg({ type: 'error', text: check.message || 'এই কুপনটি বর্তমানে সক্রিয় নয়।' });
        return;
      }

      // Check monthly limit for user (1 per month)
      const userIdentifier = {
        email: customerEmail.trim() || currentUser?.email,
        phone: customerPhone.trim() || currentUser?.phone
      };

      const limitCheck = checkUserMonthlyCouponLimit(userIdentifier, orders, maxCouponLimit);
      if (!limitCheck.allowed) {
        setAppliedCoupon(null);
        setCouponMsg({
          type: 'error',
          text: limitCheck.message || `১ মাসে সর্বোচ্চ ${maxCouponLimit}টি কুপন ব্যবহার করা যাবে। আপনি এই মাসে ইতিমধ্যে কুপন ব্যবহার করেছেন।`
        });
        return;
      }

      setAppliedCoupon(found);
      const discountText = found.discountPercent ? `${found.discountPercent}% Discount` : `৳${found.discountBDT} BDT Discount`;
      const timeInfo = found.validUntil && getRemainingTime(found.validUntil)
        ? ` • ${getRemainingTime(found.validUntil)?.formattedText}`
        : '';
      setCouponMsg({ type: 'success', text: `কুপন '${found.code}' সফলভাবে যুক্ত হয়েছে! (${discountText}${timeInfo})` });
    } else {
      setAppliedCoupon(null);
      setCouponMsg({ type: 'error', text: 'অকার্যকর কুপন কোড (Invalid coupon code).' });
    }
  };

  const handleRemoveCoupon = () => {
    setAppliedCoupon(null);
    setCouponCode('');
    setCouponMsg(null);
  };

  const handleCopyNumber = (num: string) => {
    if (!num) return;
    const cleanDigits = copyCleanPhoneNumber(num);
    setCopiedNumber(cleanDigits);
    setTimeout(() => setCopiedNumber(null), 2500);
  };

  const handleCheckoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (cart.length === 0) return;

    if (!customerName.trim() || !customerPhone.trim() || !shippingAddress.trim()) {
      alert('Please fill in Name, Phone number, and Delivery Address.');
      return;
    }

    // Double check coupon monthly limit before finalizing order
    if (appliedCoupon) {
      const userIdentifier = {
        email: customerEmail.trim() || currentUser?.email,
        phone: customerPhone.trim() || currentUser?.phone
      };
      const limitCheck = checkUserMonthlyCouponLimit(userIdentifier, orders, maxCouponLimit);
      if (!limitCheck.allowed) {
        alert(limitCheck.message || 'আপনি এই মাসে ইতিমধ্যে ১টি কুপন ব্যবহার করেছেন!');
        return;
      }
    }

    const notesWithCoupon = appliedCoupon
      ? `${notes ? notes + ' | ' : ''}Coupon Applied: ${appliedCoupon.code} (-৳${discountAmount} BDT)`
      : notes;

    const newOrder: Order = {
      id: `ORD-${Math.floor(1000 + Math.random() * 9000)}`,
      customerName: customerName.trim(),
      customerEmail: customerEmail.trim() || (currentUser?.email || ''),
      customerPhone: customerPhone.trim(),
      shippingAddress: shippingAddress.trim(),
      items: cart.map(item => ({
        productId: item.product.id,
        productName: item.product.name,
        quantity: item.quantity,
        price: item.product.price
      })),
      totalAmount: finalTotalAmount,
      paymentMethod,
      paymentTrxId: paymentTrxId.trim() || undefined,
      paymentSenderPhone: paymentSenderPhone.trim() || customerPhone.trim(),
      deliveryZone: deliveryZone === 'Inside Dhaka' ? `Inside Dhaka (৳${chargeInside} BDT)` : `Outside Dhaka (৳${chargeOutside} BDT)`,
      deliveryCharge,
      advancePaid: effectiveAdvancePaid,
      dueAmount: effectiveDueAmount,
      couponCode: appliedCoupon ? appliedCoupon.code : undefined,
      couponDiscount: appliedCoupon ? discountAmount : undefined,
      status: 'Pending',
      createdAt: new Date().toISOString(),
      notes: notesWithCoupon
    };

    onPlaceOrder(newOrder);
    onClearCart();
    onClose();
    if (onOrderSuccess) {
      onOrderSuccess(newOrder);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div 
        onClick={onClose}
        className="absolute inset-0 bg-[#0E0A07]/85 backdrop-blur-sm transition-opacity animate-in fade-in"
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md sm:max-w-lg bg-[#140E0A] border-l border-[#3D2B22] text-[#FFF8F2] shadow-2xl flex flex-col justify-between animate-in slide-in-from-right duration-300">
          
          {/* Header */}
          <div className="p-5 border-b border-[#3D2B22] flex items-center justify-between bg-[#1C1410]/95 backdrop-blur-md">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#281D17] border border-[#523A2E] flex items-center justify-center text-[#D4A373]">
                <ShoppingCart className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-lg font-['Space_Grotesk'] text-[#FFF8F2] flex items-center gap-2">
                  <span>Shopping Cart</span>
                  {totalItemsCount > 0 && (
                    <span className="px-2 py-0.5 rounded-full bg-gradient-to-r from-[#D4A373] to-[#E6CCB2] text-[#140E0A] text-xs font-mono font-bold">
                      {totalItemsCount} {totalItemsCount === 1 ? 'item' : 'items'}
                    </span>
                  )}
                </h3>
                <p className="text-xs text-[#CBB5A1]">
                  {step === 'cart' ? 'Review your selected items' : 'Complete customer checkout details'}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {cart.length > 0 && step === 'cart' && (
                <button
                  onClick={onClearCart}
                  className="p-2 rounded-lg text-[#A88B77] hover:text-rose-400 hover:bg-rose-500/10 transition-colors text-xs flex items-center gap-1 font-mono"
                  title="Clear Cart"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
              <button
                onClick={onClose}
                className="p-2 rounded-lg text-[#A88B77] hover:text-[#FFF8F2] hover:bg-[#281D17] transition-colors"
                title="Close"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Body Content */}
          <div className="flex-1 overflow-y-auto custom-scrollbar p-5 space-y-6">
            
            {cart.length === 0 ? (
              /* Empty Cart State */
              <div className="h-full flex flex-col items-center justify-center text-center py-16 px-4 space-y-4">
                <div className="w-20 h-20 rounded-2xl bg-[#1C1410] border border-[#3D2B22] flex items-center justify-center text-[#8A6F5D] mb-2">
                  <ShoppingBag className="w-10 h-10 animate-bounce text-[#D4A373]" />
                </div>
                <h4 className="text-lg font-bold text-[#FFF8F2] font-['Space_Grotesk']">Your Cart is Empty</h4>
                <p className="text-xs text-[#CBB5A1] max-w-xs leading-relaxed">
                  Looks like you haven't added any products to your cart yet. Explore our store and add items with one click!
                </p>
                <button
                  onClick={() => {
                    onClose();
                    const el = document.getElementById('store');
                    if (el) el.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="mt-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#D4A373] via-[#E6CCB2] to-[#DDB892] hover:from-[#E6CCB2] hover:to-[#D4A373] text-[#140E0A] font-bold text-xs shadow-lg shadow-[#140E0A]/60 transition-all flex items-center gap-2"
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>Explore Products Store</span>
                </button>
              </div>
            ) : step === 'cart' ? (
              /* STEP 1: CART ITEMS LIST */
              <div className="space-y-4">
                <div className="space-y-3">
                  {cart.map((item) => {
                    const isOutOfStock = item.product.stock <= 0;
                    const isMaxStock = item.quantity >= item.product.stock;

                    return (
                      <div
                        key={item.product.id}
                        className="p-3.5 rounded-2xl bg-[#1C1410] border border-[#3D2B22] hover:border-[#523A2E] transition-all flex gap-3.5 items-center"
                      >
                        {/* Thumbnail */}
                        <div className="w-16 h-16 rounded-xl overflow-hidden bg-[#140E0A] border border-[#3D2B22] shrink-0 relative">
                          <img
                            src={item.product.image}
                            alt={item.product.name}
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover"
                          />
                        </div>

                        {/* Details */}
                        <div className="flex-1 min-w-0">
                          <span className="text-[10px] font-mono text-[#A88B77] uppercase tracking-wider block truncate">
                            {item.product.category}
                          </span>
                          <h4 className="text-sm font-bold text-[#FFF8F2] font-['Space_Grotesk'] truncate">
                            {item.product.name}
                          </h4>
                          <div className="flex items-center gap-2 mt-1">
                            <span className="text-xs font-mono font-bold text-[#FFF8F2]">৳{item.product.price}</span>
                            {item.product.originalPrice && item.product.originalPrice > item.product.price && (
                              <span className="text-[10px] font-mono text-[#8A6F5D] line-through">
                                ৳{item.product.originalPrice}
                              </span>
                            )}
                          </div>
                        </div>

                        {/* Quantity Controls & Remove */}
                        <div className="flex flex-col items-end gap-2 shrink-0">
                          <div className="flex items-center bg-[#140E0A] border border-[#3D2B22] rounded-lg p-0.5">
                            <button
                              type="button"
                              onClick={() => onUpdateQuantity(item.product.id, item.quantity - 1)}
                              className="p-1 text-[#A88B77] hover:text-[#FFF8F2] rounded hover:bg-[#281D17] transition-colors"
                              title="Decrease"
                            >
                              <Minus className="w-3.5 h-3.5" />
                            </button>
                            <span className="w-7 text-center font-mono text-xs font-bold text-[#FFF8F2]">
                              {item.quantity}
                            </span>
                            <button
                              type="button"
                              disabled={isMaxStock}
                              onClick={() => onUpdateQuantity(item.product.id, item.quantity + 1)}
                              className={`p-1 rounded transition-colors ${
                                isMaxStock 
                                  ? 'text-[#5E4738] cursor-not-allowed' 
                                  : 'text-[#A88B77] hover:text-[#FFF8F2] hover:bg-[#281D17]'
                              }`}
                              title={isMaxStock ? 'Max available stock reached' : 'Increase'}
                            >
                              <Plus className="w-3.5 h-3.5" />
                            </button>
                          </div>

                          <div className="flex items-center gap-2">
                            <span className="text-xs font-mono font-extrabold text-[#D4A373]">
                              ৳{item.product.price * item.quantity}
                            </span>
                            <button
                              type="button"
                              onClick={() => onRemoveItem(item.product.id)}
                              className="p-1 text-[#8A6F5D] hover:text-rose-400 transition-colors"
                              title="Remove item"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Coupon Code Section */}
                {isCouponFeatureEnabled ? (
                  <div className="p-4 rounded-2xl bg-[#1C1410] border border-[#3D2B22] space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 text-xs font-bold font-mono text-[#E6CCB2]">
                        <Tag className="w-3.5 h-3.5 text-[#D4A373]" />
                        <span>HAVE A COUPON CODE? (কুপন কোড)</span>
                      </div>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-[#281D17] text-[#D4A373] border border-[#523A2E]">
                        মাসে ১ বার ব্যবহারযোগ্য
                      </span>
                    </div>

                    {!appliedCoupon ? (
                      <div className="space-y-2">
                        <div className="flex gap-2">
                          <input
                            type="text"
                            placeholder="ENTER COUPON (E.G. LEWRA50)"
                            value={couponCode}
                            onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
                            className="flex-1 px-3 py-2 bg-[#140E0A] border border-[#3D2B22] rounded-xl text-xs font-mono text-[#FFF8F2] placeholder:text-[#8A6F5D] focus:outline-none focus:border-[#D4A373] uppercase font-bold"
                          />
                          <button
                            type="button"
                            onClick={handleApplyCoupon}
                            className="px-4 py-2 bg-gradient-to-r from-[#D4A373] to-[#C08A5E] hover:from-[#E6CCB2] hover:to-[#D4A373] text-[#140E0A] rounded-xl text-xs font-mono font-black transition-all shrink-0 shadow-md shadow-[#140E0A]/50"
                          >
                            Apply
                          </button>
                        </div>
                        <p className="text-[10px] text-[#8A6F5D] font-mono">
                          * প্রতিটি ইউজার প্রতি মাসে সর্বোচ্চ {maxCouponLimit}টি কুপন কোড ব্যবহার করতে পারবেন।
                        </p>
                      </div>
                    ) : (
                      <div className="p-3 rounded-xl bg-[#281D17]/80 border border-emerald-500/40 flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <div className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                            <Check className="w-4 h-4" />
                          </div>
                          <div>
                            <div className="flex items-center gap-1.5 font-mono text-xs">
                              <span className="font-bold text-white uppercase">{appliedCoupon.code}</span>
                              <span className="text-emerald-400 font-bold">
                                (-{appliedCoupon.discountPercent ? `${appliedCoupon.discountPercent}%` : `৳${appliedCoupon.discountBDT}`} OFF)
                              </span>
                            </div>
                            <span className="text-[10px] text-emerald-300 font-mono">
                              ডিসকাউন্ট মাইনাস: -৳{discountAmount} BDT
                            </span>
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={handleRemoveCoupon}
                          className="px-2.5 py-1 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/30 text-[10px] font-mono font-bold"
                        >
                          Remove
                        </button>
                      </div>
                    )}

                    {couponMsg && (
                      <div className={`p-2.5 rounded-xl text-xs font-mono flex items-center gap-1.5 ${
                        couponMsg.type === 'success' 
                          ? 'bg-emerald-950/60 text-emerald-300 border border-emerald-500/30' 
                          : 'bg-rose-950/60 text-rose-300 border border-rose-500/30'
                      }`}>
                        {couponMsg.type === 'success' ? <Check className="w-3.5 h-3.5 shrink-0 text-emerald-400" /> : <AlertCircle className="w-3.5 h-3.5 shrink-0 text-rose-400" />}
                        <span className="leading-tight">{couponMsg.text}</span>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="p-3 rounded-xl bg-[#1C1410]/50 border border-[#3D2B22]/50 flex items-center justify-between text-xs font-mono text-[#8A6F5D]">
                    <div className="flex items-center gap-2">
                      <Lock className="w-3.5 h-3.5 text-[#8A6F5D]" />
                      <span>কুপন অপশন বর্তমানে বন্ধ রয়েছে (Coupons Disabled)</span>
                    </div>
                  </div>
                )}

                {/* Delivery Zone Selector in Cart */}
                <div className="p-4 rounded-2xl bg-[#1C1410] border border-[#3D2B22] space-y-2.5">
                  <span className="text-xs font-mono font-bold text-[#E6CCB2] flex items-center gap-2">
                    <Truck className="w-3.5 h-3.5 text-[#D4A373]" />
                    DELIVERY DESTINATION
                  </span>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setDeliveryZone('Inside Dhaka')}
                      className={`p-2.5 rounded-xl border text-xs font-semibold flex flex-col items-center justify-center transition-all ${
                        deliveryZone === 'Inside Dhaka'
                          ? 'bg-gradient-to-r from-[#D4A373] via-[#E6CCB2] to-[#DDB892] text-[#140E0A] font-bold shadow-md shadow-[#140E0A]/50'
                          : 'bg-[#140E0A] border-[#3D2B22] text-[#CBB5A1] hover:text-[#FFF8F2]'
                      }`}
                    >
                      <span>Inside Dhaka</span>
                      <span className="text-[10px] font-mono font-bold">৳{chargeInside} BDT</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setDeliveryZone('Outside Dhaka')}
                      className={`p-2.5 rounded-xl border text-xs font-semibold flex flex-col items-center justify-center transition-all ${
                        deliveryZone === 'Outside Dhaka'
                          ? 'bg-gradient-to-r from-[#D4A373] via-[#E6CCB2] to-[#DDB892] text-[#140E0A] font-bold shadow-md shadow-[#140E0A]/50'
                          : 'bg-[#140E0A] border-[#3D2B22] text-[#CBB5A1] hover:text-[#FFF8F2]'
                      }`}
                    >
                      <span>Outside Dhaka</span>
                      <span className="text-[10px] font-mono font-bold">৳{chargeOutside} BDT</span>
                    </button>
                  </div>
                </div>

              </div>
            ) : (
              /* STEP 2: CHECKOUT FORM */
              <form onSubmit={handleCheckoutSubmit} className="space-y-4">
                
                {/* Back to Cart link */}
                <button
                  type="button"
                  onClick={() => setStep('cart')}
                  className="text-xs font-mono text-[#D4A373] hover:text-[#E6CCB2] hover:underline flex items-center gap-1"
                >
                  ← Edit Cart Items ({totalItemsCount})
                </button>

                {/* Customer Information */}
                <div className="p-4 rounded-2xl bg-[#1C1410] border border-[#3D2B22] space-y-3">
                  <h4 className="text-xs font-mono font-bold text-[#E6CCB2] uppercase flex items-center gap-2">
                    <User className="w-3.5 h-3.5 text-[#D4A373]" />
                    Customer Details (কাস্টমার তথ্য)
                  </h4>

                  <div className="space-y-2.5">
                    <div>
                      <label className="block text-[10px] font-mono text-[#A88B77] mb-1">
                        YOUR FULL NAME (আপনার নাম) *
                      </label>
                      <input
                        type="text"
                        required
                        value={customerName}
                        onChange={(e) => setCustomerName(e.target.value)}
                        placeholder="e.g. Tanvir Ahmed"
                        className="w-full px-3 py-2 bg-[#140E0A] border border-[#3D2B22] rounded-xl text-xs text-[#FFF8F2] focus:outline-none focus:border-[#D4A373]"
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] font-mono text-[#A88B77] mb-1">
                        PHONE NUMBER (মোবাইল নম্বর) *
                      </label>
                      <input
                        type="tel"
                        required
                        value={customerPhone}
                        onChange={(e) => setCustomerPhone(e.target.value)}
                        placeholder="e.g. 01712345678"
                        className="w-full px-3 py-2 bg-[#140E0A] border border-[#3D2B22] rounded-xl text-xs text-[#FFF8F2] font-mono focus:outline-none focus:border-[#D4A373]"
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] font-mono text-[#A88B77] mb-1">
                        DELIVERY ADDRESS (ডেলিভারি ঠিকানা) *
                      </label>
                      <textarea
                        required
                        rows={2}
                        value={shippingAddress}
                        onChange={(e) => setShippingAddress(e.target.value)}
                        placeholder="House / Road / Area / District (বিস্তারিত ঠিকানা লিখুন)"
                        className="w-full px-3 py-2 bg-[#140E0A] border border-[#3D2B22] rounded-xl text-xs text-[#FFF8F2] focus:outline-none focus:border-[#D4A373]"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      <div>
                        <label className="block text-[10px] font-mono text-[#A88B77] mb-1">
                          EMAIL (ঐচ্ছিক)
                        </label>
                        <input
                          type="email"
                          value={customerEmail}
                          onChange={(e) => setCustomerEmail(e.target.value)}
                          placeholder="your@email.com"
                          className="w-full px-3 py-2 bg-[#140E0A] border border-[#3D2B22] rounded-xl text-xs text-[#FFF8F2] focus:outline-none focus:border-[#D4A373]"
                        />
                      </div>

                      <div>
                        <label className="block text-[10px] font-mono text-[#A88B77] mb-1">
                          SPECIAL NOTES (ঐচ্ছিক)
                        </label>
                        <input
                          type="text"
                          value={notes}
                          onChange={(e) => setNotes(e.target.value)}
                          placeholder="Special instructions..."
                          className="w-full px-3 py-2 bg-[#140E0A] border border-[#3D2B22] rounded-xl text-xs text-[#FFF8F2] focus:outline-none focus:border-[#D4A373]"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Payment Method Selector */}
                <div className="p-4 rounded-2xl bg-[#1C1410] border border-[#3D2B22] space-y-3">
                  <h4 className="text-xs font-mono font-bold text-[#E6CCB2] uppercase flex items-center gap-2">
                    <CreditCard className="w-3.5 h-3.5 text-[#D4A373]" />
                    Payment Method (পেমেন্ট মাধ্যম)
                  </h4>

                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { id: 'bKash', label: 'bKash', color: 'text-pink-400 border-pink-500/40 bg-pink-950/20' },
                      { id: 'Nagad', label: 'Nagad', color: 'text-orange-400 border-orange-500/40 bg-orange-950/20' },
                      { id: 'Rocket', label: 'Rocket', color: 'text-purple-400 border-purple-500/40 bg-purple-950/20' },
                      ...(aboutInfo?.enableCashOnDelivery !== false ? [{ id: 'Cash on Delivery', label: 'Cash on Delivery', color: 'text-emerald-400 border-emerald-500/40 bg-emerald-950/20' }] : []),
                      ...(aboutInfo?.enableCardPayment ? [{ id: 'Card / Bank Transfer', label: 'Card / Bank', color: 'text-[#FFF8F2] border-[#523A2E] bg-[#281D17]' }] : [])
                    ].map(method => (
                      <button
                        key={method.id}
                        type="button"
                        onClick={() => setPaymentMethod(method.id as any)}
                        className={`p-2.5 rounded-xl border text-xs font-semibold transition-all ${
                          paymentMethod === method.id
                            ? `${method.color} shadow-lg ring-1 ring-[#D4A373]`
                            : 'bg-[#140E0A] border-[#3D2B22] text-[#CBB5A1] hover:text-[#FFF8F2]'
                        }`}
                      >
                        {method.label}
                      </button>
                    ))}
                  </div>

                  {/* Payment Details for Mobile Wallets */}
                  {(paymentMethod === 'bKash' || paymentMethod === 'Nagad' || paymentMethod === 'Rocket') && (
                    <div className="p-3 bg-[#140E0A] rounded-xl border border-[#3D2B22] space-y-2 text-xs">
                      {(() => {
                        const rawTargetNumber = 
                          paymentMethod === 'bKash' ? (aboutInfo?.bkashNumber || '01700000000') :
                          paymentMethod === 'Nagad' ? (aboutInfo?.nagadNumber || '01800000000') :
                          (aboutInfo?.rocketNumber || '01900000000');
                        const cleanDigits = extractCleanPhoneNumber(rawTargetNumber);
                        const isCopied = copiedNumber === cleanDigits;

                        return (
                          <div>
                            <div className="flex items-center justify-between">
                              <span className="text-[#A88B77] text-[11px] font-medium">Send Money No ({paymentMethod} Personal):</span>
                              <button
                                type="button"
                                onClick={() => handleCopyNumber(rawTargetNumber)}
                                className={`px-2 py-0.5 rounded text-[11px] font-mono font-bold flex items-center gap-1 transition-all ${
                                  isCopied
                                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                                    : 'bg-[#281D17] text-[#E6CCB2] hover:bg-[#33231B] border border-[#523A2E]'
                                }`}
                                title="ক্লিক করলে শুধুমাত্র মোবাইল নম্বর কপি হবে"
                              >
                                {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                                <span>{isCopied ? `Copied (${cleanDigits})` : 'Copy Number'}</span>
                              </button>
                            </div>
                            <div 
                              onClick={() => handleCopyNumber(rawTargetNumber)}
                              className="font-mono font-black text-[#D4A373] text-sm mt-1 p-2 bg-[#1C1410] rounded-lg border border-[#3D2B22] hover:border-[#D4A373] cursor-pointer flex items-center justify-between transition-all"
                              title="ক্লিক করে শুধুমাত্র নম্বরটি কপি করুন"
                            >
                              <span>{cleanDigits}</span>
                              <span className="text-[10px] text-[#A88B77] font-sans font-normal">Click to Copy</span>
                            </div>
                            <p className="text-[10px] text-[#A88B77] mt-1">
                              * কপি বাটনে চাপ দিলে শুধুমাত্র নম্বরটি কপি হবে যেন সহজেই Send Money করতে পারেন।
                            </p>
                          </div>
                        );
                      })()}

                      <div className="p-2.5 rounded-lg bg-emerald-950/40 border border-emerald-500/40 text-[11px] text-emerald-300 font-sans flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                        <span><strong>সহজ পেমেন্ট:</strong> টাকা পাঠানোর মোবাইল নম্বর দিলেই যথেষ্ট। ট্রানজেকশন আইডি (TrxID) দেওয়া বাধ্যতামূলক নয়!</span>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2 border-t border-[#3D2B22]">
                        <div>
                          <div className="flex items-center justify-between mb-1">
                            <label className="block text-[10px] font-mono text-[#A88B77]">
                              SENDER MOBILE NO *
                            </label>
                            {customerPhone && paymentSenderPhone !== customerPhone && (
                              <button
                                type="button"
                                onClick={() => setPaymentSenderPhone(customerPhone)}
                                className="text-[10px] text-[#D4A373] hover:text-[#E6CCB2] underline font-mono"
                              >
                                Use My Phone
                              </button>
                            )}
                          </div>
                          <input
                            type="tel"
                            value={paymentSenderPhone || customerPhone}
                            onChange={(e) => setPaymentSenderPhone(e.target.value.replace(/\D/g, ''))}
                            placeholder="017xxxxxxxx"
                            className="w-full px-2.5 py-1.5 bg-[#1C1410] border border-[#3D2B22] rounded-lg text-xs text-[#FFF8F2] font-mono focus:outline-none focus:border-[#D4A373]"
                          />
                          <span className="text-[9px] text-[#A88B77] mt-0.5 block">
                            যে নম্বর থেকে টাকা পাঠিয়েছেন
                          </span>
                        </div>
                        <div>
                          <div className="flex items-center justify-between mb-1">
                            <label className="block text-[10px] font-mono text-[#A88B77]">
                              TRANSACTION ID (TRXID)
                            </label>
                            <span className="text-[10px] text-emerald-400 font-mono">ঐচ্ছিক</span>
                          </div>
                          <input
                            type="text"
                            value={paymentTrxId}
                            onChange={(e) => setPaymentTrxId(e.target.value.toUpperCase())}
                            placeholder="থাকলে দিন (ঐচ্ছিক)"
                            className="w-full px-2.5 py-1.5 bg-[#1C1410] border border-[#3D2B22] rounded-lg text-xs text-[#D4A373] font-mono focus:outline-none focus:border-[#D4A373] uppercase"
                          />
                          <span className="text-[9px] text-[#A88B77] mt-0.5 block">
                            নম্বর থাকলেই অর্ডার গ্রহণ হবে
                          </span>
                        </div>
                      </div>
                    </div>
                  )}

                </div>

              </form>
            )}

          </div>

          {/* Sticky Footer Summary & Action */}
          {cart.length > 0 && (
            <div className="p-5 border-t border-[#3D2B22] bg-[#1C1410]/95 backdrop-blur-md space-y-3">
              
              {/* Calculations Breakdown */}
              <div className="space-y-1 text-xs font-mono">
                <div className="flex justify-between text-[#CBB5A1]">
                  <span>Subtotal ({totalItemsCount} items)</span>
                  <span>৳{subtotal}</span>
                </div>
                {discountAmount > 0 && (
                  <div className="flex justify-between text-emerald-400">
                    <span>Coupon Discount</span>
                    <span>-৳{discountAmount}</span>
                  </div>
                )}
                <div className="flex justify-between text-[#CBB5A1]">
                  <span>Delivery ({deliveryZone})</span>
                  <span>৳{deliveryCharge}</span>
                </div>
                <div className="flex justify-between text-base font-bold text-[#FFF8F2] pt-2 border-t border-[#3D2B22] font-mono">
                  <span>Total Payable</span>
                  <span className="text-[#D4A373] text-lg">৳{finalTotalAmount}</span>
                </div>
              </div>

              {/* Action Button */}
              {step === 'cart' ? (
                <button
                  type="button"
                  onClick={() => setStep('checkout')}
                  className="w-full py-3.5 rounded-xl bg-gradient-to-r from-[#D4A373] via-[#E6CCB2] to-[#DDB892] hover:from-[#E6CCB2] hover:to-[#D4A373] text-[#140E0A] font-extrabold text-sm flex items-center justify-center gap-2 shadow-lg shadow-[#140E0A]/50 transition-all"
                >
                  <span>Proceed to Checkout</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              ) : (
                <button
                  type="button"
                  onClick={handleCheckoutSubmit}
                  className="w-full py-3.5 rounded-xl bg-gradient-to-r from-[#D4A373] via-[#E6CCB2] to-[#DDB892] hover:from-[#E6CCB2] hover:to-[#D4A373] text-[#140E0A] font-extrabold text-sm flex items-center justify-center gap-2 shadow-lg shadow-[#140E0A]/50 transition-all"
                >
                  <CheckCircle2 className="w-5 h-5" />
                  <span>Confirm & Place Order (৳{finalTotalAmount})</span>
                </button>
              )}

            </div>
          )}

        </div>
      </div>
    </div>
  );
};
