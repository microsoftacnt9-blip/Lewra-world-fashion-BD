import React, { useState, useEffect } from 'react';
import { Sparkles, Clock, Flame, ChevronRight, Zap, X, Gift, Star, Tag, Bell } from 'lucide-react';
import { AboutInfo } from '../types';
import { getRemainingTime } from '../utils/discountUtils';

interface FlashSaleBannerProps {
  aboutInfo: AboutInfo;
  onShopNow?: () => void;
}

export const FlashSaleBanner: React.FC<FlashSaleBannerProps> = ({ aboutInfo, onShopNow }) => {
  const [timeLeft, setTimeLeft] = useState<{
    days: number;
    hours: number;
    minutes: number;
    seconds: number;
    isExpired: boolean;
  } | null>(null);

  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    if (!aboutInfo.flashSaleActive) return;

    const updateTimer = () => {
      if (!aboutInfo.flashSaleValidUntil) {
        setTimeLeft({ days: 3, hours: 12, minutes: 45, seconds: 30, isExpired: false });
        return;
      }
      const rem = getRemainingTime(aboutInfo.flashSaleValidUntil);
      if (rem) {
        setTimeLeft({
          days: rem.days,
          hours: rem.hours,
          minutes: rem.minutes,
          seconds: rem.seconds,
          isExpired: rem.isExpired
        });
      } else {
        setTimeLeft(null);
      }
    };

    updateTimer();
    const interval = setInterval(updateTimer, 1000);
    return () => clearInterval(interval);
  }, [aboutInfo.flashSaleActive, aboutInfo.flashSaleValidUntil]);

  if (!aboutInfo.flashSaleActive || dismissed || (timeLeft && timeLeft.isExpired)) {
    return null;
  }

  // Theme Styles mapping
  const theme = aboutInfo.flashSaleTheme || 'fire';

  const themeStyles = {
    fire: {
      wrapper: 'bg-gradient-to-r from-rose-950 via-red-950 to-orange-950 border-rose-500/50',
      glow1: 'bg-rose-500/20',
      glow2: 'bg-orange-500/20',
      badge: 'bg-gradient-to-r from-rose-500 to-amber-500 text-slate-950',
      badgeIcon: <Flame className="w-3.5 h-3.5 fill-slate-950" />,
      title: 'text-white',
      subtitle: 'text-rose-200/80 border-rose-500/30',
      clockBorder: 'border-rose-500/40',
      clockIcon: 'text-rose-400',
      timerBox: 'bg-rose-900/60 border-rose-500/40 text-rose-200',
      timerSecBox: 'bg-rose-500 text-slate-950 shadow-rose-950',
      timerColon: 'text-rose-400',
      btn: 'bg-gradient-to-r from-rose-500 via-amber-500 to-yellow-400 hover:from-rose-400 hover:to-yellow-300 text-slate-950 shadow-rose-900/50',
      closeBtn: 'text-rose-300 hover:bg-rose-900/40'
    },
    gold: {
      wrapper: 'bg-gradient-to-r from-amber-950 via-yellow-950 to-orange-950 border-amber-500/50',
      glow1: 'bg-yellow-500/20',
      glow2: 'bg-amber-500/20',
      badge: 'bg-gradient-to-r from-yellow-400 to-amber-500 text-slate-950',
      badgeIcon: <Sparkles className="w-3.5 h-3.5 fill-slate-950" />,
      title: 'text-amber-100',
      subtitle: 'text-amber-200/80 border-amber-500/30',
      clockBorder: 'border-amber-500/40',
      clockIcon: 'text-amber-400',
      timerBox: 'bg-amber-900/60 border-amber-500/40 text-amber-200',
      timerSecBox: 'bg-amber-400 text-slate-950 shadow-amber-950',
      timerColon: 'text-amber-400',
      btn: 'bg-gradient-to-r from-amber-400 via-yellow-300 to-yellow-500 hover:from-amber-300 hover:to-yellow-200 text-slate-950 shadow-amber-900/50',
      closeBtn: 'text-amber-300 hover:bg-amber-900/40'
    },
    cyber: {
      wrapper: 'bg-gradient-to-r from-cyan-950 via-blue-950 to-indigo-950 border-cyan-500/50',
      glow1: 'bg-cyan-500/20',
      glow2: 'bg-indigo-500/20',
      badge: 'bg-gradient-to-r from-cyan-400 to-blue-500 text-slate-950',
      badgeIcon: <Zap className="w-3.5 h-3.5 fill-slate-950" />,
      title: 'text-cyan-50',
      subtitle: 'text-cyan-200/80 border-cyan-500/30',
      clockBorder: 'border-cyan-500/40',
      clockIcon: 'text-cyan-400',
      timerBox: 'bg-cyan-900/60 border-cyan-500/40 text-cyan-200',
      timerSecBox: 'bg-cyan-400 text-slate-950 shadow-cyan-950',
      timerColon: 'text-cyan-400',
      btn: 'bg-gradient-to-r from-cyan-400 via-teal-300 to-blue-400 hover:from-cyan-300 hover:to-blue-300 text-slate-950 shadow-cyan-900/50',
      closeBtn: 'text-cyan-300 hover:bg-cyan-900/40'
    },
    emerald: {
      wrapper: 'bg-gradient-to-r from-emerald-950 via-teal-950 to-slate-900 border-emerald-500/50',
      glow1: 'bg-emerald-500/20',
      glow2: 'bg-teal-500/20',
      badge: 'bg-gradient-to-r from-emerald-400 to-teal-400 text-slate-950',
      badgeIcon: <Gift className="w-3.5 h-3.5 text-slate-950" />,
      title: 'text-emerald-50',
      subtitle: 'text-emerald-200/80 border-emerald-500/30',
      clockBorder: 'border-emerald-500/40',
      clockIcon: 'text-emerald-400',
      timerBox: 'bg-emerald-900/60 border-emerald-500/40 text-emerald-200',
      timerSecBox: 'bg-emerald-400 text-slate-950 shadow-emerald-950',
      timerColon: 'text-emerald-400',
      btn: 'bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-400 hover:from-emerald-300 hover:to-teal-200 text-slate-950 shadow-emerald-900/50',
      closeBtn: 'text-emerald-300 hover:bg-emerald-900/40'
    },
    purple: {
      wrapper: 'bg-gradient-to-r from-purple-950 via-fuchsia-950 to-indigo-950 border-purple-500/50',
      glow1: 'bg-purple-500/20',
      glow2: 'bg-fuchsia-500/20',
      badge: 'bg-gradient-to-r from-purple-400 to-pink-500 text-slate-950',
      badgeIcon: <Star className="w-3.5 h-3.5 fill-slate-950" />,
      title: 'text-purple-50',
      subtitle: 'text-purple-200/80 border-purple-500/30',
      clockBorder: 'border-purple-500/40',
      clockIcon: 'text-purple-400',
      timerBox: 'bg-purple-900/60 border-purple-500/40 text-purple-200',
      timerSecBox: 'bg-purple-400 text-slate-950 shadow-purple-950',
      timerColon: 'text-purple-400',
      btn: 'bg-gradient-to-r from-purple-400 via-pink-400 to-rose-400 hover:from-purple-300 hover:to-pink-300 text-slate-950 shadow-purple-900/50',
      closeBtn: 'text-purple-300 hover:bg-purple-900/40'
    },
    sunset: {
      wrapper: 'bg-gradient-to-r from-pink-950 via-rose-950 to-amber-950 border-pink-500/50',
      glow1: 'bg-pink-500/20',
      glow2: 'bg-amber-500/20',
      badge: 'bg-gradient-to-r from-pink-400 to-amber-400 text-slate-950',
      badgeIcon: <Flame className="w-3.5 h-3.5 fill-slate-950" />,
      title: 'text-pink-50',
      subtitle: 'text-pink-200/80 border-pink-500/30',
      clockBorder: 'border-pink-500/40',
      clockIcon: 'text-pink-400',
      timerBox: 'bg-pink-900/60 border-pink-500/40 text-pink-200',
      timerSecBox: 'bg-pink-400 text-slate-950 shadow-pink-950',
      timerColon: 'text-pink-400',
      btn: 'bg-gradient-to-r from-pink-400 via-rose-300 to-amber-400 hover:from-pink-300 hover:to-amber-300 text-slate-950 shadow-pink-900/50',
      closeBtn: 'text-pink-300 hover:bg-pink-900/40'
    },
    midnight: {
      wrapper: 'bg-gradient-to-r from-slate-950 via-zinc-900 to-neutral-950 border-slate-700/60',
      glow1: 'bg-cyan-500/10',
      glow2: 'bg-purple-500/10',
      badge: 'bg-slate-800 text-cyan-300 border border-cyan-500/30',
      badgeIcon: <Tag className="w-3.5 h-3.5 text-cyan-400" />,
      title: 'text-slate-100',
      subtitle: 'text-slate-400 border-slate-700',
      clockBorder: 'border-slate-700',
      clockIcon: 'text-cyan-400',
      timerBox: 'bg-slate-900 border-slate-700 text-slate-200',
      timerSecBox: 'bg-cyan-500 text-slate-950 shadow-cyan-950',
      timerColon: 'text-slate-500',
      btn: 'bg-slate-100 hover:bg-white text-slate-950 shadow-slate-950/80',
      closeBtn: 'text-slate-400 hover:bg-slate-800'
    }
  }[theme];

  // Action Click Handler
  const handleButtonClick = () => {
    const action = aboutInfo.flashSaleButtonAction || 'scroll_products';
    if (action === 'scroll_products') {
      const el = document.getElementById('products');
      if (el) {
        el.scrollIntoView({ behavior: 'smooth' });
      } else if (onShopNow) {
        onShopNow();
      }
    } else if (action === 'scroll_pricing') {
      const el = document.getElementById('pricing');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    } else if (action === 'scroll_features') {
      const el = document.getElementById('features');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    } else if (action === 'custom_url' && aboutInfo.flashSaleButtonUrl) {
      window.location.href = aboutInfo.flashSaleButtonUrl;
    } else if (onShopNow) {
      onShopNow();
    }
  };

  const badgeText = aboutInfo.flashSaleBadgeText || (aboutInfo.flashSaleDiscountPercent ? `${aboutInfo.flashSaleDiscountPercent}% OFF FLASH SALE` : 'LIMITED DISCOUNT OFFER');
  const mainTitle = aboutInfo.flashSaleTitle || 'Special Store Discount Offer is Live!';
  const buttonText = aboutInfo.flashSaleButtonText || 'SHOP NOW (ছাড় নিন)';
  const showTimer = !aboutInfo.flashSaleHideTimer;
  const showButton = !aboutInfo.flashSaleHideButton;

  return (
    <div
      className={`relative z-40 border-b text-white shadow-xl overflow-hidden py-2.5 px-3 sm:px-6 transition-all ${themeStyles.wrapper}`}
      style={
        aboutInfo.flashSaleBgImage
          ? {
              backgroundImage: `linear-gradient(to right, rgba(10, 10, 20, 0.88), rgba(15, 10, 25, 0.82)), url('${aboutInfo.flashSaleBgImage}')`,
              backgroundSize: 'cover',
              backgroundPosition: 'center'
            }
          : undefined
      }
    >
      {/* Subtle animated background glow */}
      <div className={`absolute -top-10 left-1/4 w-72 h-20 blur-3xl rounded-full pointer-events-none animate-pulse ${themeStyles.glow1}`} />
      <div className={`absolute -bottom-10 right-1/4 w-72 h-20 blur-3xl rounded-full pointer-events-none animate-pulse ${themeStyles.glow2}`} />

      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-3 text-xs relative z-10">
        
        {/* Left Side: Campaign Title & Discount */}
        <div className="flex items-center gap-2.5 text-center md:text-left flex-wrap justify-center">
          <span className={`px-2.5 py-1 rounded-full font-extrabold text-[10px] font-mono tracking-wider flex items-center gap-1 shadow-md uppercase ${themeStyles.badge}`}>
            {themeStyles.badgeIcon}
            {badgeText}
          </span>

          <span className={`font-bold text-xs sm:text-sm font-['Space_Grotesk'] tracking-wide ${themeStyles.title}`}>
            {mainTitle}
          </span>

          {aboutInfo.flashSaleSubtitle && (
            <span className={`hidden lg:inline text-[11px] font-mono border-l pl-2 ${themeStyles.subtitle}`}>
              {aboutInfo.flashSaleSubtitle}
            </span>
          )}
        </div>

        {/* Right Side: Live Countdown Timer & Action Button */}
        <div className="flex items-center gap-3 sm:gap-4 shrink-0 flex-wrap justify-center">
          
          {/* Countdown Clock Box */}
          {showTimer && timeLeft && !timeLeft.isExpired && (
            <div className={`flex items-center gap-1.5 font-mono text-[11px] bg-slate-950/80 px-3 py-1 rounded-xl border shadow-inner ${themeStyles.clockBorder}`}>
              <Clock className={`w-3.5 h-3.5 animate-spin shrink-0 ${themeStyles.clockIcon}`} style={{ animationDuration: '6s' }} />
              <span className="text-slate-400 text-[10px] hidden sm:inline">ENDS IN:</span>
              
              <div className="flex items-center gap-1 font-bold text-white">
                <span className={`border px-1.5 py-0.5 rounded min-w-[22px] text-center ${themeStyles.timerBox}`}>
                  {String(timeLeft.days).padStart(2, '0')}d
                </span>
                <span className={`font-bold ${themeStyles.timerColon}`}>:</span>
                <span className={`border px-1.5 py-0.5 rounded min-w-[22px] text-center ${themeStyles.timerBox}`}>
                  {String(timeLeft.hours).padStart(2, '0')}h
                </span>
                <span className={`font-bold ${themeStyles.timerColon}`}>:</span>
                <span className={`border px-1.5 py-0.5 rounded min-w-[22px] text-center ${themeStyles.timerBox}`}>
                  {String(timeLeft.minutes).padStart(2, '0')}m
                </span>
                <span className={`font-bold ${themeStyles.timerColon}`}>:</span>
                <span className={`px-1.5 py-0.5 rounded font-black min-w-[22px] text-center shadow-sm ${themeStyles.timerSecBox}`}>
                  {String(timeLeft.seconds).padStart(2, '0')}s
                </span>
              </div>
            </div>
          )}

          {/* Shop Now Action */}
          {showButton && (
            <button
              type="button"
              onClick={handleButtonClick}
              className={`px-3.5 py-1.5 rounded-xl font-black text-xs font-mono flex items-center gap-1 shadow-lg hover:scale-105 transition-all cursor-pointer ${themeStyles.btn}`}
            >
              <Zap className="w-3.5 h-3.5 fill-slate-950" />
              <span>{buttonText}</span>
              <ChevronRight className="w-3 h-3" />
            </button>
          )}

          {/* Close banner button */}
          <button
            type="button"
            onClick={() => setDismissed(true)}
            className={`p-1 rounded-lg transition-colors cursor-pointer ${themeStyles.closeBtn}`}
            title="Dismiss Announcement"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

      </div>
    </div>
  );
};
