import React, { useState, useEffect } from 'react';
import { Product, Order, Coupon, AboutInfo, UserAccount, ProductReview } from '../types';
import { ShoppingBag, ShoppingCart, Sparkles, Check, Package, X, ArrowRight, DollarSign, Tag, CheckCircle2, Video, Play, FileText, Percent, Copy, CreditCard, Smartphone, Truck, Search, Clock, Flame, Timer, Eye, Image as ImageIcon, Star, Heart, MapPin } from 'lucide-react';
import { OrderReceiptModal } from './OrderReceiptModal';
import { ProductDetailModal } from './ProductDetailModal';
import { isProductDiscountActive, getRemainingTime, checkCouponValidity, checkUserMonthlyCouponLimit, copyCleanPhoneNumber, extractCleanPhoneNumber } from '../utils/discountUtils';

interface ProductStoreProps {
  products: Product[];
  coupons?: Coupon[];
  aboutInfo?: AboutInfo;
  currentUser?: UserAccount | null;
  orders?: Order[];
  onPlaceOrder: (order: Order) => void;
  onOpenAdmin: () => void;
  onAddToCart?: (product: Product, quantity?: number, selectedColor?: string, selectedSpec?: string) => void;
  onOpenCart?: () => void;
  cartItemsCount?: number;
  reviews?: ProductReview[];
  onAddReview?: (review: Omit<ProductReview, 'id' | 'createdAt'>) => void;
  wishlistIds?: string[];
  onToggleWishlist?: (product: Product) => void;
  onOpenWishlist?: () => void;
  onOpenTracking?: () => void;
}

const getEmbedVideoUrl = (url?: string) => {
  if (!url) return null;
  const cleanUrl = url.trim();
  if (cleanUrl.includes('youtube.com/watch?v=')) {
    const videoId = cleanUrl.split('v=')[1]?.split('&')[0];
    return `https://www.youtube.com/embed/${videoId}`;
  }
  if (cleanUrl.includes('youtu.be/')) {
    const videoId = cleanUrl.split('youtu.be/')[1]?.split('?')[0];
    return `https://www.youtube.com/embed/${videoId}`;
  }
  return cleanUrl;
};

export const ProductStore: React.FC<ProductStoreProps> = ({ 
  products, 
  coupons = [], 
  aboutInfo, 
  currentUser, 
  orders = [],
  onPlaceOrder, 
  onOpenAdmin,
  onAddToCart,
  onOpenCart,
  cartItemsCount = 0,
  reviews = [],
  onAddReview,
  wishlistIds = [],
  onToggleWishlist,
  onOpenWishlist,
  onOpenTracking
}) => {
  const [viewDetailsProduct, setViewDetailsProduct] = useState<Product | null>(null);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [quantity, setQuantity] = useState(1);
  const [customerName, setCustomerName] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [addedProductId, setAddedProductId] = useState<string | null>(null);
  const [customerPhone, setCustomerPhone] = useState('');
  const [shippingAddress, setShippingAddress] = useState('');
  const [notes, setNotes] = useState('');
  const [wishlistToast, setWishlistToast] = useState<{ message: string; isAdded: boolean } | null>(null);

  const handleWishlistToggleWithFeedback = (product: Product) => {
    const isCurrentlyWishlisted = wishlistIds.includes(product.id);
    if (onToggleWishlist) {
      onToggleWishlist(product);
    }
    setWishlistToast({
      message: isCurrentlyWishlisted
        ? `Removed "${product.name}" from Wishlist`
        : `Saved "${product.name}" to Wishlist! ❤️`,
      isAdded: !isCurrentlyWishlisted
    });
    setTimeout(() => {
      setWishlistToast(null);
    }, 2800);
  };

  // Variant selections for Quick Order
  const [selectedColor, setSelectedColor] = useState<string>('');
  const [selectedSpec, setSelectedSpec] = useState<string>('');

  // Auto-fill customer details (including phone) when user is logged in
  useEffect(() => {
    if (currentUser) {
      if (currentUser.name && !customerName) setCustomerName(currentUser.name);
      if (currentUser.email && !customerEmail) setCustomerEmail(currentUser.email);
      if (currentUser.phone) {
        setCustomerPhone(currentUser.phone);
        if (!paymentSenderPhone) setPaymentSenderPhone(currentUser.phone);
      }
    }
  }, [currentUser]);

  useEffect(() => {
    if (selectedProduct && currentUser) {
      if (currentUser.name && !customerName) setCustomerName(currentUser.name);
      if (currentUser.email && !customerEmail) setCustomerEmail(currentUser.email);
      if (currentUser.phone) {
        setCustomerPhone(currentUser.phone);
        if (!paymentSenderPhone) setPaymentSenderPhone(currentUser.phone);
      }
    }
  }, [selectedProduct, currentUser]);
  const [orderSuccess, setOrderSuccess] = useState<Order | null>(null);
  const [viewReceiptOrder, setViewReceiptOrder] = useState<Order | null>(null);
  const [categoryFilter, setCategoryFilter] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const handleAddToCartClick = (product: Product, qty: number = 1, color?: string, spec?: string) => {
    if (onAddToCart) {
      onAddToCart(product, qty, color, spec);
    }
    setAddedProductId(product.id);
    setTimeout(() => setAddedProductId(null), 2200);
  };

  // Coupon state
  const [couponCode, setCouponCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(null);
  const [couponMsg, setCouponMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Payment method & Delivery state
  const [paymentMethod, setPaymentMethod] = useState<'bKash' | 'Nagad' | 'Rocket' | 'Cash on Delivery' | 'Card / Bank Transfer'>('bKash');
  const [paymentTrxId, setPaymentTrxId] = useState('');
  const [paymentSenderPhone, setPaymentSenderPhone] = useState('');
  const [advancePaymentInput, setAdvancePaymentInput] = useState<string>('');
  const [copiedNumber, setCopiedNumber] = useState<string | null>(null);
  const [deliveryZone, setDeliveryZone] = useState<'Inside Dhaka' | 'Outside Dhaka'>('Inside Dhaka');

  const categories = ['All', ...Array.from(new Set(products.map(p => p.category)))];

  const filteredProducts = products.filter(product => {
    const matchesCategory = categoryFilter === 'All' || product.category === categoryFilter;
    const q = searchQuery.trim().toLowerCase();
    const matchesSearch = !q ||
      product.name.toLowerCase().includes(q) ||
      product.description.toLowerCase().includes(q) ||
      product.category.toLowerCase().includes(q) ||
      (product.tag && product.tag.toLowerCase().includes(q));
    return matchesCategory && matchesSearch;
  });

  const chargeInside = aboutInfo?.deliveryChargeInsideDhaka ?? 60;
  const chargeOutside = aboutInfo?.deliveryChargeOutsideDhaka ?? 130;
  const deliveryCharge = deliveryZone === 'Inside Dhaka' ? chargeInside : chargeOutside;

  // Coupon enablement check
  const isCouponFeatureEnabled = aboutInfo?.enableCoupons !== false;
  const maxCouponLimit = aboutInfo?.maxCouponsPerUserPerMonth ?? 1;

  const subtotal = selectedProduct ? selectedProduct.price * quantity : 0;
  let discountAmount = 0;
  if (appliedCoupon && subtotal > 0 && isCouponFeatureEnabled) {
    if (appliedCoupon.discountPercent) {
      discountAmount = Math.round((subtotal * appliedCoupon.discountPercent) / 100);
    } else if (appliedCoupon.discountBDT) {
      discountAmount = Math.min(subtotal, appliedCoupon.discountBDT);
    }
  }
  const finalTotalAmount = Math.max(0, subtotal - discountAmount) + deliveryCharge;

  const effectiveAdvancePaid = advancePaymentInput !== ''
    ? Math.min(finalTotalAmount, Math.max(0, parseInt(advancePaymentInput) || 0))
    : (paymentMethod === 'Cash on Delivery' ? 0 : finalTotalAmount);
  const effectiveDueAmount = Math.max(0, finalTotalAmount - effectiveAdvancePaid);

  const handleApplyCoupon = () => {
    setCouponMsg(null);
    if (!couponCode.trim()) return;

    if (!isCouponFeatureEnabled) {
      setAppliedCoupon(null);
      setCouponMsg({ type: 'error', text: 'বর্তমানে স্টোরে কুপন অপশন বন্ধ রয়েছে (Coupons disabled by admin).' });
      return;
    }

    const clean = couponCode.trim().toUpperCase();
    const found = coupons.find(c => c.code.toUpperCase() === clean);
    if (found) {
      const check = checkCouponValidity(found);
      if (!check.isValid) {
        setAppliedCoupon(null);
        setCouponMsg({ type: 'error', text: check.message || 'এই কুপনটি বর্তমানে সক্রিয় নয়।' });
        return;
      }

      // Check monthly limit for user (1 per month)
      const userIdentifier = {
        email: customerEmail.trim() || currentUser?.email,
        phone: customerPhone.trim() || currentUser?.phone
      };

      const limitCheck = checkUserMonthlyCouponLimit(userIdentifier, orders, maxCouponLimit);
      if (!limitCheck.allowed) {
        setAppliedCoupon(null);
        setCouponMsg({ type: 'error', text: limitCheck.message || 'আপনি এই মাসে ইতিমধ্যে ১টি কুপন ব্যবহার করেছেন।' });
        return;
      }

      setAppliedCoupon(found);
      const discountText = found.discountPercent ? `${found.discountPercent}% Discount` : `৳${found.discountBDT} BDT Discount`;
      const timeInfo = found.validUntil && getRemainingTime(found.validUntil)
        ? ` • ${getRemainingTime(found.validUntil)?.formattedText}`
        : '';
      setCouponMsg({ type: 'success', text: `কুপন '${found.code}' সফলভাবে যুক্ত হয়েছে! (${discountText}${timeInfo})` });
    } else {
      setAppliedCoupon(null);
      setCouponMsg({ type: 'error', text: 'অকার্যকর কুপন কোড (Invalid coupon code).' });
    }
  };

  const handleOpenCheckout = (product: Product) => {
    setSelectedProduct(product);
    setQuantity(1);
    setCouponCode('');
    setAppliedCoupon(null);
    setCouponMsg(null);
    setOrderSuccess(null);
    setPaymentMethod('bKash');
    setPaymentTrxId('');
    setPaymentSenderPhone(currentUser?.phone || '');
    setAdvancePaymentInput('');
    if (currentUser) {
      setCustomerName(currentUser.name || '');
      setCustomerEmail(currentUser.email || '');
      setCustomerPhone(currentUser.phone || '');
    }
  };

  const handleCopyNumber = (num: string) => {
    if (!num) return;
    const cleanDigits = copyCleanPhoneNumber(num);
    setCopiedNumber(cleanDigits);
    setTimeout(() => setCopiedNumber(null), 2500);
  };

  const handleCheckoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProduct) return;

    if (quantity <= 0) {
      alert('Please enter a quantity of at least 1 or more.');
      return;
    }

    if (quantity > selectedProduct.stock) {
      alert(`We currently do not have this many in stock. We have ${selectedProduct.stock} available. You can order up to ${selectedProduct.stock} units max.`);
      return;
    }

    // If a coupon is applied, verify limit one last time
    if (appliedCoupon) {
      if (!isCouponFeatureEnabled) {
        alert('বর্তমানে কুপন অপশন বন্ধ রাখা হয়েছে। কুপন ছাড়া অর্ডার সম্পন্ন করুন।');
        setAppliedCoupon(null);
        return;
      }

      const userIdentifier = {
        email: customerEmail.trim() || currentUser?.email,
        phone: customerPhone.trim() || currentUser?.phone
      };

      const limitCheck = checkUserMonthlyCouponLimit(userIdentifier, orders, maxCouponLimit);
      if (!limitCheck.allowed) {
        alert(limitCheck.message || 'আপনি এই মাসে ইতিমধ্যে কুপন ব্যবহার করেছেন।');
        setAppliedCoupon(null);
        return;
      }
    }

    const notesWithCoupon = appliedCoupon
      ? `${notes ? notes + ' | ' : ''}Coupon Applied: ${appliedCoupon.code} (-৳${discountAmount} BDT)`
      : notes;

    const newOrder: Order = {
      id: `ORD-${Math.floor(1000 + Math.random() * 9000)}`,
      customerName,
      customerEmail,
      customerPhone,
      shippingAddress,
      items: [
        {
          productId: selectedProduct.id,
          productName: selectedProduct.name,
          quantity,
          price: selectedProduct.price
        }
      ],
      totalAmount: finalTotalAmount,
      paymentMethod,
      paymentTrxId: paymentTrxId.trim() || undefined,
      paymentSenderPhone: paymentSenderPhone.trim() || customerPhone,
      deliveryZone: deliveryZone === 'Inside Dhaka' ? `Inside Dhaka (৳${chargeInside} BDT)` : `Outside Dhaka (৳${chargeOutside} BDT)`,
      deliveryCharge,
      advancePaid: effectiveAdvancePaid,
      dueAmount: effectiveDueAmount,
      status: 'Pending',
      createdAt: new Date().toISOString(),
      notes: notesWithCoupon,
      couponCode: appliedCoupon?.code,
      couponDiscount: discountAmount > 0 ? discountAmount : undefined
    };

    onPlaceOrder(newOrder);
    setOrderSuccess(newOrder);
    setViewReceiptOrder(newOrder);
    setSelectedProduct(null);

    // Reset form fields
    setCustomerName('');
    setCustomerEmail('');
    setCustomerPhone('');
    setShippingAddress('');
    setNotes('');
    setCouponCode('');
    setAppliedCoupon(null);
    setCouponMsg(null);
    setPaymentTrxId('');
    setPaymentSenderPhone('');
    setAdvancePaymentInput('');
  };

  return (
    <section id="store" className="py-24 relative bg-black border-t border-zinc-800/80">
      {/* Glow highlight */}
      <div className="absolute top-1/4 right-0 w-96 h-96 bg-white/[0.02] rounded-full blur-[150px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-zinc-900 border border-zinc-800 text-zinc-300 text-xs font-mono font-semibold uppercase tracking-wider mb-4">
              <ShoppingBag className="w-3.5 h-3.5 text-white" />
              {aboutInfo?.storeBadge || 'LEWRA HARDWARE & SPATIAL PRODUCTS STORE'}
            </div>
            <h2 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight font-['Space_Grotesk']">
              {aboutInfo?.storeTitle || 'Explore Our Spatial Ecosystem Products'}
            </h2>
            <p className="text-zinc-400 text-sm sm:text-base mt-2 max-w-xl">
              {aboutInfo?.storeSubtitle || 'Order next-gen hardware HUDs, neural edge gateways, and developer kits directly with real-time tracking.'}
            </p>
          </div>

          {/* Quick Header Actions */}
          <div className="flex items-center gap-2.5 flex-wrap">
            {onOpenTracking && (
              <button
                type="button"
                onClick={onOpenTracking}
                className="px-4 py-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-white font-mono text-xs font-bold flex items-center gap-2 transition-all shadow-md"
              >
                <Truck className="w-4 h-4 text-cyan-400" />
                <span>Track Live Order</span>
              </button>
            )}

            {onOpenWishlist && (
              <button
                type="button"
                onClick={onOpenWishlist}
                className="px-4 py-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-white font-mono text-xs font-bold flex items-center gap-2 transition-all shadow-md relative"
              >
                <Heart className="w-4 h-4 text-rose-500 fill-rose-500" />
                <span>Saved Wishlist</span>
                {wishlistIds.length > 0 && (
                  <span className="w-5 h-5 rounded-full bg-rose-500 text-white text-[10px] flex items-center justify-center font-bold">
                    {wishlistIds.length}
                  </span>
                )}
              </button>
            )}
          </div>
        </div>

        {/* Search Bar & Category Filters */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-10">
          {/* Search Bar */}
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-zinc-500 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search products by name, tag, or category..."
              className="w-full bg-zinc-900/90 border border-zinc-800 focus:border-zinc-500 rounded-xl pl-10 pr-10 py-2.5 text-xs text-white placeholder-zinc-500 font-mono focus:outline-none shadow-inner"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-zinc-400 hover:text-white rounded-md"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Category Filter Pills */}
          <div className="flex flex-wrap items-center gap-2 overflow-x-auto pb-1">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setCategoryFilter(cat)}
                className={`px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                  categoryFilter === cat
                    ? 'bg-white text-black font-bold shadow-md shadow-white/10'
                    : 'bg-zinc-900 text-zinc-300 hover:text-white border border-zinc-800'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Empty Search Result State */}
        {filteredProducts.length === 0 && (
          <div className="text-center py-16 px-6 rounded-2xl bg-zinc-900/80 border border-zinc-800 max-w-md mx-auto space-y-3 my-8">
            <Search className="w-10 h-10 text-zinc-500 mx-auto animate-pulse" />
            <h3 className="text-base font-bold text-white font-['Space_Grotesk']">No Products Found</h3>
            <p className="text-xs text-zinc-400">
              No products match "{searchQuery}". Try searching for another keyword or reset the category filter.
            </p>
            <button
              onClick={() => { setSearchQuery(''); setCategoryFilter('All'); }}
              className="px-4 py-2 rounded-xl bg-zinc-800 text-zinc-200 border border-zinc-700 text-xs font-mono font-bold hover:bg-zinc-700 transition-all"
            >
              Clear Search Filters
            </button>
          </div>
        )}

        {/* Products Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {filteredProducts.map((product) => {
            const isWishlisted = wishlistIds.includes(product.id);
            const productReviewsList = reviews.filter(r => r.productId === product.id);
            const avgRating = productReviewsList.length > 0 
              ? (productReviewsList.reduce((acc, r) => acc + r.rating, 0) / productReviewsList.length).toFixed(1)
              : (product.rating || 5.0).toFixed(1);
            const totalReviewsCount = productReviewsList.length > 0 ? productReviewsList.length : (product.reviewsCount || 0);

            return (
            <div
              key={product.id}
              className={`glass-card glass-card-hover rounded-2xl overflow-hidden border flex flex-col justify-between group cursor-pointer bg-zinc-950/80 transition-all ${
                isWishlisted
                  ? 'border-rose-500/60 shadow-lg shadow-rose-500/15 ring-1 ring-rose-500/30'
                  : 'border-zinc-800 hover:border-zinc-700'
              }`}
              onClick={() => setViewDetailsProduct(product)}
            >
              <div>
                {/* Image & Video Badge */}
                <div className="relative aspect-video sm:aspect-square overflow-hidden bg-black">
                  <img
                    src={product.image}
                    alt={product.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-90"
                  />
                  
                  {/* Top Left: Tag & Wishlist Status Badge */}
                  <div className="absolute top-3 left-3 flex flex-col items-start gap-1.5 z-10">
                    {product.tag && (
                      <span className="px-2.5 py-1 rounded-full bg-black/90 border border-zinc-700 text-zinc-200 font-mono text-[10px] font-bold shadow-lg backdrop-blur-md">
                        {product.tag}
                      </span>
                    )}
                    {isWishlisted && (
                      <span className="px-2 py-0.5 rounded-full bg-rose-600/95 text-white font-mono text-[9px] font-extrabold border border-rose-400 shadow-lg flex items-center gap-1 backdrop-blur-md animate-in fade-in zoom-in-95">
                        <Heart className="w-2.5 h-2.5 fill-white text-white" />
                        <span>Wishlisted</span>
                      </span>
                    )}
                  </div>

                  {/* Top Right: Wishlist Toggle + Discount */}
                  <div className="absolute top-3 right-3 flex flex-col items-end gap-1.5 z-10">
                    {onToggleWishlist && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleWishlistToggleWithFeedback(product);
                        }}
                        className={`p-2.5 rounded-full backdrop-blur-md border transition-all duration-200 shadow-xl group/wish ${
                          isWishlisted
                            ? 'bg-rose-600 text-white border-rose-400 ring-2 ring-rose-400/50 scale-110 shadow-rose-600/50'
                            : 'bg-black/75 text-zinc-300 hover:text-white border-zinc-700 hover:border-rose-400/60 hover:bg-black/90'
                        }`}
                        title={isWishlisted ? 'Remove from Wishlist (পছন্দের তালিকা থেকে সরান)' : 'Add to Wishlist (পছন্দের তালিকায় রাখুন)'}
                      >
                        <Heart className={`w-4 h-4 transition-transform duration-200 ${isWishlisted ? 'fill-white text-white scale-110' : 'text-zinc-300 group-hover/wish:text-rose-400 group-hover/wish:scale-110'}`} />
                      </button>
                    )}

                    {isProductDiscountActive(product) && (
                      <div className="flex flex-col items-end gap-1">
                        <span className="px-2.5 py-0.5 rounded-full bg-rose-500 text-white font-mono text-[10px] font-black shadow-lg flex items-center gap-1 border border-rose-400/60 animate-in fade-in">
                          <Flame className="w-3 h-3 text-white fill-white" />
                          {product.discountPercent || Math.round(((product.originalPrice! - product.price) / product.originalPrice!) * 100)}% OFF
                        </span>
                        {product.discountValidUntil && getRemainingTime(product.discountValidUntil) && !getRemainingTime(product.discountValidUntil)?.isExpired && (
                          <span className="px-2 py-0.5 rounded-md bg-black/90 text-amber-300 border border-zinc-700 text-[9px] font-mono font-bold shadow-md flex items-center gap-1 backdrop-blur-md">
                            <Clock className="w-2.5 h-2.5 text-amber-400" />
                            {getRemainingTime(product.discountValidUntil)?.badgeText}
                          </span>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Multi-photo & video badges */}
                  <div className="absolute bottom-3 left-3 flex items-center gap-1">
                    {((product.images && product.images.length > 0) || (product.videoUrls && product.videoUrls.length > 0) || product.videoUrl) && (
                      <span className="px-2 py-0.5 rounded-md bg-black/90 border border-zinc-700 text-zinc-200 font-mono text-[10px] font-bold shadow-md backdrop-blur-md flex items-center gap-1">
                        <ImageIcon className="w-3 h-3 text-white" />
                        {1 + (product.images?.length || 0)} Pics
                        {((product.videoUrls?.length || 0) > 0 || product.videoUrl) && (
                          <>
                            <span>•</span>
                            <Play className="w-2.5 h-2.5 fill-white text-white" />
                            {(product.videoUrls?.length || (product.videoUrl ? 1 : 0))} Vids
                          </>
                        )}
                      </span>
                    )}
                  </div>

                  {/* Stock Status Badge */}
                  <span
                    className={`absolute bottom-3 right-3 px-2 py-0.5 rounded text-[10px] font-mono border backdrop-blur-md font-bold ${
                      product.stock > 5
                        ? 'bg-black/90 text-emerald-300 border-emerald-500/40'
                        : product.stock > 0
                        ? 'bg-amber-950/90 text-amber-300 border-amber-500/60 animate-pulse'
                        : 'bg-rose-950/90 text-rose-300 border-rose-500/70'
                    }`}
                  >
                    {product.stock > 5
                      ? `Stock: ${product.stock}`
                      : product.stock > 0
                      ? `⚡ Low Stock: Only ${product.stock} Left`
                      : 'OUT OF STOCK (স্টক শেষ)'}
                  </span>
                </div>

                {/* Product Info */}
                <div className="p-5">
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-[10px] font-mono text-zinc-400 uppercase tracking-wider block">
                      {product.category}
                    </span>
                    
                    {/* Rating preview */}
                    <div className="flex items-center gap-1 bg-zinc-900/80 px-2 py-0.5 rounded-md border border-zinc-800 text-[10px] font-mono text-amber-400">
                      <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                      <span className="font-bold text-white">{avgRating}</span>
                      {totalReviewsCount > 0 && (
                        <span className="text-zinc-500">({totalReviewsCount})</span>
                      )}
                    </div>
                  </div>

                  <h3 className="text-base font-bold text-white font-['Space_Grotesk'] group-hover:text-zinc-200 transition-colors mb-1.5">
                    {product.name}
                  </h3>

                  {/* Color / Variant Swatches Preview */}
                  {product.variants && (
                    <div className="flex items-center gap-1.5 mb-2.5 flex-wrap">
                      {product.variants.colors && product.variants.colors.length > 0 && (
                        <div className="flex items-center gap-1">
                          {product.variants.colors.map((c) => (
                            <span
                              key={c.name}
                              className="w-2.5 h-2.5 rounded-full border border-zinc-700 shadow-sm"
                              style={{ backgroundColor: c.hex || '#ffffff' }}
                              title={c.name}
                            />
                          ))}
                        </div>
                      )}
                      {product.variants.specs && product.variants.specs.length > 0 && (
                        <span className="text-[9px] font-mono text-zinc-400 bg-zinc-900 px-1.5 py-0.5 rounded border border-zinc-800">
                          {product.variants.specs.length} Options
                        </span>
                      )}
                    </div>
                  )}

                  <p className="text-xs text-zinc-400 line-clamp-2 leading-relaxed mb-4">
                    {product.description}
                  </p>
                </div>
              </div>

              {/* Price & Order Action Bottom Bar */}
              <div 
                className="p-4 pt-3 border-t border-zinc-800/80 flex flex-col gap-3 mt-auto bg-black rounded-b-2xl"
                onClick={(e) => e.stopPropagation()}
              >
                {/* Large Prominent Price Display */}
                <div className="p-3 rounded-xl bg-zinc-900/90 border border-zinc-800 flex items-center justify-between shadow-inner">
                  <div>
                    <div className="flex items-center gap-1.5 mb-0.5">
                      <span className="text-[10px] font-mono font-bold text-zinc-400 tracking-wider">OFFICIAL PRICE</span>
                      {product.originalPrice && product.originalPrice > product.price && (
                        <span className="px-1.5 py-0.2 rounded bg-rose-500/20 text-rose-300 font-mono font-bold text-[9px] border border-rose-500/30">
                          SAVE ৳{product.originalPrice - product.price}
                        </span>
                      )}
                    </div>
                    <div className="flex items-baseline gap-2 flex-wrap">
                      <span className="text-2xl sm:text-3xl font-black text-white font-mono tracking-tight drop-shadow-sm">
                        ৳{product.price}
                      </span>
                      {product.originalPrice && product.originalPrice > product.price && (
                        <span className="text-xs sm:text-sm font-mono text-zinc-500 line-through">
                          ৳{product.originalPrice}
                        </span>
                      )}
                      <span className="text-[10px] font-mono text-zinc-400 font-semibold uppercase">BDT</span>
                    </div>
                  </div>

                  <div className="text-right">
                    <span
                      className={`text-[10px] font-mono font-bold px-2 py-1 rounded-lg border block ${
                        product.stock > 5
                          ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                          : product.stock > 0
                          ? 'bg-amber-500/10 text-amber-300 border-amber-500/30'
                          : 'bg-rose-500/10 text-rose-400 border-rose-500/30'
                      }`}
                    >
                      {product.stock > 0 ? `${product.stock} In Stock` : 'Stock Out'}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => handleAddToCartClick(product, 1)}
                    disabled={product.stock <= 0}
                    className={`py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all border ${
                      addedProductId === product.id
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-400/60 shadow-md shadow-emerald-950/40'
                        : product.stock > 0
                        ? 'bg-zinc-900 text-white hover:bg-zinc-800 border-zinc-700 hover:border-zinc-500 shadow-sm'
                        : 'bg-zinc-900 text-zinc-600 border-zinc-800 cursor-not-allowed'
                    }`}
                    title={product.stock <= 0 ? 'Out of stock' : 'Add to Cart (কার্টে যোগ করুন)'}
                  >
                    {addedProductId === product.id ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Added!</span>
                      </>
                    ) : (
                      <>
                        <ShoppingCart className="w-3.5 h-3.5 text-white" />
                        <span>Add to Cart</span>
                      </>
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={() => handleOpenCheckout(product)}
                    className={`py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-md ${
                      product.stock > 0
                        ? 'bg-white hover:bg-zinc-200 text-black font-bold shadow-white/10'
                        : 'bg-zinc-800 hover:bg-zinc-700 text-white'
                    }`}
                  >
                    <ShoppingBag className="w-3.5 h-3.5" />
                    <span>{product.stock > 0 ? 'Buy Now' : 'Pre-Order'}</span>
                  </button>
                </div>
              </div>

            </div>
          );
        })}
        </div>

        {/* Order Success Banner Notice */}
        {orderSuccess && (
          <div className="mt-8 p-6 rounded-2xl bg-emerald-950/40 border border-emerald-500/50 glass-card text-center space-y-3 animate-in fade-in duration-300">
            <div className="flex items-center justify-center gap-2 text-emerald-400 font-bold text-lg font-['Space_Grotesk']">
              <CheckCircle2 className="w-6 h-6" />
              Order Placed Successfully! (Order ID: <span className="font-mono">{orderSuccess.id}</span>)
            </div>
            <p className="text-xs text-slate-300">
              Thank you, <strong className="text-white">{orderSuccess.customerName}</strong>! Your order for <strong className="text-cyan-300">{orderSuccess.items[0]?.productName}</strong> (Total: ৳{orderSuccess.totalAmount} BDT) has been received and added to our order queue.
            </p>
            <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
              <button
                onClick={() => setViewReceiptOrder(orderSuccess)}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-400 to-indigo-500 text-slate-950 font-bold text-xs flex items-center gap-2 shadow-lg hover:from-cyan-300"
              >
                <FileText className="w-4 h-4" />
                View Customer Confirmation Receipt
              </button>
              {onOpenTracking && (
                <button
                  onClick={() => onOpenTracking(orderSuccess.id)}
                  className="px-4 py-2 rounded-xl bg-cyan-500/20 border border-cyan-500/50 text-cyan-300 font-bold text-xs flex items-center gap-2 shadow-md hover:bg-cyan-500/30"
                >
                  <Truck className="w-4 h-4 text-cyan-400" />
                  Live Track This Order
                </button>
              )}
            </div>
          </div>
        )}

      </div>

      {/* Customer Order Confirmation Receipt Modal */}
      <OrderReceiptModal
        order={viewReceiptOrder}
        onClose={() => setViewReceiptOrder(null)}
      />

      {/* Customer Interactive Product Detail & Multi-Media Showcase Modal */}
      <ProductDetailModal
        product={viewDetailsProduct}
        aboutInfo={aboutInfo}
        isOpen={!!viewDetailsProduct}
        onClose={() => setViewDetailsProduct(null)}
        onAddToCart={handleAddToCartClick}
        onBuyNow={(prod, qty, col, spc) => {
          setViewDetailsProduct(null);
          handleOpenCheckout(prod);
        }}
        addedProductId={addedProductId}
        reviews={reviews}
        onAddReview={onAddReview}
        isWishlisted={viewDetailsProduct ? wishlistIds.includes(viewDetailsProduct.id) : false}
        onToggleWishlist={onToggleWishlist}
      />

      {/* Quick Order Modal */}
      {selectedProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
          <div className="glass-card border border-zinc-800 max-w-lg w-full rounded-2xl p-5 sm:p-8 relative shadow-2xl bg-zinc-950 max-h-[90vh] overflow-y-auto custom-scrollbar my-auto text-white">
            
            <button
              onClick={() => setSelectedProduct(null)}
              className="absolute top-4 right-4 p-2 rounded-lg bg-zinc-900 text-zinc-400 hover:text-white border border-zinc-800"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="space-y-4 mb-6 pb-4 border-b border-zinc-800">
              <div className="flex items-center gap-3">
                <img
                  src={selectedProduct.image}
                  alt={selectedProduct.name}
                  referrerPolicy="no-referrer"
                  className="w-16 h-16 rounded-xl object-cover border border-zinc-800 shrink-0"
                />
                <div>
                  <span className="text-[10px] font-mono text-zinc-400 uppercase">{selectedProduct.category}</span>
                  <h3 className="text-lg font-bold text-white font-['Space_Grotesk']">{selectedProduct.name}</h3>
                  <p className="text-xs font-mono text-zinc-300">৳{selectedProduct.price} / unit</p>
                </div>
              </div>

              {selectedProduct.videoUrl && (
                <div className="rounded-xl overflow-hidden border border-zinc-800 bg-black aspect-video">
                  {getEmbedVideoUrl(selectedProduct.videoUrl)?.includes('youtube.com/embed') ? (
                    <iframe
                      src={getEmbedVideoUrl(selectedProduct.videoUrl)!}
                      title={`${selectedProduct.name} Video Demo`}
                      className="w-full h-full border-0"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen
                    />
                  ) : (
                    <video
                      src={selectedProduct.videoUrl}
                      controls
                      className="w-full h-full object-contain"
                    />
                  )}
                </div>
              )}
            </div>

            <form onSubmit={handleCheckoutSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-mono text-zinc-300 block mb-1">Your Full Name *</label>
                  <input
                    type="text"
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="e.g. Tanvir Hossain"
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-zinc-500"
                  />
                </div>
                <div>
                  <label className="text-xs font-mono text-zinc-300 block mb-1">Email Address *</label>
                  <input
                    type="email"
                    required
                    value={customerEmail}
                    onChange={(e) => setCustomerEmail(e.target.value)}
                    placeholder="tanvir@example.com"
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-zinc-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-mono text-zinc-300 block mb-1">Phone Number (শুধুমাত্র নম্বর) *</label>
                  <input
                    type="tel"
                    required
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value.replace(/\D/g, ''))}
                    placeholder="e.g. 01700000000"
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-zinc-500 font-mono"
                  />
                </div>
                <div>
                  <label className="text-xs font-mono text-white font-bold block mb-1">
                    Quantity *
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={quantity === 0 ? '' : quantity}
                    onChange={(e) => setQuantity(Math.max(0, parseInt(e.target.value) || 0))}
                    placeholder="0"
                    className={`w-full bg-zinc-900 border rounded-xl px-3.5 py-2 text-xs font-extrabold focus:outline-none font-mono ${
                      quantity > selectedProduct.stock
                        ? 'border-rose-500 text-rose-300'
                        : 'border-zinc-800 text-white focus:border-zinc-500'
                    }`}
                  />
                  {quantity > selectedProduct.stock ? (
                    <div className="mt-1.5 p-2 rounded-lg bg-rose-950/90 border border-rose-500/60 text-[11px] text-rose-200 font-mono leading-tight shadow-md">
                      ⚠️ We currently do not have this many in stock. We have <strong>{selectedProduct.stock}</strong> available. You can order up to <strong>{selectedProduct.stock}</strong> units max.
                    </div>
                  ) : (
                    <span className="text-[10px] text-zinc-400 font-mono block mt-0.5">
                      {quantity === 0 ? '⚠️ Enter quantity' : `Available Stock: ${selectedProduct.stock} Pcs`}
                    </span>
                  )}
                </div>
              </div>

              {/* Delivery Zone Selector */}
              <div className="space-y-1.5">
                <label className="text-xs font-mono text-zinc-300 font-bold block flex items-center justify-between">
                  <span>Delivery Location *</span>
                  <span className="text-[10px] text-zinc-400 font-normal">Dhaka: ৳{chargeInside} | Outside: ৳{chargeOutside}</span>
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setDeliveryZone('Inside Dhaka')}
                    className={`p-2.5 rounded-xl border text-xs font-bold font-mono text-left transition-all flex flex-col gap-0.5 ${
                      deliveryZone === 'Inside Dhaka'
                        ? 'bg-zinc-800 border-white text-white shadow-md shadow-white/10 scale-[1.01]'
                        : 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:text-white'
                    }`}
                  >
                    <span className="text-white">Inside Dhaka City</span>
                    <span className="text-[10px] text-zinc-300 font-normal">Delivery Fee: ৳{chargeInside} BDT</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setDeliveryZone('Outside Dhaka')}
                    className={`p-2.5 rounded-xl border text-xs font-bold font-mono text-left transition-all flex flex-col gap-0.5 ${
                      deliveryZone === 'Outside Dhaka'
                        ? 'bg-zinc-800 border-white text-white shadow-md shadow-white/10 scale-[1.01]'
                        : 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:text-white'
                    }`}
                  >
                    <span className="text-white">Outside Dhaka</span>
                    <span className="text-[10px] text-zinc-300 font-normal">Delivery Fee: ৳{chargeOutside} BDT</span>
                  </button>
                </div>
                {aboutInfo?.deliveryNote && (
                  <div className="p-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-zinc-300 font-mono flex items-center gap-2">
                    <Truck className="w-4 h-4 text-white shrink-0" />
                    <span>{aboutInfo.deliveryNote}</span>
                  </div>
                )}
              </div>

              <div>
                <label className="text-xs font-mono text-zinc-300 block mb-1">Shipping Address *</label>
                <textarea
                  required
                  rows={2}
                  value={shippingAddress}
                  onChange={(e) => setShippingAddress(e.target.value)}
                  placeholder="House, Road, Area, City..."
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-zinc-500"
                />
              </div>

              <div>
                <label className="text-xs font-mono text-zinc-400 block mb-1">Order Notes (Optional)</label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Special instructions or delivery time preference..."
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3.5 py-2 text-xs text-zinc-300 focus:outline-none focus:border-zinc-500"
                />
              </div>

              {/* PAYMENT METHOD SELECTION */}
              <div className="space-y-2.5 pt-2 border-t border-zinc-800">
                <label className="text-xs font-mono text-zinc-300 font-bold block flex items-center justify-between">
                  <span>Select Payment Method *</span>
                  <span className="text-[10px] text-zinc-400 font-normal">bKash, Nagad, Rocket, COD</span>
                </label>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('bKash')}
                    className={`p-2.5 rounded-xl border text-xs font-bold font-mono flex items-center justify-center gap-1.5 transition-all ${
                      paymentMethod === 'bKash'
                        ? 'bg-pink-950/80 border-pink-500 text-pink-300 shadow-lg shadow-pink-950/50 scale-[1.02]'
                        : 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:text-white'
                    }`}
                  >
                    {aboutInfo?.bkashLogoUrl ? (
                      <img src={aboutInfo.bkashLogoUrl} alt="bKash" referrerPolicy="no-referrer" className="w-4 h-4 object-cover rounded shrink-0" />
                    ) : (
                      <Smartphone className="w-3.5 h-3.5 text-pink-400" />
                    )}
                    bKash (বিকাশ)
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMethod('Nagad')}
                    className={`p-2.5 rounded-xl border text-xs font-bold font-mono flex items-center justify-center gap-1.5 transition-all ${
                      paymentMethod === 'Nagad'
                        ? 'bg-amber-950/80 border-amber-500 text-amber-300 shadow-lg shadow-amber-950/50 scale-[1.02]'
                        : 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:text-white'
                    }`}
                  >
                    {aboutInfo?.nagadLogoUrl ? (
                      <img src={aboutInfo.nagadLogoUrl} alt="Nagad" referrerPolicy="no-referrer" className="w-4 h-4 object-cover rounded shrink-0" />
                    ) : (
                      <Smartphone className="w-3.5 h-3.5 text-amber-400" />
                    )}
                    Nagad (নগদ)
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMethod('Rocket')}
                    className={`p-2.5 rounded-xl border text-xs font-bold font-mono flex items-center justify-center gap-1.5 transition-all ${
                      paymentMethod === 'Rocket'
                        ? 'bg-purple-950/80 border-purple-500 text-purple-300 shadow-lg shadow-purple-950/50 scale-[1.02]'
                        : 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:text-white'
                    }`}
                  >
                    {aboutInfo?.rocketLogoUrl ? (
                      <img src={aboutInfo.rocketLogoUrl} alt="Rocket" referrerPolicy="no-referrer" className="w-4 h-4 object-cover rounded shrink-0" />
                    ) : (
                      <Smartphone className="w-3.5 h-3.5 text-purple-400" />
                    )}
                    Rocket (রকেট)
                  </button>

                  {aboutInfo?.enableCashOnDelivery !== false && (
                    <button
                      type="button"
                      onClick={() => setPaymentMethod('Cash on Delivery')}
                      className={`p-2.5 rounded-xl border text-xs font-bold font-mono flex items-center justify-center gap-1.5 transition-all ${
                        paymentMethod === 'Cash on Delivery'
                          ? 'bg-emerald-950/80 border-emerald-500 text-emerald-300 shadow-lg shadow-emerald-950/50 scale-[1.02]'
                          : 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:text-white'
                      }`}
                    >
                      <Package className="w-3.5 h-3.5 text-emerald-400" />
                      Cash on Delivery
                    </button>
                  )}

                  {aboutInfo?.enableCardPayment !== false && (
                    <button
                      type="button"
                      onClick={() => setPaymentMethod('Card / Bank Transfer')}
                      className={`p-2.5 rounded-xl border text-xs font-bold font-mono flex items-center justify-center gap-1.5 transition-all col-span-2 sm:col-span-1 ${
                        paymentMethod === 'Card / Bank Transfer'
                          ? 'bg-zinc-800 border-white text-white shadow-lg shadow-white/10 scale-[1.02]'
                          : 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:text-white'
                      }`}
                    >
                      <CreditCard className="w-3.5 h-3.5 text-white" />
                      Card / Bank
                    </button>
                  )}
                </div>

                {/* Details Box for Mobile MFS Payments */}
                {(paymentMethod === 'bKash' || paymentMethod === 'Nagad' || paymentMethod === 'Rocket') && (
                  <div className={`p-4 rounded-xl border space-y-3 font-mono text-xs animate-in fade-in duration-200 ${
                    paymentMethod === 'bKash' ? 'bg-pink-950/30 border-pink-500/40' :
                    paymentMethod === 'Nagad' ? 'bg-amber-950/30 border-amber-500/40' :
                    'bg-purple-950/30 border-purple-500/40'
                  }`}>
                    {(() => {
                      const rawTargetNum = paymentMethod === 'bKash' ? (aboutInfo?.bkashNumber || '01700000000') :
                                            paymentMethod === 'Nagad' ? (aboutInfo?.nagadNumber || '01800000000') :
                                            (aboutInfo?.rocketNumber || '01900000000');
                      const cleanDigits = extractCleanPhoneNumber(rawTargetNum);
                      const isCopied = copiedNumber === cleanDigits;

                      return (
                        <>
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2 font-bold text-white">
                              {paymentMethod === 'bKash' && aboutInfo?.bkashLogoUrl && (
                                <img src={aboutInfo.bkashLogoUrl} alt="bKash Logo" referrerPolicy="no-referrer" className="w-5 h-5 object-cover rounded" />
                              )}
                              {paymentMethod === 'Nagad' && aboutInfo?.nagadLogoUrl && (
                                <img src={aboutInfo.nagadLogoUrl} alt="Nagad Logo" referrerPolicy="no-referrer" className="w-5 h-5 object-cover rounded" />
                              )}
                              {paymentMethod === 'Rocket' && aboutInfo?.rocketLogoUrl && (
                                <img src={aboutInfo.rocketLogoUrl} alt="Rocket Logo" referrerPolicy="no-referrer" className="w-5 h-5 object-cover rounded" />
                              )}
                              <span>Official {paymentMethod} (Send Money):</span>
                            </div>
                            <button
                              type="button"
                              onClick={() => handleCopyNumber(rawTargetNum)}
                              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 shadow-sm ${
                                isCopied 
                                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold' 
                                  : 'bg-zinc-800 text-zinc-200 hover:bg-zinc-700 border border-zinc-700'
                              }`}
                              title="ক্লিক করলে শুধুমাত্র মোবাইল নম্বরটি কপি হবে"
                            >
                              {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                              <span>{isCopied ? `Copied (${cleanDigits})` : 'Copy Number'}</span>
                            </button>
                          </div>

                          <div 
                            onClick={() => handleCopyNumber(rawTargetNum)}
                            className="text-base font-extrabold text-white tracking-wider bg-black px-3.5 py-2.5 rounded-xl border border-zinc-800 hover:border-zinc-600 cursor-pointer flex items-center justify-between group transition-all"
                            title="ক্লিক করে শুধুমাত্র নম্বর কপি করুন"
                          >
                            <div className="flex items-center gap-2">
                              <span className="text-white text-lg font-mono font-black">{cleanDigits}</span>
                              <span className="text-[11px] font-normal text-zinc-400 font-sans">({paymentMethod} Personal)</span>
                            </div>
                            <span className="text-[10px] text-zinc-400 group-hover:text-white font-mono flex items-center gap-1">
                              <Copy className="w-3 h-3" />
                              Click to Copy
                            </span>
                          </div>

                          <p className="text-[11px] text-zinc-400 leading-relaxed">
                            {aboutInfo?.paymentInstructions || `Send Money ৳${finalTotalAmount} BDT to our ${paymentMethod} Personal number above. (কপি বাটনে ক্লিক করলে শুধুমাত্র নম্বরটি কপি হয়ে যাবে যাতে সহজে বিকাশ/নগদে পেস্ট করতে পারেন)`}
                          </p>
                        </>
                      );
                    })()}

                    <div className="p-2.5 rounded-lg bg-emerald-950/40 border border-emerald-500/40 text-[11px] text-emerald-300 font-sans flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                      <span><strong>সহজ পেমেন্ট:</strong> টাকা পাঠানোর মোবাইল নম্বর দিলেই যথেষ্ট। ট্রানজেকশন আইডি (TrxID) দেওয়া বাধ্যতামূলক নয়!</span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <label className="text-[10px] text-zinc-300 font-bold">
                            Sender Mobile No (টাকা পাঠানোর নম্বর) *
                          </label>
                          {customerPhone && paymentSenderPhone !== customerPhone && (
                            <button
                              type="button"
                              onClick={() => setPaymentSenderPhone(customerPhone)}
                              className="text-[10px] text-cyan-400 hover:text-cyan-300 underline font-mono"
                            >
                              Use My Phone
                            </button>
                          )}
                        </div>
                        <input
                          type="tel"
                          required
                          value={paymentSenderPhone || customerPhone}
                          onChange={(e) => setPaymentSenderPhone(e.target.value.replace(/\D/g, ''))}
                          placeholder="e.g. 01712345678"
                          className="w-full bg-black border border-zinc-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-zinc-400 font-mono"
                        />
                        <span className="text-[9px] text-zinc-400 mt-0.5 block">
                          যে বিকাশ/নগদ/রকেট নম্বর থেকে Send Money করেছেন
                        </span>
                      </div>

                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <label className="text-[10px] text-zinc-400 font-bold">
                            Transaction ID (TrxID)
                          </label>
                          <span className="text-[10px] text-emerald-400 font-mono font-semibold">ঐচ্ছিক (Optional)</span>
                        </div>
                        <input
                          type="text"
                          value={paymentTrxId}
                          onChange={(e) => setPaymentTrxId(e.target.value)}
                          placeholder="থাকলে লিখুন (ঐচ্ছিক)"
                          className="w-full bg-black border border-zinc-800 rounded-lg px-3 py-1.5 text-xs text-zinc-300 focus:outline-none focus:border-zinc-500 uppercase font-mono"
                        />
                        <span className="text-[9px] text-zinc-500 mt-0.5 block">
                          না দিলেও সমস্যা নেই, মোবাইল নম্বর দিয়ে ভেরিফাই হবে
                        </span>
                      </div>
                    </div>
                  </div>
                )}

                {paymentMethod === 'Cash on Delivery' && (
                  <div className="p-3.5 rounded-xl bg-emerald-950/30 border border-emerald-500/40 text-xs text-emerald-200 font-mono flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                    <span>পণ্য হাতে পেয়ে নগদ মূল্য পরিশোধ করুন।</span>
                  </div>
                )}

                {paymentMethod === 'Card / Bank Transfer' && (
                  <div className="p-3.5 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-zinc-300 font-mono space-y-1">
                    <div className="font-bold text-white">Bank Deposit Details:</div>
                    <div>Account Name: {aboutInfo?.companyName || 'Lewra World'}</div>
                    <div>Bank & Branch: City Bank, Banani Branch, Dhaka</div>
                    <div>A/C Number: 11029384759201</div>
                  </div>
                )}
              </div>

              {/* Advance Payment Amount Option */}
              <div className="p-3.5 rounded-xl bg-zinc-900/90 border border-zinc-800 space-y-2">
                <label className="text-xs font-mono text-emerald-300 font-bold flex items-center justify-between">
                  <span>Advance Paid Amount (অগ্রিম প্রদান কত টাকা করেছেন)</span>
                  <span className="text-[10px] text-amber-300 font-semibold">Due: ৳{effectiveDueAmount} BDT</span>
                </label>
                <div className="flex gap-2 items-center">
                  <div className="relative flex-1">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400 font-mono text-xs">৳</span>
                    <input
                      type="number"
                      min="0"
                      max={finalTotalAmount}
                      value={advancePaymentInput}
                      onChange={(e) => setAdvancePaymentInput(e.target.value)}
                      placeholder={paymentMethod === 'Cash on Delivery' ? "0" : `${finalTotalAmount}`}
                      className="w-full bg-black border border-zinc-800 focus:border-emerald-400 rounded-xl pl-7 pr-3 py-2 text-xs text-emerald-300 font-bold font-mono focus:outline-none"
                    />
                  </div>
                  <div className="flex gap-1">
                    <button
                      type="button"
                      onClick={() => setAdvancePaymentInput(`${finalTotalAmount}`)}
                      className="px-2.5 py-2 bg-zinc-800 hover:bg-zinc-700 text-[10px] text-white rounded-lg font-mono font-bold border border-zinc-700"
                      title="Full Total Amount"
                    >
                      Full
                    </button>
                    <button
                      type="button"
                      onClick={() => setAdvancePaymentInput(`${deliveryCharge}`)}
                      className="px-2.5 py-2 bg-zinc-800 hover:bg-zinc-700 text-[10px] text-zinc-300 rounded-lg font-mono font-bold border border-zinc-700"
                      title="Delivery Charge"
                    >
                      Delivery
                    </button>
                    <button
                      type="button"
                      onClick={() => setAdvancePaymentInput('0')}
                      className="px-2.5 py-2 bg-zinc-800 hover:bg-zinc-700 text-[10px] text-amber-300 rounded-lg font-mono font-bold border border-zinc-700"
                      title="Zero Advance"
                    >
                      0
                    </button>
                  </div>
                </div>
                <p className="text-[11px] text-zinc-400 font-mono">
                  {effectiveAdvancePaid > 0 ? (
                    <span className="text-emerald-400">
                      ✓ Advance Paid: <strong>৳{effectiveAdvancePaid} BDT</strong>. Remaining Due on Delivery: <strong>৳{effectiveDueAmount} BDT</strong>
                    </span>
                  ) : (
                    <span className="text-amber-300">
                      • No advance entered. Total <strong>৳{finalTotalAmount} BDT</strong> will be due on delivery.
                    </span>
                  )}
                </p>
              </div>

              {/* Promo Coupon Code Box */}
              <div>
                <label className="text-xs font-mono text-zinc-300 block mb-1">Have a Promo / Discount Coupon Code?</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={couponCode}
                    onChange={(e) => setCouponCode(e.target.value)}
                    placeholder="e.g. LEWRA10, DISCOUNT20"
                    className="flex-1 bg-black border border-zinc-800 rounded-xl px-3.5 py-2 text-xs text-white font-mono uppercase focus:outline-none focus:border-zinc-500"
                  />
                  <button
                    type="button"
                    onClick={handleApplyCoupon}
                    className="px-4 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white border border-zinc-700 text-xs font-mono font-bold transition-all"
                  >
                    Apply Code
                  </button>
                </div>
                {couponMsg && (
                  <p className={`text-[11px] font-mono mt-1 ${couponMsg.type === 'success' ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {couponMsg.text}
                  </p>
                )}
              </div>

              {/* Total Payment Breakdown */}
              <div className="p-4 rounded-2xl bg-black border border-zinc-800 space-y-2 font-mono text-xs shadow-xl shadow-black/40">
                <div className="flex items-center justify-between text-zinc-400">
                  <span>Product Subtotal ({quantity} item):</span>
                  <span className="text-white font-bold">৳{subtotal} BDT</span>
                </div>
                {discountAmount > 0 && (
                  <div className="flex items-center justify-between text-emerald-400 font-semibold">
                    <span>Coupon Discount ({appliedCoupon?.code}):</span>
                    <span>-৳{discountAmount} BDT</span>
                  </div>
                )}
                <div className="flex items-center justify-between text-zinc-300">
                  <span>Delivery Charge ({deliveryZone}):</span>
                  <span className="font-bold">+৳{deliveryCharge} BDT</span>
                </div>
                <div className="pt-2.5 pb-1 border-t border-zinc-800 flex items-center justify-between bg-zinc-950 -mx-4 px-4">
                  <span className="text-white font-black text-xs sm:text-sm uppercase tracking-wide">TOTAL ORDER AMOUNT:</span>
                  <div className="flex items-baseline gap-1">
                    <span className="text-2xl sm:text-3xl font-black text-white tracking-tight drop-shadow-md">
                      ৳{finalTotalAmount}
                    </span>
                    <span className="text-xs text-zinc-400 font-bold">BDT</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 pt-2 border-t border-zinc-800 text-[11px]">
                  <div className="p-2 rounded-lg bg-emerald-950/40 border border-emerald-500/30 flex items-center justify-between">
                    <span className="text-emerald-300 font-bold">Advance Paid:</span>
                    <span className="font-mono font-extrabold text-emerald-400">৳{effectiveAdvancePaid} BDT</span>
                  </div>
                  <div className="p-2 rounded-lg bg-amber-950/40 border border-amber-500/30 flex items-center justify-between">
                    <span className="text-amber-300 font-bold">Due Amount:</span>
                    <span className="font-mono font-extrabold text-amber-400">৳{effectiveDueAmount} BDT</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                <button
                  type="button"
                  onClick={() => {
                    if (selectedProduct) {
                      handleAddToCartClick(selectedProduct, Math.max(1, quantity));
                      setSelectedProduct(null);
                    }
                  }}
                  disabled={quantity <= 0 || (selectedProduct && quantity > selectedProduct.stock)}
                  className="py-3 px-4 rounded-xl border border-zinc-700 bg-zinc-900 hover:bg-zinc-800 text-white font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-md disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <ShoppingCart className="w-4 h-4 text-white" />
                  <span>Add {quantity > 1 ? `(${quantity})` : ''} to Cart</span>
                </button>

                <button
                  type="submit"
                  className="py-3 px-4 rounded-xl bg-white hover:bg-zinc-200 text-black font-bold text-xs transition-all shadow-lg shadow-white/10 flex items-center justify-center gap-1.5"
                >
                  <CheckCircle2 className="w-4 h-4 text-black" />
                  <span>Confirm & Submit Order</span>
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

      {/* Floating Wishlist Interactive Notification Toast */}
      {wishlistToast && (
        <div className="fixed bottom-6 right-6 z-50 animate-in slide-in-from-bottom-5 duration-300">
          <div className={`px-4 py-3 rounded-2xl border shadow-2xl backdrop-blur-md flex items-center gap-3 text-xs font-mono font-bold ${
            wishlistToast.isAdded
              ? 'bg-rose-950/90 border-rose-500 text-rose-200 shadow-rose-950/60'
              : 'bg-zinc-900/90 border-zinc-700 text-zinc-300 shadow-black/80'
          }`}>
            <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${
              wishlistToast.isAdded ? 'bg-rose-600 text-white' : 'bg-zinc-800 text-zinc-400'
            }`}>
              <Heart className={`w-4 h-4 ${wishlistToast.isAdded ? 'fill-white' : ''}`} />
            </div>
            <div>
              <div className="text-white text-sm font-['Space_Grotesk'] font-bold">
                {wishlistToast.isAdded ? 'Wishlist Updated! (পছন্দের তালিকায় যুক্ত)' : 'Removed from Wishlist'}
              </div>
              <div className="text-zinc-400 text-[11px] font-normal">{wishlistToast.message}</div>
            </div>
            {onOpenWishlist && wishlistToast.isAdded && (
              <button
                type="button"
                onClick={() => {
                  setWishlistToast(null);
                  onOpenWishlist();
                }}
                className="ml-2 px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-[11px] font-bold transition-all shadow shrink-0"
              >
                View Wishlist
              </button>
            )}
          </div>
        </div>
      )}

    </section>
  );
};
