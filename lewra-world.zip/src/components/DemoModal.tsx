import React, { useState } from 'react';
import { X, Play, CheckCircle2, Key, Sparkles, ArrowRight, ShieldCheck, Zap } from 'lucide-react';

interface DemoModalProps {
  mode: 'keynote' | 'get-started' | null;
  onClose: () => void;
}

export const DemoModal: React.FC<DemoModalProps> = ({ mode, onClose }) => {
  const [email, setEmail] = useState('');
  const [organization, setOrganization] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [isPlaying, setIsPlaying] = useState(true);

  if (!mode) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="glass-card border border-slate-700/80 max-w-2xl w-full rounded-2xl p-6 sm:p-8 relative shadow-2xl">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-lg bg-slate-900 text-slate-400 hover:text-white border border-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {mode === 'keynote' ? (
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 font-mono text-[10px] uppercase border border-cyan-500/30">
                KEYNOTE REPLAY
              </span>
              <span className="text-xs text-slate-400 font-mono">Duration: 4m 20s</span>
            </div>

            <h3 className="text-2xl font-bold text-white font-['Space_Grotesk'] mb-4">
              Lewra World 3.0 Spatial Keynote
            </h3>

            {/* Video Mockup Frame */}
            <div className="relative rounded-xl overflow-hidden aspect-video border border-slate-800 bg-[#060913] mb-6 flex items-center justify-center group">
              <img
                src="/src/assets/images/lewra_hero_3d_1785996301280.jpg"
                alt="Keynote Visual"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover opacity-70"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent" />

              <button
                onClick={() => setIsPlaying(!isPlaying)}
                className="relative z-10 w-16 h-16 rounded-full bg-cyan-400 text-slate-950 flex items-center justify-center shadow-xl shadow-cyan-400/30 hover:scale-105 transition-transform"
              >
                <Play className="w-7 h-7 fill-current ml-1" />
              </button>

              <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between text-xs font-mono text-slate-300 z-10">
                <span>02:14 / 04:20</span>
                <span className="text-cyan-400 font-bold">1080p 60FPS Spatial Audio</span>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed mb-6">
              Watch CEO & Founder Dr. Elena Vance walk through sub-1ms spatial UI rendering, autonomous multi-agent node coordination, and lattice quantum encryption.
            </p>

            <button
              onClick={onClose}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-cyan-400 to-indigo-500 text-slate-950 font-bold text-xs hover:from-cyan-300 hover:to-indigo-400 transition-all"
            >
              Done Watching
            </button>
          </div>
        ) : (
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Sparkles className="w-4 h-4 text-cyan-400" />
              <span className="text-xs font-mono font-bold text-cyan-300 uppercase">EARLY ACCESS REGISTRATION</span>
            </div>

            <h3 className="text-2xl font-bold text-white font-['Space_Grotesk'] mb-2">
              Launch Your Lewra Workspace
            </h3>
            <p className="text-xs text-slate-400 mb-6">
              Claim your 14-day free developer pass with 100,000 spatial AI credits and instant API key generation.
            </p>

            {submitted ? (
              <div className="p-6 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-center space-y-3">
                <div className="w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <h4 className="text-lg font-bold text-white font-['Space_Grotesk']">Workspace Reserved!</h4>
                <p className="text-xs text-slate-300">
                  Your temporary API key: <code className="bg-slate-950 px-2 py-1 rounded text-cyan-300 font-mono">lwr_live_99214a_x82</code>
                </p>
                <button
                  onClick={onClose}
                  className="mt-4 px-6 py-2.5 rounded-xl bg-cyan-400 text-slate-950 font-bold text-xs"
                >
                  Enter Workspace Console
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="text-xs font-mono text-slate-300 block mb-1">Work Email</label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    placeholder="alex@company.com"
                    className="w-full bg-[#0C111E] border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-cyan-400"
                  />
                </div>

                <div>
                  <label className="text-xs font-mono text-slate-300 block mb-1">Organization / Project Name</label>
                  <input
                    type="text"
                    value={organization}
                    onChange={(e) => setOrganization(e.target.value)}
                    required
                    placeholder="Aetheria Labs"
                    className="w-full bg-[#0C111E] border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-cyan-400"
                  />
                </div>

                <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 text-[11px] text-slate-400 flex items-center gap-2">
                  <Key className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span>Instant provisioning. No credit card required.</span>
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 rounded-xl bg-gradient-to-r from-cyan-400 via-teal-300 to-indigo-400 hover:from-cyan-300 text-slate-950 font-bold text-xs shadow-lg shadow-cyan-500/20"
                >
                  Create Developer Pass & Issue Key
                </button>
              </form>
            )}
          </div>
        )}

      </div>
    </div>
  );
};
