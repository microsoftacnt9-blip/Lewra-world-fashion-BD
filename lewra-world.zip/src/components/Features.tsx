import React, { useState } from 'react';
import { FEATURES_DATA } from '../data/mockData';
import { FeatureItem } from '../types';
import { Cpu, Bot, ShieldCheck, Activity, Layout, Globe, ArrowRight, Check, Sparkles, Terminal, Code } from 'lucide-react';

interface FeaturesProps {
  onOpenGetStarted: () => void;
}

export const Features: React.FC<FeaturesProps> = ({ onOpenGetStarted }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [activeModalFeature, setActiveModalFeature] = useState<FeatureItem | null>(null);

  const categories = ['All', 'Spatial AI', 'Autonomous Workflows', 'Quantum Security', 'Real-time Analytics'];

  const filteredFeatures = selectedCategory === 'All'
    ? FEATURES_DATA
    : FEATURES_DATA.filter(f => f.category === selectedCategory);

  const renderIcon = (name: string) => {
    switch (name) {
      case 'Cpu': return <Cpu className="w-6 h-6 text-cyan-400" />;
      case 'Bot': return <Bot className="w-6 h-6 text-purple-400" />;
      case 'ShieldCheck': return <ShieldCheck className="w-6 h-6 text-emerald-400" />;
      case 'Activity': return <Activity className="w-6 h-6 text-amber-400" />;
      case 'Layout': return <Layout className="w-6 h-6 text-indigo-400" />;
      case 'Globe': return <Globe className="w-6 h-6 text-blue-400" />;
      default: return <Sparkles className="w-6 h-6 text-cyan-400" />;
    }
  };

  return (
    <section id="features" className="py-24 relative bg-[#070A12]">
      {/* Background Subtle Gradient Highlights */}
      <div className="absolute top-1/2 left-0 w-96 h-96 bg-purple-600/10 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute bottom-10 right-0 w-96 h-96 bg-cyan-500/10 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-900 border border-purple-500/30 text-purple-300 text-xs font-mono font-semibold uppercase tracking-wider mb-4">
            <Sparkles className="w-3.5 h-3.5 text-purple-400" />
            ENGINEERING EXCELLENCE
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight font-['Space_Grotesk'] mb-4">
            Architected for <span className="text-gradient-cyan">Uncompromising Performance</span>
          </h2>
          <p className="text-slate-400 text-base sm:text-lg">
            Lewra World combines high-density spatial algorithms with ultra-fast hardware micro-architectures.
          </p>
        </div>

        {/* Category Filters */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-12">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all duration-300 ${
                selectedCategory === cat
                  ? 'bg-gradient-to-r from-cyan-500/20 to-purple-500/20 text-cyan-300 border border-cyan-400/50 shadow-lg shadow-cyan-950/40'
                  : 'bg-slate-900/60 text-slate-400 hover:text-slate-200 border border-slate-800 hover:border-slate-700'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* 3-Column Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredFeatures.map((feature) => (
            <div
              key={feature.id}
              onClick={() => setActiveModalFeature(feature)}
              className="glass-card glass-card-hover rounded-2xl p-6 relative group cursor-pointer flex flex-col justify-between"
            >
              <div>
                {/* Top Row: Icon + Tag */}
                <div className="flex items-center justify-between mb-5">
                  <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800 group-hover:border-cyan-500/50 group-hover:bg-slate-800 transition-colors">
                    {renderIcon(feature.iconName)}
                  </div>
                  <span className="text-[11px] font-mono font-semibold px-2.5 py-1 rounded-full bg-slate-900 text-cyan-300 border border-slate-800">
                    {feature.tag}
                  </span>
                </div>

                {/* Title */}
                <h3 className="text-xl font-bold text-white group-hover:text-cyan-300 transition-colors mb-2 font-['Space_Grotesk']">
                  {feature.title}
                </h3>

                {/* Description */}
                <p className="text-sm text-slate-400 leading-relaxed mb-6">
                  {feature.description}
                </p>
              </div>

              {/* Bottom Row: Metrics & Action */}
              <div className="pt-4 border-t border-slate-800/80 flex items-center justify-between">
                <span className="text-xs font-mono text-slate-400 flex items-center gap-1">
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  {feature.metrics}
                </span>
                <span className="text-xs font-semibold text-cyan-400 group-hover:translate-x-1 transition-transform flex items-center gap-1">
                  Inspect Specs <ArrowRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Feature Inspection Modal */}
        {activeModalFeature && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
            <div className="glass-card border border-slate-700 max-w-xl w-full rounded-2xl p-6 sm:p-8 relative shadow-2xl">
              
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                    {renderIcon(activeModalFeature.iconName)}
                  </div>
                  <div>
                    <span className="text-xs font-mono text-cyan-400 uppercase tracking-wider">{activeModalFeature.category}</span>
                    <h3 className="text-2xl font-bold text-white">{activeModalFeature.title}</h3>
                  </div>
                </div>
                <button
                  onClick={() => setActiveModalFeature(null)}
                  className="p-2 rounded-lg bg-slate-900 text-slate-400 hover:text-white border border-slate-800"
                >
                  ✕
                </button>
              </div>

              <p className="text-slate-300 text-sm mb-6 leading-relaxed">
                {activeModalFeature.description}
              </p>

              {/* Simulated Code / SDK Snippet */}
              <div className="bg-[#050811] rounded-xl p-4 border border-slate-800 mb-6 font-mono text-xs text-slate-300">
                <div className="flex items-center justify-between pb-2 mb-3 border-b border-slate-800/80 text-slate-500">
                  <span className="flex items-center gap-1.5 text-cyan-400 font-sans">
                    <Terminal className="w-3.5 h-3.5" /> SDK Initialization
                  </span>
                  <span>TypeScript</span>
                </div>
                <pre className="overflow-x-auto text-slate-300">
                  <code>
{`import { LewraSpatialClient } from '@lewra/spatial-sdk';

const lewra = new LewraSpatialClient({
  apiKey: process.env.LEWRA_API_KEY,
  feature: '${activeModalFeature.title}',
  region: 'global-edge'
});

// Execute low-latency telemetry request
const response = await lewra.spatial.execute({
  mode: '${activeModalFeature.tag.toLowerCase()}',
  quantumSecure: true
});`}
                  </code>
                </pre>
              </div>

              <div className="flex items-center justify-between pt-2">
                <span className="text-xs font-mono text-emerald-400 flex items-center gap-1">
                  ✓ Verified Performance: {activeModalFeature.metrics}
                </span>
                <button
                  onClick={() => {
                    setActiveModalFeature(null);
                    onOpenGetStarted();
                  }}
                  className="px-5 py-2.5 rounded-xl bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold text-xs"
                >
                  Deploy Feature Node
                </button>
              </div>

            </div>
          </div>
        )}

      </div>
    </section>
  );
};
