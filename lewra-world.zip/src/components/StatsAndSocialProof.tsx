import React, { useState } from 'react';
import { TESTIMONIALS_DATA, PARTNERS } from '../data/mockData';
import { Star, Quote, CheckCircle2, TrendingUp, Users, ShieldAlert, Sparkles, Building2 } from 'lucide-react';

export const StatsAndSocialProof: React.FC = () => {
  const [activeTestimonialIdx, setActiveTestimonialIdx] = useState(0);

  return (
    <section className="py-24 relative bg-grid-pattern overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Animated Marquee Partner Logos */}
        <div className="mb-20 text-center">
          <p className="text-xs font-mono font-semibold text-slate-400 uppercase tracking-widest mb-8">
            POWERING SPATIAL ARCHITECTURE AT WORLD-CLASS ENTERPRISES
          </p>
          
          <div className="relative overflow-hidden w-full py-4 border-y border-slate-800/80 bg-slate-950/40">
            <div className="absolute top-0 bottom-0 left-0 w-24 bg-gradient-to-r from-[#070A12] to-transparent z-10 pointer-events-none" />
            <div className="absolute top-0 bottom-0 right-0 w-24 bg-gradient-to-l from-[#070A12] to-transparent z-10 pointer-events-none" />

            <div className="animate-marquee flex items-center gap-12 sm:gap-16">
              {[...PARTNERS, ...PARTNERS].map((partner, idx) => (
                <div key={idx} className="flex items-center gap-2 grayscale hover:grayscale-0 opacity-60 hover:opacity-100 transition-all cursor-pointer">
                  <div className="p-2 rounded-lg bg-slate-900 border border-slate-800">
                    <Building2 className="w-5 h-5 text-cyan-400" />
                  </div>
                  <span className="text-sm font-bold font-['Space_Grotesk'] text-slate-300 tracking-wider">
                    {partner.name}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Dynamic Big Counter Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-20">
          <div className="glass-card rounded-2xl p-6 text-center border border-slate-800 hover:border-cyan-500/40 transition-colors">
            <div className="text-3xl sm:text-5xl font-extrabold font-mono text-cyan-400 mb-2">
              10M+
            </div>
            <p className="text-sm font-bold text-white mb-1">Daily API Events</p>
            <p className="text-xs text-slate-400">Processed at sub-1ms speed</p>
          </div>

          <div className="glass-card rounded-2xl p-6 text-center border border-slate-800 hover:border-purple-500/40 transition-colors">
            <div className="text-3xl sm:text-5xl font-extrabold font-mono text-purple-400 mb-2">
              99.999%
            </div>
            <p className="text-sm font-bold text-white mb-1">High Availability</p>
            <p className="text-xs text-slate-400">Guaranteed enterprise SLA</p>
          </div>

          <div className="glass-card rounded-2xl p-6 text-center border border-slate-800 hover:border-emerald-500/40 transition-colors">
            <div className="text-3xl sm:text-5xl font-extrabold font-mono text-emerald-400 mb-2">
              300+
            </div>
            <p className="text-sm font-bold text-white mb-1">Edge Mesh PoPs</p>
            <p className="text-xs text-slate-400">Global low-latency edge</p>
          </div>

          <div className="glass-card rounded-2xl p-6 text-center border border-slate-800 hover:border-amber-500/40 transition-colors">
            <div className="text-3xl sm:text-5xl font-extrabold font-mono text-amber-400 mb-2">
              &lt;1.2ms
            </div>
            <p className="text-sm font-bold text-white mb-1">Mean Latency</p>
            <p className="text-xs text-slate-400">Post-quantum key handshake</p>
          </div>
        </div>

        {/* Testimonials Showcase */}
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-10">
            <h3 className="text-2xl sm:text-4xl font-extrabold text-white font-['Space_Grotesk'] mb-3">
              Trusted by <span className="text-gradient-cyan">Industry Pioneers</span>
            </h3>
            <p className="text-slate-400 text-sm sm:text-base">
              See how leading technology companies accelerate spatial innovation with Lewra World.
            </p>
          </div>

          {/* Testimonial Glass Card */}
          <div className="glass-card rounded-2xl p-8 border border-slate-700/80 shadow-2xl relative">
            <Quote className="w-10 h-10 text-cyan-500/20 absolute top-6 right-6" />

            <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6">
              <img
                src={TESTIMONIALS_DATA[activeTestimonialIdx].avatar}
                alt={TESTIMONIALS_DATA[activeTestimonialIdx].name}
                referrerPolicy="no-referrer"
                className="w-20 h-20 rounded-2xl object-cover border-2 border-cyan-400/40 shadow-xl"
              />

              <div className="flex-1 text-center sm:text-left">
                {/* Rating stars */}
                <div className="flex items-center justify-center sm:justify-start gap-1 mb-3">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                  ))}
                  <span className="text-xs font-mono text-emerald-400 ml-2 px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/20">
                    {TESTIMONIALS_DATA[activeTestimonialIdx].highlight}
                  </span>
                </div>

                <p className="text-lg sm:text-xl text-slate-100 italic leading-relaxed mb-6 font-normal">
                  &quot;{TESTIMONIALS_DATA[activeTestimonialIdx].quote}&quot;
                </p>

                <div>
                  <h4 className="text-base font-bold text-white font-['Space_Grotesk']">
                    {TESTIMONIALS_DATA[activeTestimonialIdx].name}
                  </h4>
                  <p className="text-xs font-mono text-slate-400">
                    {TESTIMONIALS_DATA[activeTestimonialIdx].role}, <span className="text-cyan-400">{TESTIMONIALS_DATA[activeTestimonialIdx].company}</span>
                  </p>
                </div>
              </div>
            </div>

            {/* Testimonial Switcher Dots */}
            <div className="flex justify-center items-center gap-2 mt-8 pt-6 border-t border-slate-800/80">
              {TESTIMONIALS_DATA.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveTestimonialIdx(idx)}
                  className={`w-3 h-3 rounded-full transition-all ${
                    activeTestimonialIdx === idx ? 'w-8 bg-cyan-400 shadow-md shadow-cyan-400/50' : 'bg-slate-700 hover:bg-slate-500'
                  }`}
                  aria-label={`View testimonial ${idx + 1}`}
                />
              ))}
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
