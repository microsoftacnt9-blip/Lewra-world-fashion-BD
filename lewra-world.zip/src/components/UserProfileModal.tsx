import React, { useState, useRef, useEffect } from 'react';
import { X, User, Mail, Lock, Key, LogOut, Package, ShoppingBag, Calendar, CheckCircle2, AlertCircle, Bot, ArrowRight, ShieldCheck, Eye, EyeOff, Receipt, Clock, Truck, Sparkles, Camera, Upload, Trash2, Edit3, Image as ImageIcon, Phone, Check, Link as LinkIcon, Gift, Copy, Star, PackageCheck, ThumbsUp } from 'lucide-react';
import { UserAccount, Order } from '../types';
import { DeliveryConfirmationModal } from './DeliveryConfirmationModal';

const PRESET_AVATARS = [
  { id: 'av-1', label: 'Pro Executive', url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80' },
  { id: 'av-2', label: 'Tech Pro', url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80' },
  { id: 'av-3', label: 'Urban Minimal', url: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&auto=format&fit=crop&q=80' },
  { id: 'av-4', label: 'Creative Style', url: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&auto=format&fit=crop&q=80' },
  { id: 'av-5', label: 'Modern Chic', url: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=200&auto=format&fit=crop&q=80' },
  { id: 'av-6', label: 'Casual Hero', url: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=200&auto=format&fit=crop&q=80' },
  { id: 'av-7', label: '3D Bottt', url: 'https://api.dicebear.com/7.x/bottts/svg?seed=Felix' },
  { id: 'av-8', label: '3D Persona', url: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Jack' },
];

interface UserProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserAccount | null;
  users: UserAccount[];
  orders: Order[];
  deletedUserEmails?: string[];
  onLogin: (user: UserAccount) => void;
  onLogout: () => void;
  onRegister: (newUser: UserAccount) => void;
  onUpdateUser?: (updatedUser: UserAccount) => void;
  onResetPassword: (email: string, newPass: string) => boolean;
  onViewReceipt: (order: Order) => void;
  onUpdateOrder?: (order: Order) => void;
  onOpenTracking?: (orderId: string) => void;
  onConfirmReceived?: (orderId: string, rating: number, review: string) => void;
}

export const UserProfileModal: React.FC<UserProfileModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  users,
  orders,
  deletedUserEmails = [],
  onLogin,
  onLogout,
  onRegister,
  onUpdateUser,
  onResetPassword,
  onViewReceipt,
  onUpdateOrder,
  onOpenTracking,
  onConfirmReceived
}) => {
  const [activeTab, setActiveTab] = useState<'login' | 'register' | 'forgot' | 'profile'>(
    currentUser ? 'profile' : 'login'
  );
  const [cancellingOrderId, setCancellingOrderId] = useState<string | null>(null);
  const [confirmingOrder, setConfirmingOrder] = useState<Order | null>(null);
  const [copiedReferral, setCopiedReferral] = useState(false);

  // Profile Edit State
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [editName, setEditName] = useState('');
  const [editPhone, setEditPhone] = useState('');
  const [editAvatar, setEditAvatar] = useState('');
  const [customAvatarUrl, setCustomAvatarUrl] = useState('');
  const [showAvatarPicker, setShowAvatarPicker] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const regFileInputRef = useRef<HTMLInputElement>(null);

  // Form states
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regAvatar, setRegAvatar] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirmPassword, setRegConfirmPassword] = useState('');
  const [regStep, setRegStep] = useState<1 | 2>(1);
  const [regGeneratedCode, setRegGeneratedCode] = useState('');
  const [regInputCode, setRegInputCode] = useState('');

  // Forgot password state
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotStep, setForgotStep] = useState<1 | 2>(1);
  const [generatedCode, setGeneratedCode] = useState('');
  const [inputCode, setInputCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [botMessage, setBotMessage] = useState<string | null>(null);

  // Error / Message feedback
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Sync edit states when currentUser changes
  useEffect(() => {
    if (currentUser) {
      setEditName(currentUser.name || '');
      setEditPhone(currentUser.phone || '');
      setEditAvatar(currentUser.avatar || '');
    }
  }, [currentUser]);

  if (!isOpen) return null;

  // Compress & convert file to Base64
  const processImageFile = (file: File, callback: (base64: string) => void) => {
    if (!file.type.startsWith('image/')) {
      setErrorMsg('Please select a valid image file (JPG, PNG, WebP).');
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new window.Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const MAX_SIZE = 360;
        let width = img.width;
        let height = img.height;
        if (width > height) {
          if (width > MAX_SIZE) {
            height = Math.round(height * (MAX_SIZE / width));
            width = MAX_SIZE;
          }
        } else {
          if (height > MAX_SIZE) {
            width = Math.round(width * (MAX_SIZE / height));
            height = MAX_SIZE;
          }
        }
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
          callback(dataUrl);
        } else {
          callback(e.target?.result as string);
        }
      };
      img.src = e.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, isReg: boolean = false) => {
    const file = e.target.files?.[0];
    if (!file) return;
    processImageFile(file, (base64) => {
      if (isReg) {
        setRegAvatar(base64);
      } else {
        setEditAvatar(base64);
        // If not in full edit mode, immediately save avatar
        if (currentUser && onUpdateUser && !isEditingProfile) {
          const updated = { ...currentUser, avatar: base64 };
          onUpdateUser(updated);
          setSuccessMsg('Profile picture updated successfully! (ছবি সফলভাবে পরিবর্তন হয়েছে)');
          setTimeout(() => setSuccessMsg(null), 3000);
        }
      }
    });
  };

  const handleSaveProfileDetails = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser || !onUpdateUser) return;
    if (!editName.trim()) {
      setErrorMsg('Name cannot be empty.');
      return;
    }

    const updated: UserAccount = {
      ...currentUser,
      name: editName.trim(),
      phone: editPhone.trim() || undefined,
      avatar: editAvatar.trim() || undefined
    };

    onUpdateUser(updated);
    setIsEditingProfile(false);
    setShowAvatarPicker(false);
    setSuccessMsg('Profile details & photo updated successfully! (প্রোফাইল সফলভাবে আপডেট হয়েছে)');
    setTimeout(() => setSuccessMsg(null), 3500);
  };

  // Sync activeTab when currentUser changes
  const currentTab = currentUser ? 'profile' : (activeTab === 'profile' ? 'login' : activeTab);

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    const cleanEmail = loginEmail.trim().toLowerCase();

    // Check if account was deleted by admin
    if (deletedUserEmails.some(e => e.toLowerCase() === cleanEmail)) {
      setErrorMsg('Your account has been deleted by the administrator.');
      return;
    }

    const user = users.find(u => u.email.toLowerCase() === cleanEmail);

    if (!user) {
      setErrorMsg('No account found with this email. Please register first.');
      return;
    }

    if (user.password !== loginPassword) {
      setErrorMsg('Incorrect password. Please try again or reset your password.');
      return;
    }

    onLogin(user);
    setSuccessMsg(`Welcome back, ${user.name}!`);
  };

  const handleGoogleSignIn = (customEmail?: string) => {
    setErrorMsg(null);
    setSuccessMsg(null);

    const emailToUse = (customEmail || loginEmail || 'microsoftacnt9@gmail.com').trim().toLowerCase();

    if (deletedUserEmails.some(e => e.toLowerCase() === emailToUse)) {
      setErrorMsg('Your account has been deleted by the administrator.');
      return;
    }

    let existingUser = users.find(u => u.email.toLowerCase() === emailToUse);
    if (!existingUser) {
      existingUser = {
        id: `usr_${Date.now()}`,
        name: emailToUse === 'microsoftacnt9@gmail.com' ? 'Microsoft Admin' : (emailToUse.split('@')[0] || 'Google User'),
        email: emailToUse,
        createdAt: new Date().toISOString(),
        isVerified: true,
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80'
      };
      if (onRegister) {
        onRegister(existingUser);
      }
    }
    onLogin(existingUser);
    setSuccessMsg(`Google অ্যাকাউন্ট দিয়ে সফলভাবে লগইন হয়েছে (${emailToUse})!`);
  };

  const handleRegSendCode = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    const cleanEmail = regEmail.trim().toLowerCase();

    if (deletedUserEmails.some(e => e.toLowerCase() === cleanEmail)) {
      setErrorMsg('Your account has been deleted by the administrator.');
      return;
    }

    if (!regName.trim() || !cleanEmail || !regPassword) {
      setErrorMsg('Please fill in all required fields.');
      return;
    }

    if (!cleanEmail.includes('@') || !cleanEmail.includes('.')) {
      setErrorMsg('Please enter a valid Gmail / Email address.');
      return;
    }

    if (regPassword.length < 6) {
      setErrorMsg('Password must be at least 6 characters long.');
      return;
    }

    if (regPassword !== regConfirmPassword) {
      setErrorMsg('Passwords do not match.');
      return;
    }

    // Check email uniqueness
    const exists = users.some(u => u.email.toLowerCase() === cleanEmail);
    if (exists) {
      setErrorMsg('An account with this email already exists! 2nd time registration with same Gmail is not allowed.');
      return;
    }

    // Generate 6-digit OTP code for registration
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    setRegGeneratedCode(code);
    setRegStep(2);
    setBotMessage(`A 6-digit verification code has been dispatched by Bot Dispatcher directly to your Gmail mailbox (${cleanEmail}). Please check your inbox or spam folder to retrieve your code.`);
  };

  const handleRegVerifyAndCreate = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (regInputCode.trim() !== regGeneratedCode) {
      setErrorMsg('Invalid verification code! Please enter the code generated by the Bot.');
      return;
    }

    const cleanEmail = regEmail.trim().toLowerCase();
    const newUser: UserAccount = {
      id: `user-${Date.now()}`,
      name: regName.trim(),
      email: cleanEmail,
      phone: regPhone.trim() || undefined,
      avatar: regAvatar.trim() || undefined,
      password: regPassword,
      createdAt: new Date().toISOString()
    };

    onRegister(newUser);
    onLogin(newUser);
    setSuccessMsg('Account created & verified successfully! You are now logged in.');
    setActiveTab('profile');
    setRegStep(1);
    setRegGeneratedCode('');
    setRegInputCode('');
    setBotMessage(null);
  };

  const handleSendResetCode = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setBotMessage(null);

    const cleanEmail = forgotEmail.trim().toLowerCase();

    if (deletedUserEmails.some(e => e.toLowerCase() === cleanEmail)) {
      setErrorMsg('Your account has been deleted by the administrator.');
      return;
    }

    const user = users.find(u => u.email.toLowerCase() === cleanEmail);

    if (!user) {
      setErrorMsg('No account exists with this Gmail / Email address.');
      return;
    }

    // Generate 6-digit OTP code
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    setGeneratedCode(code);
    setForgotStep(2);

    // Simulate Bot Dispatcher
    setBotMessage(`A 6-digit password reset verification code has been dispatched by Bot Dispatcher to your Gmail mailbox (${cleanEmail}). Please check your email inbox to copy the code.`);
  };

  const handleVerifyAndResetPassword = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (inputCode.trim() !== generatedCode) {
      setErrorMsg('Invalid verification code! Please check the code provided by the Bot.');
      return;
    }

    if (newPassword.length < 6) {
      setErrorMsg('New password must be at least 6 characters long.');
      return;
    }

    const success = onResetPassword(forgotEmail.trim().toLowerCase(), newPassword);
    if (success) {
      setSuccessMsg('Password updated successfully! You can now login with your new password.');
      setActiveTab('login');
      setLoginEmail(forgotEmail);
      setLoginPassword('');
      setForgotStep(1);
      setBotMessage(null);
      setInputCode('');
    } else {
      setErrorMsg('Failed to reset password. User not found.');
    }
  };

  // Filter orders for logged-in user
  const userOrders = currentUser
    ? orders.filter(o => o.customerEmail.toLowerCase() === currentUser.email.toLowerCase())
    : [];

  const totalSpent = userOrders.reduce((sum, o) => sum + o.totalAmount, 0);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
      <div className="border border-zinc-800 max-w-2xl w-full rounded-2xl p-5 sm:p-8 relative shadow-2xl bg-black max-h-[90vh] overflow-y-auto custom-scrollbar my-auto text-white">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-zinc-400 hover:text-white rounded-xl bg-zinc-900 hover:bg-zinc-800 transition-all z-10"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-6 pb-4 border-b border-zinc-800">
          <div className="w-10 h-10 rounded-xl bg-zinc-900 border border-white/20 flex items-center justify-center text-white">
            <User className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl font-bold font-['Space_Grotesk'] text-white">
              {currentUser ? `Welcome, ${currentUser.name}` : 'Customer Account & Profile'}
            </h2>
            <p className="text-xs text-zinc-400">
              {currentUser ? 'Manage your account details & order receipts' : 'Create an account or login to track your orders'}
            </p>
          </div>
        </div>

        {/* Success / Error Alerts */}
        {errorMsg && (
          <div className="mb-4 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{errorMsg}</span>
          </div>
        )}
        {successMsg && (
          <div className="mb-4 p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* TAB 1: LOGGED IN USER PROFILE & ORDERS */}
        {currentUser && activeTab === 'profile' && (
          <div className="space-y-6">
            {/* Hidden file input for quick direct upload */}
            <input
              type="file"
              ref={fileInputRef}
              accept="image/*"
              className="hidden"
              onChange={(e) => handleFileUpload(e, false)}
            />

            {/* Profile Overview Card */}
            <div className="p-4 sm:p-5 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-4 shadow-inner">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div className="flex items-center gap-3.5">
                  {/* Avatar with Camera Trigger */}
                  <div className="relative group shrink-0">
                    {currentUser.avatar ? (
                      <img
                        src={currentUser.avatar}
                        alt={currentUser.name}
                        referrerPolicy="no-referrer"
                        className="w-14 h-14 rounded-2xl object-cover border-2 border-zinc-700 shadow-lg bg-black"
                      />
                    ) : (
                      <div className="w-14 h-14 rounded-2xl bg-white text-black flex items-center justify-center font-extrabold font-mono text-xl shadow-lg">
                        {currentUser.name.slice(0, 2).toUpperCase()}
                      </div>
                    )}
                    <button
                      type="button"
                      onClick={() => {
                        setIsEditingProfile(true);
                        setShowAvatarPicker(true);
                      }}
                      className="absolute -bottom-1 -right-1 p-1.5 rounded-full bg-white hover:bg-zinc-200 text-black shadow-md transition-transform hover:scale-110 border border-black"
                      title="Change / Upload Profile Picture"
                    >
                      <Camera className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div>
                    <h3 className="text-base font-bold text-white flex items-center gap-2">
                      {currentUser.name}
                      <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-mono">
                        Verified Customer
                      </span>
                    </h3>
                    <p className="text-xs text-zinc-400 font-mono flex items-center gap-1 mt-0.5">
                      <Mail className="w-3 h-3 text-zinc-400" />
                      {currentUser.email}
                    </p>
                    {currentUser.phone && (
                      <p className="text-xs text-zinc-400 font-mono flex items-center gap-1 mt-0.5">
                        <Phone className="w-3 h-3 text-emerald-400" />
                        {currentUser.phone}
                      </p>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-2.5 w-full sm:w-auto justify-between sm:justify-end">
                  <div className="text-right font-mono text-xs hidden sm:block">
                    <p className="text-zinc-400">Total Orders: <strong className="text-white">{userOrders.length}</strong></p>
                    <p className="text-zinc-400">Total Spent: <strong className="text-emerald-400">৳{totalSpent} BDT</strong></p>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setIsEditingProfile(!isEditingProfile);
                        setShowAvatarPicker(false);
                      }}
                      className="px-3 py-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-white text-xs font-semibold flex items-center gap-1.5 transition-all shadow-sm"
                      title="Edit Profile & Picture"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      {isEditingProfile ? 'Close Editor' : 'Edit Profile'}
                    </button>
                    <button
                      onClick={onLogout}
                      className="px-3 py-2 rounded-xl bg-rose-950/50 hover:bg-rose-900/80 border border-rose-500/40 text-rose-300 text-xs font-semibold flex items-center gap-1.5 transition-all"
                      title="Logout from account"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      Logout
                    </button>
                  </div>
                </div>
              </div>

              {/* Mobile Stats Row */}
              <div className="grid grid-cols-2 gap-2 pt-2 border-t border-zinc-800 text-xs font-mono sm:hidden">
                <div className="p-2 rounded-lg bg-black border border-zinc-800">
                  <span className="text-zinc-400 text-[10px] block">Total Orders</span>
                  <strong className="text-white">{userOrders.length} Orders</strong>
                </div>
                <div className="p-2 rounded-lg bg-black border border-zinc-800">
                  <span className="text-zinc-400 text-[10px] block">Total Spent</span>
                  <strong className="text-emerald-400">৳{totalSpent} BDT</strong>
                </div>
              </div>

              {/* LOYALTY REWARDS & REFERRAL SYSTEM */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                {/* Reward Points Wallet */}
                <div className="p-3.5 rounded-xl bg-gradient-to-br from-amber-950/40 via-yellow-950/20 to-black border border-amber-500/40 space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-mono font-bold text-amber-300 flex items-center gap-1.5">
                      <Gift className="w-4 h-4 text-amber-400" />
                      <span>Loyalty Reward Points (রিওয়ার্ড পয়েন্ট)</span>
                    </span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300">
                      1 Point = 1 BDT
                    </span>
                  </div>
                  <div className="flex items-baseline gap-2">
                    <span className="text-2xl font-black font-mono text-amber-400">
                      {currentUser.rewardPoints !== undefined ? currentUser.rewardPoints : 150}
                    </span>
                    <span className="text-xs text-amber-200/80 font-mono">Points Available (৳{currentUser.rewardPoints !== undefined ? currentUser.rewardPoints : 150} সমমূল্য)</span>
                  </div>
                  <p className="text-[10px] text-zinc-400">
                    প্রতিটি কেনাকাটা এবং ভেরিফায়েড রিভিউতে স্বয়ংক্রিয় পয়েন্ট জমা হয় যা চেকআউটে ক্যাশ হিসেবে ব্যবহারযোগ্য।
                  </p>
                </div>

                {/* Referral Code Box */}
                <div className="p-3.5 rounded-xl bg-gradient-to-br from-cyan-950/40 via-blue-950/20 to-black border border-cyan-500/40 space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-mono font-bold text-cyan-300 flex items-center gap-1.5">
                      <Sparkles className="w-4 h-4 text-cyan-400" />
                      <span>Refer & Earn (রেফারেল প্রোগ্রাম)</span>
                    </span>
                    <span className="text-[10px] font-mono text-cyan-400">Win 100 Tk</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="flex-1 px-3 py-1.5 rounded-lg bg-black border border-cyan-500/40 font-mono font-bold text-xs text-cyan-300 tracking-wider text-center">
                      {currentUser.referralCode || `REF-${currentUser.id.slice(0, 6).toUpperCase()}`}
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        const code = currentUser.referralCode || `REF-${currentUser.id.slice(0, 6).toUpperCase()}`;
                        navigator.clipboard.writeText(`Shop on Lewra with my referral code ${code} and get extra bonus: ${window.location.origin}`);
                        setCopiedReferral(true);
                        setTimeout(() => setCopiedReferral(false), 2000);
                      }}
                      className="px-3 py-1.5 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/40 text-cyan-300 font-mono text-xs font-bold flex items-center gap-1 transition-all"
                    >
                      {copiedReferral ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedReferral ? 'Copied' : 'Share'}</span>
                    </button>
                  </div>
                  <p className="text-[10px] text-zinc-400">
                    বন্ধুদের সাথে রেফারেল শেয়ার করুন এবং তারা প্রথম অর্ডার দিলে উভয়েই পাবেন ১০০ রিওয়ার্ড পয়েন্ট!
                  </p>
                </div>
              </div>

              {/* INLINE PROFILE & PHOTO EDITOR */}
              {isEditingProfile && (
                <form onSubmit={handleSaveProfileDetails} className="mt-4 pt-4 border-t border-zinc-800 space-y-4 animate-in fade-in">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold text-white font-mono flex items-center gap-1.5">
                      <Camera className="w-3.5 h-3.5 text-white" />
                      Customer Profile Picture & Information (কাস্টমার ছবি ও তথ্য)
                    </h4>
                    <span className="text-[10px] text-zinc-400 font-mono">Instant Update</span>
                  </div>

                  {/* Profile Picture Management Box */}
                  <div className="p-3.5 rounded-xl bg-black border border-zinc-800 space-y-3">
                    <div className="flex flex-col sm:flex-row items-center gap-4">
                      {/* Avatar Preview */}
                      <div className="relative group shrink-0">
                        {editAvatar ? (
                          <img
                            src={editAvatar}
                            alt="Profile Preview"
                            referrerPolicy="no-referrer"
                            className="w-16 h-16 rounded-2xl object-cover border-2 border-zinc-700 shadow-md bg-zinc-900"
                          />
                        ) : (
                          <div className="w-16 h-16 rounded-2xl bg-white text-black flex items-center justify-center font-extrabold font-mono text-2xl shadow-md">
                            {(editName || currentUser.name).slice(0, 2).toUpperCase()}
                          </div>
                        )}
                      </div>

                      {/* Action Buttons */}
                      <div className="flex-1 w-full space-y-2">
                        <div className="flex flex-wrap gap-2">
                          <button
                            type="button"
                            onClick={() => fileInputRef.current?.click()}
                            className="px-3 py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-white text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm"
                          >
                            <Upload className="w-3.5 h-3.5" />
                            Upload from Device
                          </button>
                          
                          <button
                            type="button"
                            onClick={() => setShowAvatarPicker(!showAvatarPicker)}
                            className="px-3 py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-zinc-300 text-xs font-bold flex items-center gap-1.5 transition-all"
                          >
                            <Sparkles className="w-3.5 h-3.5" />
                            {showAvatarPicker ? 'Hide Presets' : 'Preset Avatars'}
                          </button>

                          {editAvatar && (
                            <button
                              type="button"
                              onClick={() => {
                                setEditAvatar('');
                                setCustomAvatarUrl('');
                              }}
                              className="px-2.5 py-1.5 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 text-rose-300 text-xs flex items-center gap-1 transition-all"
                              title="Remove custom profile picture"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                              Remove Photo
                            </button>
                          )}
                        </div>

                        <p className="text-[10px] text-zinc-400">
                          * PNG, JPG বা WebP ছবি আপলোড করুন অথবা নিচের প্রিসেট অবতার থেকে যেকোনো একটি বেছে নিন।
                        </p>
                      </div>
                    </div>

                    {/* Preset Avatars Grid */}
                    {showAvatarPicker && (
                      <div className="pt-2 border-t border-zinc-800 space-y-2 animate-in fade-in">
                        <span className="text-[11px] font-bold text-zinc-300 font-mono block">
                          Select from Curated Avatars (তাত্ক্ষণিক অবতার সিলেক্ট করুন):
                        </span>
                        <div className="grid grid-cols-4 sm:grid-cols-8 gap-2">
                          {PRESET_AVATARS.map((av) => {
                            const isSelected = editAvatar === av.url;
                            return (
                              <button
                                key={av.id}
                                type="button"
                                onClick={() => {
                                  setEditAvatar(av.url);
                                  setCustomAvatarUrl('');
                                }}
                                className={`relative rounded-xl overflow-hidden aspect-square border-2 transition-all p-0.5 group ${
                                  isSelected
                                    ? 'border-white ring-2 ring-white/40 scale-105'
                                    : 'border-zinc-800 hover:border-zinc-500'
                                }`}
                                title={av.label}
                              >
                                <img
                                  src={av.url}
                                  alt={av.label}
                                  referrerPolicy="no-referrer"
                                  className="w-full h-full object-cover rounded-lg"
                                />
                                {isSelected && (
                                  <div className="absolute inset-0 bg-white/20 backdrop-blur-[1px] flex items-center justify-center">
                                    <Check className="w-4 h-4 text-white font-bold" />
                                  </div>
                                )}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {/* Direct Image URL input */}
                    <div className="pt-2 border-t border-zinc-800">
                      <div className="flex gap-2">
                        <div className="relative flex-1">
                          <LinkIcon className="w-3.5 h-3.5 text-zinc-500 absolute left-2.5 top-1/2 -translate-y-1/2" />
                          <input
                            type="url"
                            value={customAvatarUrl}
                            onChange={(e) => setCustomAvatarUrl(e.target.value)}
                            placeholder="Or paste direct image URL (https://...)"
                            className="w-full bg-zinc-950 border border-zinc-800 focus:border-white rounded-lg pl-8 pr-3 py-1.5 text-xs text-white placeholder-zinc-500 font-mono focus:outline-none"
                          />
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            if (customAvatarUrl.trim()) {
                              setEditAvatar(customAvatarUrl.trim());
                            }
                          }}
                          disabled={!customAvatarUrl.trim()}
                          className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 disabled:opacity-50 text-white text-xs font-mono font-bold"
                        >
                          Apply URL
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Name & Phone inputs */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-[11px] font-mono text-zinc-300 block mb-1">Full Name (নাম) *</label>
                      <div className="relative">
                        <User className="w-3.5 h-3.5 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2" />
                        <input
                          type="text"
                          required
                          value={editName}
                          onChange={(e) => setEditName(e.target.value)}
                          placeholder="Your Name"
                          className="w-full bg-zinc-950 border border-zinc-800 focus:border-white rounded-xl pl-8 pr-3 py-2 text-xs text-white font-mono focus:outline-none"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="text-[11px] font-mono text-zinc-300 block mb-1">Mobile Phone (মোবাইল নম্বর)</label>
                      <div className="relative">
                        <Phone className="w-3.5 h-3.5 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2" />
                        <input
                          type="tel"
                          value={editPhone}
                          onChange={(e) => setEditPhone(e.target.value)}
                          placeholder="017XXXXXXXX"
                          className="w-full bg-zinc-950 border border-zinc-800 focus:border-white rounded-xl pl-8 pr-3 py-2 text-xs text-white font-mono focus:outline-none"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Form Action Buttons */}
                  <div className="flex items-center justify-end gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => {
                        setIsEditingProfile(false);
                        setShowAvatarPicker(false);
                        if (currentUser) {
                          setEditName(currentUser.name);
                          setEditPhone(currentUser.phone || '');
                          setEditAvatar(currentUser.avatar || '');
                        }
                      }}
                      className="px-4 py-2 rounded-xl border border-zinc-800 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 text-xs font-mono"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-5 py-2 rounded-xl bg-white hover:bg-zinc-200 text-black font-bold font-mono text-xs transition-all shadow-md flex items-center gap-1.5"
                    >
                      <Check className="w-3.5 h-3.5" />
                      Save Changes
                    </button>
                  </div>
                </form>
              )}
            </div>

            {/* User Orders Section */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-bold text-white flex items-center gap-2 font-['Space_Grotesk']">
                  <Package className="w-4 h-4 text-white" />
                  My Purchase & Order History ({userOrders.length})
                </h3>
              </div>

              {userOrders.length === 0 ? (
                <div className="text-center py-12 px-4 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-3">
                  <ShoppingBag className="w-10 h-10 text-zinc-600 mx-auto" />
                  <p className="text-xs text-zinc-400">You haven't placed any orders yet with this Gmail address.</p>
                  <p className="text-xs text-white font-mono">Browse products and place your order!</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {userOrders.map((ord) => {
                    const adv = ord.advancePaid !== undefined ? ord.advancePaid : (ord.paymentMethod === 'Cash on Delivery' ? 0 : ord.totalAmount);
                    const due = ord.dueAmount !== undefined ? ord.dueAmount : Math.max(0, ord.totalAmount - adv);

                    return (
                      <div key={ord.id} className="p-4 rounded-xl bg-zinc-950 border border-zinc-800 hover:border-zinc-700 transition-all space-y-3">
                        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-zinc-800 pb-2.5 text-xs font-mono">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-white">{ord.id}</span>
                            <span className="text-zinc-600">•</span>
                            <span className="text-zinc-400">{new Date(ord.createdAt).toLocaleDateString()}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                              ord.status === 'Completed' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' :
                              ord.status === 'Shipped' ? 'bg-blue-500/20 text-blue-300 border border-blue-500/40' :
                              ord.status === 'Processing' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' :
                              ord.status === 'Cancelled' ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40' :
                              'bg-zinc-800 text-white border border-zinc-700'
                            }`}>
                              {ord.status} {ord.status === 'Cancelled' && (ord.cancelledBy === 'Customer' ? '(By You)' : '(By Seller)')}
                            </span>
                          </div>
                        </div>

                        {/* Order Items */}
                        <div className="space-y-1.5 text-xs">
                          {ord.items.map((item, i) => (
                            <div key={i} className="flex justify-between text-zinc-300 font-mono">
                              <span>{item.quantity}x {item.productName}</span>
                              <span className="text-zinc-400">৳{item.price * item.quantity}</span>
                            </div>
                          ))}
                        </div>

                        {/* Financial breakdown */}
                        <div className="pt-2 border-t border-zinc-800 grid grid-cols-3 gap-2 text-[11px] font-mono">
                          <div className="p-2 rounded bg-black border border-zinc-800">
                            <span className="text-zinc-400 block text-[10px]">Total Amount</span>
                            <span className="font-extrabold text-white">৳{ord.totalAmount}</span>
                          </div>
                          <div className="p-2 rounded bg-emerald-950/40 border border-emerald-500/30">
                            <span className="text-emerald-300/80 block text-[10px]">Advance Paid</span>
                            <span className="font-extrabold text-emerald-400">৳{adv}</span>
                          </div>
                          <div className="p-2 rounded bg-amber-950/40 border border-amber-500/30">
                            <span className="text-amber-300/80 block text-[10px]">Due Amount</span>
                            <span className="font-extrabold text-amber-400">৳{due}</span>
                          </div>
                        </div>

                        {/* Customer Received Banner */}
                        {ord.customerReceived ? (
                          <div className="p-2.5 rounded-lg bg-emerald-950/40 border border-emerald-500/40 flex items-center justify-between text-xs font-mono text-emerald-300">
                            <span className="flex items-center gap-1.5 font-bold">
                              <PackageCheck className="w-4 h-4 text-emerald-400" />
                              <span>পণ্য ডেলিভারি বুঝে পেয়েছি (Verified Delivery)</span>
                            </span>
                            {ord.customerRating && (
                              <span className="text-amber-400 flex items-center gap-0.5">
                                {[...Array(ord.customerRating)].map((_, idx) => (
                                  <Star key={idx} className="w-3 h-3 fill-amber-400" />
                                ))}
                              </span>
                            )}
                          </div>
                        ) : null}

                        <div className="pt-2 flex items-center justify-between gap-2 flex-wrap">
                          {ord.status !== 'Cancelled' && ord.status !== 'Completed' && (
                            <button
                              type="button"
                              onClick={() => setCancellingOrderId(ord.id)}
                              className="px-3 py-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 text-rose-300 text-xs font-mono font-bold flex items-center gap-1.5 transition-all"
                            >
                              <X className="w-3.5 h-3.5 text-rose-400" />
                              Cancel Order
                            </button>
                          )}

                          {!ord.customerReceived && ord.status !== 'Cancelled' && (
                            <button
                              type="button"
                              onClick={() => setConfirmingOrder(ord)}
                              className="px-3 py-1.5 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-300 text-xs font-mono font-bold flex items-center gap-1.5 transition-all"
                            >
                              <ThumbsUp className="w-3.5 h-3.5 text-emerald-400" />
                              পণ্য পেয়েছি (Mark Received)
                            </button>
                          )}

                          <div className="flex items-center gap-2 ml-auto">
                            {onOpenTracking && (
                              <button
                                type="button"
                                onClick={() => {
                                  onClose();
                                  onOpenTracking(ord.id);
                                }}
                                className="px-3 py-1.5 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/40 text-cyan-300 text-xs font-mono font-bold flex items-center gap-1.5 transition-all"
                              >
                                <Truck className="w-3.5 h-3.5 text-cyan-400" />
                                Track Order
                              </button>
                            )}
                            <button
                              type="button"
                              onClick={() => onViewReceipt(ord)}
                              className="px-3 py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-white text-xs font-mono font-bold flex items-center gap-1.5 transition-all"
                            >
                              <Receipt className="w-3.5 h-3.5" />
                              Receipt
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB NAVIGATION FOR LOGGED-OUT USERS */}
        {!currentUser && (
          <div>
            <div className="flex border-b border-zinc-800 mb-6">
              <button
                onClick={() => { setActiveTab('login'); setErrorMsg(null); setSuccessMsg(null); }}
                className={`flex-1 py-2.5 text-xs font-bold font-mono border-b-2 transition-all ${
                  activeTab === 'login'
                    ? 'border-white text-white bg-zinc-900'
                    : 'border-transparent text-zinc-400 hover:text-white'
                }`}
              >
                Sign In / Login
              </button>
              <button
                onClick={() => { setActiveTab('register'); setErrorMsg(null); setSuccessMsg(null); }}
                className={`flex-1 py-2.5 text-xs font-bold font-mono border-b-2 transition-all ${
                  activeTab === 'register'
                    ? 'border-white text-white bg-zinc-900'
                    : 'border-transparent text-zinc-400 hover:text-white'
                }`}
              >
                Create Account (Register)
              </button>
            </div>

            {/* LOGIN FORM */}
            {activeTab === 'login' && (
              <div className="space-y-4">
                {/* 1-Tap Google Sign In */}
                <button
                  type="button"
                  onClick={() => handleGoogleSignIn()}
                  className="w-full py-2.5 px-4 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-white font-mono text-xs font-bold flex items-center justify-center gap-3 transition-all hover:border-zinc-500 shadow-sm"
                >
                  <svg className="w-4 h-4" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.66-5.17 3.66-9.17z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 9.98 0 12s.45 3.82 1.25 5.42l4.03-3.15z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
                    />
                  </svg>
                  <span>Continue with Google (গুগল দিয়ে লগইন)</span>
                </button>

                <div className="flex items-center gap-3 my-2">
                  <div className="flex-1 h-px bg-zinc-800" />
                  <span className="text-[10px] font-mono text-zinc-500 uppercase">অথবা ইমেইল দিয়ে</span>
                  <div className="flex-1 h-px bg-zinc-800" />
                </div>

                <form onSubmit={handleLoginSubmit} className="space-y-4">
                  <div>
                    <label className="text-xs font-mono text-zinc-300 block mb-1">Gmail / Email Address *</label>
                    <div className="relative">
                      <Mail className="w-4 h-4 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        type="email"
                        required
                        value={loginEmail}
                        onChange={(e) => setLoginEmail(e.target.value)}
                        placeholder="example@gmail.com"
                        className="w-full bg-zinc-950 border border-zinc-800 focus:border-white rounded-xl pl-9 pr-3 py-2.5 text-xs text-white placeholder-zinc-500 font-mono focus:outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <label className="text-xs font-mono text-zinc-300 block">Password *</label>
                      <button
                        type="button"
                        onClick={() => { setActiveTab('forgot'); setForgotEmail(loginEmail); setErrorMsg(null); setSuccessMsg(null); }}
                        className="text-[11px] text-zinc-400 hover:text-white hover:underline font-mono"
                      >
                        Forgot Password?
                      </button>
                    </div>
                    <div className="relative">
                      <Lock className="w-4 h-4 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        type={showPassword ? 'text' : 'password'}
                        required
                        value={loginPassword}
                        onChange={(e) => setLoginPassword(e.target.value)}
                        placeholder="••••••••"
                        className="w-full bg-zinc-950 border border-zinc-800 focus:border-white rounded-xl pl-9 pr-10 py-2.5 text-xs text-white placeholder-zinc-500 font-mono focus:outline-none"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-zinc-300"
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 rounded-xl bg-white hover:bg-zinc-200 text-black font-bold font-mono text-xs transition-all shadow-lg"
                  >
                    Log In to Profile
                  </button>
                </form>
              </div>
            )}

            {/* REGISTER FORM */}
            {activeTab === 'register' && (
              <div className="space-y-4">
                <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2">
                  <Bot className="w-5 h-5 text-emerald-400 shrink-0" />
                  <span>
                    Profile Creation Bot: Verification code will be dispatched to your provided Gmail address by our automated Bot dispatcher.
                  </span>
                </div>

                {regStep === 1 ? (
                  <form onSubmit={handleRegSendCode} className="space-y-4">
                    {/* Hidden input for registration file upload */}
                    <input
                      type="file"
                      ref={regFileInputRef}
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => handleFileUpload(e, true)}
                    />

                    {/* Profile Picture Chooser for Registration */}
                    <div className="p-3 rounded-xl bg-zinc-950 border border-zinc-800 flex items-center gap-3.5">
                      <div className="relative group shrink-0">
                        {regAvatar ? (
                          <img
                            src={regAvatar}
                            alt="Avatar Preview"
                            referrerPolicy="no-referrer"
                            className="w-12 h-12 rounded-2xl object-cover border-2 border-zinc-700 shadow-md bg-black"
                          />
                        ) : (
                          <div className="w-12 h-12 rounded-2xl bg-zinc-900 border border-zinc-700 flex items-center justify-center text-white font-bold font-mono text-base">
                            {regName ? regName.slice(0, 2).toUpperCase() : <User className="w-5 h-5" />}
                          </div>
                        )}
                      </div>
                      <div className="flex-1 space-y-1">
                        <span className="text-xs font-mono text-zinc-300 block font-bold">Profile Picture (ঐচ্ছিক ছবি)</span>
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => regFileInputRef.current?.click()}
                            className="px-2.5 py-1 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-white text-[11px] font-mono flex items-center gap-1 transition-all"
                          >
                            <Upload className="w-3 h-3" />
                            Upload Photo
                          </button>
                          {regAvatar && (
                            <button
                              type="button"
                              onClick={() => setRegAvatar('')}
                              className="px-2 py-1 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 text-rose-300 text-[11px] font-mono transition-all"
                            >
                              Remove
                            </button>
                          )}
                        </div>
                      </div>
                    </div>

                    <div>
                      <label className="text-xs font-mono text-zinc-300 block mb-1">Full Name *</label>
                      <div className="relative">
                        <User className="w-4 h-4 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2" />
                        <input
                          type="text"
                          required
                          value={regName}
                          onChange={(e) => setRegName(e.target.value)}
                          placeholder="e.g. Tanvir Hossain"
                          className="w-full bg-zinc-950 border border-zinc-800 focus:border-white rounded-xl pl-9 pr-3 py-2.5 text-xs text-white placeholder-zinc-500 font-mono focus:outline-none"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="text-xs font-mono text-zinc-300 block mb-1">Mobile Phone (মোবাইল নম্বর)</label>
                      <div className="relative">
                        <Phone className="w-4 h-4 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2" />
                        <input
                          type="tel"
                          value={regPhone}
                          onChange={(e) => setRegPhone(e.target.value)}
                          placeholder="017XXXXXXXX"
                          className="w-full bg-zinc-950 border border-zinc-800 focus:border-white rounded-xl pl-9 pr-3 py-2.5 text-xs text-white placeholder-zinc-500 font-mono focus:outline-none"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="text-xs font-mono text-zinc-300 block mb-1">Gmail / Email Address *</label>
                      <div className="relative">
                        <Mail className="w-4 h-4 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2" />
                        <input
                          type="email"
                          required
                          value={regEmail}
                          onChange={(e) => setRegEmail(e.target.value)}
                          placeholder="yourname@gmail.com"
                          className="w-full bg-zinc-950 border border-zinc-800 focus:border-white rounded-xl pl-9 pr-3 py-2.5 text-xs text-white placeholder-zinc-500 font-mono focus:outline-none"
                        />
                      </div>
                      <p className="text-[10px] text-zinc-400 mt-1">
                        * Note: Duplicate registration with the same Gmail address is strictly prohibited.
                      </p>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="text-xs font-mono text-zinc-300 block mb-1">Password *</label>
                        <div className="relative">
                          <Lock className="w-4 h-4 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2" />
                          <input
                            type="password"
                            required
                            value={regPassword}
                            onChange={(e) => setRegPassword(e.target.value)}
                            placeholder="••••••••"
                            className="w-full bg-zinc-950 border border-zinc-800 focus:border-white rounded-xl pl-9 pr-3 py-2.5 text-xs text-white placeholder-zinc-500 font-mono focus:outline-none"
                          />
                        </div>
                      </div>
                      <div>
                        <label className="text-xs font-mono text-zinc-300 block mb-1">Confirm Password *</label>
                        <div className="relative">
                          <Lock className="w-4 h-4 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2" />
                          <input
                            type="password"
                            required
                            value={regConfirmPassword}
                            onChange={(e) => setRegConfirmPassword(e.target.value)}
                            placeholder="••••••••"
                            className="w-full bg-zinc-950 border border-zinc-800 focus:border-white rounded-xl pl-9 pr-3 py-2.5 text-xs text-white placeholder-zinc-500 font-mono focus:outline-none"
                          />
                        </div>
                      </div>
                    </div>

                    <button
                      type="submit"
                      className="w-full py-3 rounded-xl bg-white hover:bg-zinc-200 text-black font-bold font-mono text-xs transition-all shadow-lg flex items-center justify-center gap-2"
                    >
                      <Bot className="w-4 h-4 text-black" />
                      Send Verification Code via Bot Dispatcher
                    </button>
                  </form>
                ) : (
                  <form onSubmit={handleRegVerifyAndCreate} className="space-y-4">
                    <div>
                      <label className="text-xs font-mono text-emerald-300 block mb-1">
                        Enter 6-Digit Verification Code *
                      </label>
                      <div className="relative">
                        <Key className="w-4 h-4 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2" />
                        <input
                          type="text"
                          required
                          maxLength={6}
                          value={regInputCode}
                          onChange={(e) => setRegInputCode(e.target.value)}
                          placeholder="e.g. 123456"
                          className="w-full bg-zinc-950 border border-emerald-500 focus:border-emerald-400 rounded-xl pl-9 pr-3 py-3 text-sm text-center font-bold tracking-widest text-emerald-300 font-mono focus:outline-none"
                        />
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          setRegStep(1);
                          setBotMessage(null);
                        }}
                        className="w-1/3 py-3 rounded-xl border border-zinc-800 bg-zinc-900 text-zinc-300 font-mono text-xs hover:bg-zinc-800 transition-all"
                      >
                        Change Details
                      </button>
                      <button
                        type="submit"
                        className="w-2/3 py-3 rounded-xl bg-white hover:bg-zinc-200 text-black font-bold font-mono text-xs transition-all shadow-lg"
                      >
                        Verify & Complete Registration
                      </button>
                    </div>
                  </form>
                )}
              </div>
            )}

            {/* FORGOT PASSWORD FORM */}
            {activeTab === 'forgot' && (
              <div className="space-y-4">
                <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs flex items-center gap-2">
                  <Bot className="w-5 h-5 text-amber-400 shrink-0" />
                  <span>
                    Forgot password system: Enter your registered Gmail address. Our Automated Bot will dispatch a 6-digit verification code.
                  </span>
                </div>

                {forgotStep === 1 ? (
                  <form onSubmit={handleSendResetCode} className="space-y-4">
                    <div>
                      <label className="text-xs font-mono text-zinc-300 block mb-1">Enter Registered Gmail Address *</label>
                      <div className="relative">
                        <Mail className="w-4 h-4 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2" />
                        <input
                          type="email"
                          required
                          value={forgotEmail}
                          onChange={(e) => setForgotEmail(e.target.value)}
                          placeholder="yourname@gmail.com"
                          className="w-full bg-zinc-950 border border-zinc-800 focus:border-white rounded-xl pl-9 pr-3 py-2.5 text-xs text-white placeholder-zinc-500 font-mono focus:outline-none"
                        />
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => setActiveTab('login')}
                        className="px-4 py-2.5 rounded-xl bg-zinc-900 text-zinc-300 text-xs font-mono font-bold"
                      >
                        Back to Login
                      </button>
                      <button
                        type="submit"
                        className="flex-1 py-2.5 rounded-xl bg-white hover:bg-zinc-200 text-black font-bold font-mono text-xs transition-all flex items-center justify-center gap-2"
                      >
                        <Bot className="w-4 h-4 text-black" />
                        Send Verification Code via Bot
                      </button>
                    </div>
                  </form>
                ) : (
                  <form onSubmit={handleVerifyAndResetPassword} className="space-y-4">
                    <div>
                      <label className="text-xs font-mono text-zinc-300 block mb-1">Enter 6-Digit OTP Code *</label>
                      <div className="relative">
                        <Key className="w-4 h-4 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2" />
                        <input
                          type="text"
                          required
                          maxLength={6}
                          value={inputCode}
                          onChange={(e) => setInputCode(e.target.value)}
                          placeholder="e.g. 849201"
                          className="w-full bg-zinc-950 border border-zinc-800 focus:border-white rounded-xl pl-9 pr-3 py-2.5 text-sm text-white font-bold font-mono tracking-widest focus:outline-none"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="text-xs font-mono text-zinc-300 block mb-1">Enter New Password *</label>
                      <div className="relative">
                        <Lock className="w-4 h-4 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2" />
                        <input
                          type="password"
                          required
                          value={newPassword}
                          onChange={(e) => setNewPassword(e.target.value)}
                          placeholder="New password (min 6 characters)"
                          className="w-full bg-zinc-950 border border-zinc-800 focus:border-white rounded-xl pl-9 pr-3 py-2.5 text-xs text-white placeholder-zinc-500 font-mono focus:outline-none"
                        />
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => setForgotStep(1)}
                        className="px-4 py-2.5 rounded-xl bg-zinc-900 text-zinc-300 text-xs font-mono font-bold"
                      >
                        Resend Code
                      </button>
                      <button
                        type="submit"
                        className="flex-1 py-2.5 rounded-xl bg-white hover:bg-zinc-200 text-black font-bold font-mono text-xs transition-all flex items-center justify-center gap-2"
                      >
                        <ShieldCheck className="w-4 h-4 text-black" />
                        Reset Password
                      </button>
                    </div>
                  </form>
                )}
              </div>
            )}
          </div>
        )}

      </div>

      {/* Delivery Confirmation Modal */}
      {confirmingOrder && (
        <DeliveryConfirmationModal
          isOpen={!!confirmingOrder}
          onClose={() => setConfirmingOrder(null)}
          order={confirmingOrder}
          onConfirm={(orderId, rating, review) => {
            if (onConfirmReceived) {
              onConfirmReceived(orderId, rating, review);
            }
            if (onUpdateOrder) {
              const updatedOrd = {
                ...confirmingOrder,
                customerReceived: true,
                customerReceivedAt: new Date().toISOString(),
                customerRating: rating,
                customerReview: review,
                status: 'Completed' as const
              };
              onUpdateOrder(updatedOrd);
            }
            setConfirmingOrder(null);
          }}
        />
      )}
    </div>
  );
};
