import React, { useState } from 'react';
import { AboutInfo } from '../types';
import { Sparkles, Send, CheckCircle2, Phone, Mail, MapPin, Globe } from 'lucide-react';

interface FooterProps {
  aboutInfo?: AboutInfo;
  onOpenAdmin?: () => void;
}

export const Footer: React.FC<FooterProps> = ({ aboutInfo, onOpenAdmin }) => {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !email.includes('@')) return;
    setSubscribed(true);
  };

  const companyName = aboutInfo?.companyName || 'Lewra World';
  const tagline = aboutInfo?.tagline || 'Leading Hardware & Technology Solutions';

  return (
    <footer className="bg-[#0E0A07] border-t border-[#3D2B22] pt-16 pb-12 relative overflow-hidden text-[#FFF8F2]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 mb-16">
          
          {/* Brand Col (2 Cols) */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              {aboutInfo?.logoUrl ? (
                <img
                  src={aboutInfo.logoUrl}
                  alt={companyName}
                  referrerPolicy="no-referrer"
                  className="w-9 h-9 rounded-xl object-cover bg-[#1C1410] border border-[#523A2E] p-0.5"
                />
              ) : (
                <div className="w-9 h-9 rounded-xl bg-[#1C1410] border border-[#523A2E] flex items-center justify-center">
                  <Sparkles className="w-4 h-4 text-[#D4A373]" />
                </div>
              )}
              <span className="text-xl font-bold tracking-wider font-['Space_Grotesk'] text-[#FFF8F2] uppercase">
                {companyName}
              </span>
              {aboutInfo?.brandOriginCountry && (
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-[#1C1410] border border-[#3D2B22] text-[10px] font-mono text-[#DDB892] font-bold">
                  <span>{aboutInfo.brandOriginFlag || '🇧🇩'}</span>
                  <span>{aboutInfo.brandOriginCountry}</span>
                </span>
              )}
            </div>

            <p className="text-xs text-[#CBB5A1] leading-relaxed max-w-sm">
              {tagline}. High quality products, fast delivery, and premium support across Bangladesh.
            </p>

            {/* Newsletter Form */}
            <div className="pt-2">
              <span className="text-xs font-mono font-semibold text-[#E6CCB2] block mb-2">
                Subscribe for Exclusive Offers & Updates
              </span>
              {subscribed ? (
                <div className="p-3 rounded-xl bg-emerald-950/60 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>Subscribed! Thank you for staying connected.</span>
                </div>
              ) : (
                <form onSubmit={handleNewsletterSubmit} className="flex gap-2">
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Enter your email address"
                    required
                    className="bg-[#140E0A] border border-[#3D2B22] rounded-xl px-3.5 py-2 text-xs text-[#FFF8F2] placeholder-[#8A6F5D] focus:outline-none focus:border-[#D4A373] flex-1"
                  />
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#D4A373] via-[#E6CCB2] to-[#DDB892] hover:from-[#E6CCB2] hover:to-[#D4A373] text-[#140E0A] font-bold text-xs flex items-center gap-1.5 transition-all shadow-md shadow-[#140E0A]/50"
                  >
                    <span>Join</span>
                    <Send className="w-3 h-3" />
                  </button>
                </form>
              )}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-xs font-mono font-bold text-[#E6CCB2] uppercase tracking-wider mb-4">Quick Links</h4>
            <ul className="space-y-2.5 text-xs text-[#CBB5A1]">
              <li><a href="#store" className="hover:text-[#FFF8F2] transition-colors">Products Store</a></li>
              <li><a href="#features" className="hover:text-[#FFF8F2] transition-colors">Key Features</a></li>
              <li><a href="#pricing" className="hover:text-[#FFF8F2] transition-colors">Packages & Pricing</a></li>
            </ul>
          </div>

          {/* Contact Details */}
          <div>
            <h4 className="text-xs font-mono font-bold text-[#E6CCB2] uppercase tracking-wider mb-4">Contact Info</h4>
            <ul className="space-y-2.5 text-xs text-[#CBB5A1]">
              {aboutInfo?.phone && (
                <li className="flex items-center gap-2">
                  <Phone className="w-3.5 h-3.5 text-[#D4A373] shrink-0" />
                  <span>{aboutInfo.phone}</span>
                </li>
              )}
              {aboutInfo?.email && (
                <li className="flex items-center gap-2">
                  <Mail className="w-3.5 h-3.5 text-[#D4A373] shrink-0" />
                  <span>{aboutInfo.email}</span>
                </li>
              )}
              {aboutInfo?.address && (
                <li className="flex items-start gap-2">
                  <MapPin className="w-3.5 h-3.5 text-[#D4A373] shrink-0 mt-0.5" />
                  <span>{aboutInfo.address}</span>
                </li>
              )}
            </ul>
          </div>

          {/* Platform & Developers Company */}
          <div>
            <h4 className="text-xs font-mono font-bold text-[#E6CCB2] uppercase tracking-wider mb-4">Platform & Developers</h4>
            <ul className="space-y-2.5 text-xs text-[#CBB5A1]">
              {aboutInfo?.platformCompany && (
                <li className="flex items-center gap-1.5">
                  <Globe className="w-3.5 h-3.5 text-[#D4A373] shrink-0" />
                  <span className="text-[#FFF8F2] font-semibold">{aboutInfo.platformCompany}</span>
                </li>
              )}
              {aboutInfo?.developerName && (
                <li className="text-[#CBB5A1] space-y-0.5">
                  <div>
                    Developed by:{' '}
                    {aboutInfo.developerWebsite ? (
                      <a
                        href={aboutInfo.developerWebsite}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-[#D4A373] hover:underline font-mono font-bold"
                      >
                        {aboutInfo.developerName}
                      </a>
                    ) : (
                      <span className="text-[#D4A373] font-mono font-bold">{aboutInfo.developerName}</span>
                    )}
                  </div>
                  {aboutInfo.developerPhone && (
                    <div className="text-[11px] text-[#A88B77] flex items-center gap-1 font-mono">
                      <Phone className="w-3 h-3 text-[#D4A373]" />
                      <span>Phone: <a href={`tel:${aboutInfo.developerPhone}`} className="text-[#E6CCB2] hover:underline">{aboutInfo.developerPhone}</a></span>
                    </div>
                  )}
                </li>
              )}
              <li><span className="hover:text-[#FFF8F2] cursor-pointer">Verified Online Store System</span></li>
              <li><span className="hover:text-[#FFF8F2] cursor-pointer">Cash on Delivery & Express Shipping</span></li>
            </ul>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-[#3D2B22] flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#8A6F5D]">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="font-mono text-[#CBB5A1]">
              {companyName} {aboutInfo?.platformCompany ? `| Powered by ${aboutInfo.platformCompany}` : ''}
            </span>
          </div>

          <div className="font-mono text-center sm:text-right">
            © {new Date().getFullYear()} {companyName}. All rights reserved.
            {aboutInfo?.developerName && (
              <span className="block sm:inline sm:ml-2 text-[#A88B77]">
                | Developed by {aboutInfo.developerName}
              </span>
            )}
          </div>
        </div>

      </div>
    </footer>
  );
};
