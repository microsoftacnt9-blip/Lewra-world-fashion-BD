import React, { useState } from 'react';
import { AboutInfo } from '../types';
import { MessageCircle, Phone, Mail, Truck, X, Sparkles, Send, ShieldCheck, Clock, ChevronRight, ExternalLink, Headphones, Facebook, Instagram } from 'lucide-react';

interface WhatsAppWidgetProps {
  aboutInfo: AboutInfo;
  onOpenTracking?: () => void;
  onOpenWishlist?: () => void;
}

export const WhatsAppWidget: React.FC<WhatsAppWidgetProps> = ({
  aboutInfo,
  onOpenTracking,
  onOpenWishlist
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [customMsg, setCustomMsg] = useState('');

  if (aboutInfo.showFloatingSupport === false) return null;

  const whatsappNum = (aboutInfo.whatsapp || aboutInfo.phone || '8801700000000').replace(/[^0-9]/g, '');
  const phoneNum = aboutInfo.phone || '+880 1700-000000';
  const secondaryPhone = aboutInfo.supportPhoneSecondary;
  const emailAddr = aboutInfo.email || 'contact@lewra.world';
  const fbMessenger = aboutInfo.facebookMessenger || (aboutInfo.facebook ? (aboutInfo.facebook.startsWith('http') ? aboutInfo.facebook : `https://facebook.com/${aboutInfo.facebook}`) : '');
  const fbPage = aboutInfo.facebook;
  const supportHours = aboutInfo.supportHours || '10:00 AM - 10:00 PM (Everyday)';

  const handleSendWhatsApp = (text?: string) => {
    const defaultMsg = aboutInfo.whatsappMessage || 'Hello Lewra Support, I want to inquire about products and delivery.';
    const messageToSend = text || customMsg || defaultMsg;
    const url = `https://wa.me/${whatsappNum}?text=${encodeURIComponent(messageToSend)}`;
    window.open(url, '_blank');
  };

  const handleOpenMessenger = () => {
    if (!fbMessenger) return;
    let url = fbMessenger;
    if (!url.startsWith('http')) {
      url = `https://m.me/${url.replace('@', '')}`;
    }
    window.open(url, '_blank');
  };

  const quickQuestions = [
    'ডেলিভারি চার্জ এবং সময় কত লাগবে?',
    'বিকাশ ও নগদ পেমেন্ট করার নিয়ম কী?',
    'প্রোডাক্টে অফিসিয়াল ওয়ারেন্টি আছে কি?',
    'অর্ডার ট্র্যাকিং ও হোম ডেলিভারি আপডেট চাই'
  ];

  return (
    <div className="fixed bottom-20 md:bottom-5 right-4 sm:right-5 z-40">
      {/* Floating Popup Window */}
      {isOpen && (
        <div className="mb-3 w-80 sm:w-96 rounded-2xl bg-[#090D18] border border-emerald-500/40 shadow-2xl overflow-hidden flex flex-col animate-in slide-in-from-bottom-5 duration-200">
          
          {/* Header */}
          <div className="p-4 bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-700 text-white flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="w-10 h-10 rounded-full bg-white/15 backdrop-blur-md flex items-center justify-center font-bold text-base border border-white/20">
                  <Headphones className="w-5 h-5 text-white" />
                </div>
                <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-300 border-2 border-emerald-700 rounded-full animate-pulse"></span>
              </div>
              <div>
                <h4 className="font-bold text-sm font-['Space_Grotesk'] leading-tight">
                  {aboutInfo.companyName || 'Lewra World'} Live Support
                </h4>
                <p className="text-[11px] text-emerald-100 flex items-center gap-1 mt-0.5 font-mono">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-200 animate-pulse"></span>
                  Active Now • {supportHours}
                </p>
              </div>
            </div>

            <button
              onClick={() => setIsOpen(false)}
              className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Body */}
          <div className="p-4 space-y-3.5 max-h-96 overflow-y-auto">
            
            {/* Greeting / Support Notice */}
            <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800 text-xs text-slate-300 space-y-1">
              <p className="font-semibold text-white flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>আসসালামু আলাইকুম! আপনাকে কীভাবে সাহায্য করতে পারি?</span>
              </p>
              <p className="text-[11px] text-slate-400">
                {aboutInfo.supportNotice || 'যেকোনো পণ্য, স্পেসিফিকেশন বা ডেলিভারি তথ্যের জন্য সরাসরি হোয়াটসঅ্যাপ বা ফেসবুক মেসেঞ্জারে যোগাযোগ করুন।'}
              </p>
            </div>

            {/* Direct Support Channels */}
            <div className="space-y-2">
              <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold block">
                Direct Channels & Support Hours (সাপোর্ট চ্যানেল ও সময়সূচি):
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {aboutInfo.whatsappEnabled !== false && (
                  <button
                    type="button"
                    onClick={() => handleSendWhatsApp()}
                    className="p-2.5 rounded-xl bg-emerald-950/60 hover:bg-emerald-900/60 border border-emerald-500/40 text-emerald-300 font-mono text-xs flex flex-col items-start gap-1 transition-all group shadow-sm text-left"
                  >
                    <div className="flex items-center gap-1.5 font-bold">
                      <MessageCircle className="w-4 h-4 text-emerald-400 group-hover:scale-110 transition-transform shrink-0" />
                      <span>WhatsApp Chat</span>
                    </div>
                    <span className="text-[10px] text-emerald-400/80 font-sans">
                      🕒 {aboutInfo.whatsappSupportHours || aboutInfo.supportHours || 'সকাল ১০:০০ AM - রাত ১০:০০ PM'}
                    </span>
                  </button>
                )}

                {aboutInfo.messengerEnabled !== false && fbMessenger && (
                  <button
                    type="button"
                    onClick={handleOpenMessenger}
                    className="p-2.5 rounded-xl bg-blue-950/60 hover:bg-blue-900/60 border border-blue-500/40 text-blue-300 font-mono text-xs flex flex-col items-start gap-1 transition-all group shadow-sm text-left"
                  >
                    <div className="flex items-center gap-1.5 font-bold">
                      <Facebook className="w-4 h-4 text-blue-400 group-hover:scale-110 transition-transform shrink-0" />
                      <span>FB Messenger</span>
                    </div>
                    <span className="text-[10px] text-blue-400/80 font-sans">
                      🕒 {aboutInfo.messengerSupportHours || aboutInfo.supportHours || 'সকাল ০৯:০০ AM - রাত ১১:০০ PM'}
                    </span>
                  </button>
                )}
              </div>
            </div>

            {/* Quick Question Chips */}
            <div className="space-y-1.5">
              <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold block">
                Quick Questions (দ্রুত বার্তা পাঠান):
              </span>
              <div className="space-y-1">
                {quickQuestions.map((q, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleSendWhatsApp(q)}
                    className="w-full text-left p-2 rounded-lg bg-slate-950/80 hover:bg-emerald-950/40 border border-slate-800 hover:border-emerald-500/40 text-slate-300 hover:text-emerald-300 text-xs transition-all flex items-center justify-between group"
                  >
                    <span className="truncate">{q}</span>
                    <ChevronRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-emerald-400 shrink-0" />
                  </button>
                ))}
              </div>
            </div>

            {/* Custom Input */}
            <div className="space-y-1.5">
              <div className="relative">
                <input
                  type="text"
                  value={customMsg}
                  onChange={(e) => setCustomMsg(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleSendWhatsApp();
                  }}
                  placeholder="Type your question for WhatsApp..."
                  className="w-full bg-[#050811] border border-slate-700 rounded-xl pl-3 pr-9 py-2 text-xs text-white placeholder-slate-500 font-sans focus:outline-none focus:border-emerald-400"
                />
                <button
                  type="button"
                  onClick={() => handleSendWhatsApp()}
                  className="absolute right-1.5 top-1/2 -translate-y-1/2 p-1.5 rounded-lg bg-emerald-500 text-slate-950 hover:bg-emerald-400 transition-colors"
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Support Actions Grid (Call & Order Tracking) */}
            <div className="grid grid-cols-2 gap-2 pt-1 border-t border-slate-800 text-xs font-mono">
              <a
                href={`tel:${phoneNum}`}
                className="p-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-cyan-500/40 hover:bg-slate-800 text-slate-300 text-center flex items-center justify-center gap-1.5 transition-all"
              >
                <Phone className="w-3.5 h-3.5 text-cyan-400" />
                <span>Call Hotline</span>
              </a>

              {onOpenTracking && (
                <button
                  type="button"
                  onClick={() => {
                    setIsOpen(false);
                    onOpenTracking();
                  }}
                  className="p-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-purple-500/40 hover:bg-slate-800 text-slate-300 text-center flex items-center justify-center gap-1.5 transition-all"
                >
                  <Truck className="w-3.5 h-3.5 text-purple-400" />
                  <span>Track Order</span>
                </button>
              )}
            </div>

            {secondaryPhone && (
              <div className="text-center pt-0.5">
                <a
                  href={`tel:${secondaryPhone}`}
                  className="text-[11px] text-amber-400 hover:underline font-mono inline-flex items-center gap-1"
                >
                  <Phone className="w-3 h-3" />
                  Secondary Hotline: {secondaryPhone}
                </a>
              </div>
            )}

          </div>

          {/* Footer Note */}
          <div className="p-2.5 bg-slate-950 border-t border-slate-800/80 flex items-center justify-between text-[10px] font-mono text-slate-400 px-3">
            <span className="flex items-center gap-1">
              <Clock className="w-3 h-3 text-cyan-400" />
              <span>{supportHours}</span>
            </span>
            {fbPage && (
              <a
                href={fbPage.startsWith('http') ? fbPage : `https://facebook.com/${fbPage}`}
                target="_blank"
                rel="noreferrer"
                className="text-blue-400 hover:underline flex items-center gap-1 font-bold"
              >
                <Facebook className="w-3 h-3" />
                <span>Official Page</span>
              </a>
            )}
          </div>

        </div>
      )}

      {/* Main Trigger Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="relative group flex items-center gap-2 px-4 py-3 rounded-full bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-slate-950 font-bold shadow-xl shadow-emerald-500/30 hover:scale-105 transition-all duration-200"
        title="Chat with Customer Support"
      >
        <span className="relative flex h-3 w-3">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75"></span>
          <span className="relative inline-flex rounded-full h-3 w-3 bg-white"></span>
        </span>
        
        <Headphones className="w-5 h-5 text-slate-950" />
        
        <span className="text-xs font-['Space_Grotesk'] font-extrabold tracking-wide hidden sm:inline">
          {isOpen ? 'Close Support' : 'Live Support (সাপোর্ট)'}
        </span>
      </button>
    </div>
  );
};
