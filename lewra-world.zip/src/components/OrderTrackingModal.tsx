import React, { useState, useEffect } from 'react';
import { Order, AboutInfo } from '../types';
import { X, Search, Package, Truck, CheckCircle2, Clock, MapPin, Phone, User, Calendar, CreditCard, ShieldCheck, FileText, ArrowRight, MessageCircle, AlertCircle, Sparkles, Star, ThumbsUp, PackageCheck } from 'lucide-react';
import { DeliveryConfirmationModal } from './DeliveryConfirmationModal';

interface OrderTrackingModalProps {
  isOpen: boolean;
  onClose: () => void;
  orders: Order[];
  aboutInfo: AboutInfo;
  initialOrderId?: string;
  onViewInvoice?: (order: Order) => void;
  onConfirmReceived?: (orderId: string, rating: number, review: string) => void;
}

export const OrderTrackingModal: React.FC<OrderTrackingModalProps> = ({
  isOpen,
  onClose,
  orders,
  aboutInfo,
  initialOrderId = '',
  onViewInvoice,
  onConfirmReceived
}) => {
  const [searchQuery, setSearchQuery] = useState(initialOrderId || '');
  const [searchedOrder, setSearchedOrder] = useState<Order | null>(null);
  const [matchedOrders, setMatchedOrders] = useState<Order[]>([]);
  const [errorMsg, setErrorMsg] = useState('');
  const [hasSearched, setHasSearched] = useState(false);
  const [showConfirmModal, setShowConfirmModal] = useState(false);

  // Auto search when modal opens or initialOrderId changes
  useEffect(() => {
    if (isOpen) {
      if (initialOrderId) {
        setSearchQuery(initialOrderId);
        handleSearch(initialOrderId);
      } else if (orders.length > 0 && !searchedOrder) {
        // Pre-select most recent order if available
        setSearchedOrder(orders[0]);
        setSearchQuery(orders[0].id);
        setHasSearched(true);
      }
    }
  }, [initialOrderId, isOpen, orders]);

  if (!isOpen) return null;

  const handleSearch = (queryOverride?: string) => {
    const rawQuery = (queryOverride !== undefined ? queryOverride : searchQuery).trim();
    const q = rawQuery.toLowerCase();
    setHasSearched(true);
    setErrorMsg('');

    if (!q) {
      setErrorMsg('অনুগ্রহ করে আপনার অর্ডার আইডি (যেমন: ORD-9821) অথবা মোবাইল নম্বর লিখুন।');
      setSearchedOrder(null);
      setMatchedOrders([]);
      return;
    }

    const cleanNumeric = q.replace(/[^0-9]/g, '');

    // Comprehensive flexible matching
    const matches = orders.filter(o => {
      const ordId = (o.id || '').toLowerCase();
      const ordPhone = (o.customerPhone || '').replace(/[^0-9]/g, '');
      const ordEmail = (o.customerEmail || '').toLowerCase();
      const ordName = (o.customerName || '').toLowerCase();
      const ordSenderPhone = (o.paymentSenderPhone || '').replace(/[^0-9]/g, '');
      const ordTrx = (o.paymentTrxId || '').toLowerCase();

      // Exact or partial ID matches (with or without # or ORD- prefix)
      if (ordId === q || ordId.replace('#', '') === q.replace('#', '') || ordId.includes(q)) {
        return true;
      }
      // Phone number partial or full match (at least 4 digits)
      if (cleanNumeric.length >= 4 && (ordPhone.includes(cleanNumeric) || ordSenderPhone.includes(cleanNumeric))) {
        return true;
      }
      // Email match
      if (ordEmail && ordEmail.includes(q)) {
        return true;
      }
      // Customer Name match
      if (ordName && ordName.includes(q)) {
        return true;
      }
      // TrxID match
      if (ordTrx && ordTrx.includes(q)) {
        return true;
      }
      return false;
    });

    if (matches.length > 0) {
      setSearchedOrder(matches[0]);
      setMatchedOrders(matches);
      setErrorMsg('');
    } else {
      setSearchedOrder(null);
      setMatchedOrders([]);
      setErrorMsg(`"${rawQuery}" দিয়ে কোনো অর্ডার রেকর্ড পাওয়া যায়নি। অনুগ্রহ করে সঠিক অর্ডার আইডি বা মোবাইল নম্বর দিয়ে চেষ্টা করুন।`);
    }
  };

  const getStepStatus = (stepIndex: number, status: Order['status']) => {
    // 0: Placed, 1: Verified/Processing, 2: Packaging, 3: Shipped, 4: Delivered
    if (status === 'Cancelled') {
      return stepIndex === 0 ? 'completed' : 'cancelled';
    }

    const statusMap: Record<Order['status'], number> = {
      'Pending': 0,
      'Processing': 2,
      'Shipped': 3,
      'Completed': 4,
      'Cancelled': -1
    };

    const currentLevel = statusMap[status] ?? 0;
    if (stepIndex < currentLevel) return 'completed';
    if (stepIndex === currentLevel) return 'current';
    return 'upcoming';
  };

  const steps = [
    {
      id: 0,
      title: 'Order Placed',
      titleBn: 'অর্ডার গৃহীত',
      desc: 'Order details received and entered in system.'
    },
    {
      id: 1,
      title: 'Verification & Payment',
      titleBn: 'ভেরিফিকেশন সম্পন্ন',
      desc: 'Payment & shipping details verified by admin.'
    },
    {
      id: 2,
      title: 'Packaging & Quality Check',
      titleBn: 'প্যাকেজিং ও প্রস্তুতি',
      desc: 'Genuine hardware tested, boxed & sealed.'
    },
    {
      id: 3,
      title: 'Shipped / In Transit',
      titleBn: 'কুরিয়ারে হস্তান্তর',
      desc: 'Handed over to courier partner for express delivery.'
    },
    {
      id: 4,
      title: 'Delivered',
      titleBn: 'ডেলিভারি সম্পন্ন',
      desc: 'Parcel successfully handed over to customer.'
    }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-[#090D18] border border-slate-700/80 max-w-2xl w-full rounded-2xl flex flex-col max-h-[90vh] overflow-hidden shadow-2xl relative">
        
        {/* Header */}
        <div className="p-4 sm:p-6 bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-bold text-white font-['Space_Grotesk'] flex items-center gap-2">
                Live Order Tracking
                <span className="text-xs px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 font-mono font-semibold">
                  রিয়েল-টাইম ট্র্যাকিং
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                আপনার অর্ডার আইডি বা ফোন নম্বর দিয়ে অর্ডারের সর্বশেষ অবস্থা জানুন
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-6">
          
          {/* Search Box */}
          <div className="space-y-2">
            <label className="text-xs font-mono text-slate-300 block font-bold">
              Enter Order ID or Mobile Number (অর্ডার আইডি বা মোবাইল নম্বর):
            </label>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSearch();
              }}
              className="flex gap-2"
            >
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="e.g. ORD-9821 or 01712345678"
                  className="w-full bg-[#050811] border border-slate-700 rounded-xl pl-10 pr-3.5 py-2.5 text-xs sm:text-sm text-white font-mono placeholder-slate-500 focus:outline-none focus:border-cyan-400 shadow-inner"
                />
              </div>
              <button
                type="submit"
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs sm:text-sm flex items-center gap-1.5 transition-all shadow-lg shadow-cyan-500/20 shrink-0"
              >
                <Search className="w-4 h-4" />
                <span>Track (খুঁজুন)</span>
              </button>
            </form>

            {/* Quick chips if recent orders exist */}
            {orders.length > 0 && (
              <div className="flex items-center gap-2 flex-wrap pt-1">
                <span className="text-[11px] text-slate-400 font-mono">Recent Orders:</span>
                {orders.slice(0, 4).map((ord) => (
                  <button
                    key={ord.id}
                    type="button"
                    onClick={() => {
                      setSearchQuery(ord.id);
                      handleSearch(ord.id);
                    }}
                    className={`text-[11px] font-mono px-2.5 py-1 rounded-lg border transition-all ${
                      searchedOrder?.id === ord.id
                        ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50 font-bold'
                        : 'bg-slate-900 border-slate-800 text-slate-300 hover:text-white hover:border-slate-700'
                    }`}
                  >
                    #{ord.id} ({ord.customerName})
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Multiple matches selector if user searched by phone number with multiple orders */}
          {matchedOrders.length > 1 && (
            <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 space-y-2">
              <span className="text-xs font-mono text-cyan-300 font-bold block">
                Found {matchedOrders.length} Orders for this search. Select an order to view:
              </span>
              <div className="flex flex-wrap gap-2">
                {matchedOrders.map((mo) => (
                  <button
                    key={mo.id}
                    type="button"
                    onClick={() => setSearchedOrder(mo)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-mono transition-all flex items-center gap-1.5 ${
                      searchedOrder?.id === mo.id
                        ? 'bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/30'
                        : 'bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white border border-slate-700'
                    }`}
                  >
                    <span>#{mo.id}</span>
                    <span className="opacity-75">({mo.status})</span>
                    <span className="font-bold">৳{mo.totalAmount}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Error Message */}
          {errorMsg && (
            <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2.5 font-mono">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Order Found Details */}
          {searchedOrder && (
            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2">
              
              {/* Order Info Card */}
              <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-800">
                  <div>
                    <div className="text-xs font-mono text-slate-400">TRACKING ORDER ID</div>
                    <div className="text-base sm:text-lg font-bold text-white font-mono flex items-center gap-2">
                      <span>#{searchedOrder.id}</span>
                      <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-mono font-bold border ${
                        searchedOrder.status === 'Completed' ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40' :
                        searchedOrder.status === 'Shipped' ? 'bg-indigo-500/20 text-indigo-300 border-indigo-500/40' :
                        searchedOrder.status === 'Processing' ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40' :
                        searchedOrder.status === 'Cancelled' ? 'bg-rose-500/20 text-rose-300 border-rose-500/40' :
                        'bg-amber-500/20 text-amber-300 border-amber-500/40'
                      }`}>
                        {searchedOrder.status}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {onViewInvoice && (
                      <button
                        type="button"
                        onClick={() => onViewInvoice(searchedOrder)}
                        className="px-3 py-1.5 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 text-xs font-mono font-bold flex items-center gap-1.5 transition-all"
                      >
                        <FileText className="w-3.5 h-3.5" />
                        <span>Print Invoice (ইনভয়েস)</span>
                      </button>
                    )}
                  </div>
                </div>

                {/* Recipient & Courier Details Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs font-mono">
                  <div className="space-y-1">
                    <div className="text-slate-400 flex items-center gap-1.5">
                      <User className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Recipient:</span>
                      <strong className="text-white">{searchedOrder.customerName}</strong>
                    </div>
                    <div className="text-slate-400 flex items-center gap-1.5">
                      <Phone className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Phone:</span>
                      <span className="text-slate-200">{searchedOrder.customerPhone || 'N/A'}</span>
                    </div>
                    <div className="text-slate-400 flex items-start gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-cyan-400 shrink-0 mt-0.5" />
                      <span className="text-slate-200 leading-tight">{searchedOrder.shippingAddress || 'N/A'}</span>
                    </div>
                  </div>

                  <div className="space-y-1 sm:border-l sm:border-slate-800 sm:pl-3">
                    <div className="text-slate-400 flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-purple-400" />
                      <span>Order Date:</span>
                      <span className="text-slate-200">
                        {new Date(searchedOrder.createdAt).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}
                      </span>
                    </div>
                    <div className="text-slate-400 flex items-center gap-1.5">
                      <CreditCard className="w-3.5 h-3.5 text-purple-400" />
                      <span>Payment:</span>
                      <span className="text-amber-300 font-bold">{searchedOrder.paymentMethod || 'Cash on Delivery'}</span>
                    </div>
                    <div className="text-slate-400 flex items-center gap-1.5">
                      <Truck className="w-3.5 h-3.5 text-purple-400" />
                      <span>Courier:</span>
                      <span className="text-emerald-300 font-bold">
                        {searchedOrder.trackingCourier || (searchedOrder.deliveryZone === 'inside' ? 'Dhaka Express Rider' : 'Steadfast / Pathao Courier')}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Visual 5-Step Timeline */}
              <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-b from-slate-900/90 to-slate-950 border border-cyan-500/30 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-mono font-bold text-cyan-300 flex items-center gap-2 uppercase tracking-wider">
                    <Sparkles className="w-4 h-4 text-cyan-400" />
                    Delivery Progress Timeline (অর্ডার অগ্রগতি)
                  </h3>
                  <span className="text-[11px] font-mono text-slate-400">
                    Estimated: {searchedOrder.estimatedDeliveryTime || (searchedOrder.deliveryZone === 'inside' ? '24 - 48 Hours' : '2 - 4 Days')}
                  </span>
                </div>

                {searchedOrder.status === 'Cancelled' ? (
                  <div className="p-4 rounded-xl bg-rose-500/20 border border-rose-500/40 text-rose-200 text-xs font-mono space-y-1">
                    <div className="font-bold flex items-center gap-2 text-rose-300">
                      <AlertCircle className="w-4 h-4 text-rose-400" />
                      This Order was Cancelled ({searchedOrder.cancelledBy ? `by ${searchedOrder.cancelledBy}` : 'Cancelled'})
                    </div>
                    <p className="text-[11px] text-rose-300/80">
                      Refund status: {searchedOrder.refundStatus || 'Please contact support on WhatsApp for queries.'}
                    </p>
                  </div>
                ) : (
                  <div className="space-y-4 relative before:absolute before:left-[17px] before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-800">
                    {steps.map((step) => {
                      const state = getStepStatus(step.id, searchedOrder.status);
                      return (
                        <div key={step.id} className="relative flex items-start gap-3.5 pl-0.5 group">
                          {/* Step Icon */}
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 z-10 font-mono text-xs font-bold transition-all shadow-md ${
                            state === 'completed'
                              ? 'bg-emerald-500 text-slate-950 shadow-emerald-500/30 ring-4 ring-emerald-500/20'
                              : state === 'current'
                              ? 'bg-cyan-400 text-slate-950 shadow-cyan-500/30 ring-4 ring-cyan-500/20 animate-pulse'
                              : 'bg-slate-800 text-slate-400 border border-slate-700'
                          }`}>
                            {state === 'completed' ? (
                              <CheckCircle2 className="w-4 h-4" />
                            ) : (
                              step.id + 1
                            )}
                          </div>

                          {/* Step Content */}
                          <div className={`flex-1 p-3 rounded-xl border transition-all ${
                            state === 'current'
                              ? 'bg-cyan-950/30 border-cyan-500/40 text-white'
                              : state === 'completed'
                              ? 'bg-slate-900/60 border-slate-800 text-slate-200'
                              : 'bg-slate-950/40 border-slate-900 text-slate-500'
                          }`}>
                            <div className="flex items-center justify-between">
                              <span className="font-bold text-xs sm:text-sm font-['Space_Grotesk']">
                                {step.titleBn} ({step.title})
                              </span>
                              {state === 'current' && (
                                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 font-bold uppercase tracking-wider">
                                  Current Status
                                </span>
                              )}
                              {state === 'completed' && (
                                <span className="text-[10px] font-mono text-emerald-400 font-bold">
                                  ✓ Completed
                                </span>
                              )}
                            </div>
                            <p className="text-[11px] text-slate-400 mt-0.5">
                              {step.desc}
                            </p>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Order Items Table */}
              <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
                <div className="text-xs font-mono font-bold text-slate-300 flex items-center gap-1.5">
                  <Package className="w-4 h-4 text-purple-400" />
                  Ordered Items ({searchedOrder.items.length})
                </div>

                <div className="divide-y divide-slate-800">
                  {searchedOrder.items.map((item, idx) => (
                    <div key={idx} className="py-2.5 flex items-center justify-between text-xs">
                      <div>
                        <div className="font-bold text-white">{item.productName}</div>
                        {(item.selectedColor || item.selectedSpec || item.selectedSize) && (
                          <div className="text-[11px] text-cyan-400 font-mono">
                            {[item.selectedColor, item.selectedSize, item.selectedSpec].filter(Boolean).join(' • ')}
                          </div>
                        )}
                        <div className="text-slate-400 text-[11px] font-mono">
                          Qty: {item.quantity} × ৳{item.price.toLocaleString()} BDT
                        </div>
                      </div>
                      <div className="font-mono font-bold text-emerald-400">
                        ৳{(item.price * item.quantity).toLocaleString()} BDT
                      </div>
                    </div>
                  ))}
                </div>

                {/* Grand Total */}
                <div className="pt-2 border-t border-slate-800 flex items-center justify-between font-mono text-xs">
                  <span className="text-slate-400">Grand Total Payable:</span>
                  <span className="text-sm font-bold text-cyan-300">
                    ৳{searchedOrder.totalAmount.toLocaleString()} BDT
                  </span>
                </div>
              </div>

              {/* Customer Received Confirmation Section */}
              {searchedOrder.customerReceived ? (
                <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-950/50 via-teal-950/40 to-slate-900 border border-emerald-500/50 space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-emerald-300 font-bold text-xs">
                      <PackageCheck className="w-4 h-4 text-emerald-400" />
                      <span>কাস্টমার কর্তৃক ডেলিভারি নিশ্চিত হয়েছে (Delivered & Verified)</span>
                    </div>
                    {searchedOrder.customerReceivedAt && (
                      <span className="text-[10px] font-mono text-emerald-400/80">
                        {new Date(searchedOrder.customerReceivedAt).toLocaleDateString('en-GB')}
                      </span>
                    )}
                  </div>
                  {searchedOrder.customerRating && (
                    <div className="flex items-center gap-1.5 text-xs text-amber-400">
                      <span>Rating:</span>
                      <div className="flex">
                        {[...Array(searchedOrder.customerRating)].map((_, i) => (
                          <Star key={i} className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                        ))}
                      </div>
                    </div>
                  )}
                  {searchedOrder.customerReview && (
                    <p className="text-xs text-slate-300 italic bg-slate-950/60 p-2.5 rounded-xl border border-slate-800">
                      "{searchedOrder.customerReview}"
                    </p>
                  )}
                </div>
              ) : searchedOrder.status !== 'Cancelled' ? (
                <div className="p-4 rounded-2xl bg-gradient-to-r from-cyan-950/40 to-slate-900 border border-cyan-500/40 flex flex-col sm:flex-row items-center justify-between gap-3">
                  <div className="space-y-0.5 text-center sm:text-left">
                    <div className="text-xs font-bold text-cyan-300 flex items-center gap-1.5 justify-center sm:justify-start">
                      <PackageCheck className="w-4 h-4 text-cyan-400" />
                      <span>পণ্যটি কি হাতে পেয়েছেন?</span>
                    </div>
                    <p className="text-[11px] text-slate-400">
                      পণ্য বুঝে পেয়ে থাকলে কনফার্ম করে ওয়ারেন্টি অ্যাক্টিভ করুন ও রেটিং দিন।
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setShowConfirmModal(true)}
                    className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold font-mono text-xs flex items-center justify-center gap-1.5 transition-all shadow-md shrink-0"
                  >
                    <ThumbsUp className="w-4 h-4" />
                    <span>পণ্য পেয়েছি (Mark as Received)</span>
                  </button>
                </div>
              ) : null}

              {/* Direct WhatsApp Support Helper */}
              <div className="p-3.5 rounded-xl bg-gradient-to-r from-emerald-950/40 to-slate-900 border border-emerald-500/40 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-full bg-emerald-500 flex items-center justify-center text-slate-950 font-bold shrink-0">
                    <MessageCircle className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-emerald-300">Need Immediate Delivery Support?</div>
                    <div className="text-[11px] text-slate-400">Chat with admin regarding Order #{searchedOrder.id}</div>
                  </div>
                </div>

                <a
                  href={`https://wa.me/${(aboutInfo.whatsapp || aboutInfo.phone || '8801700000000').replace(/[^0-9]/g, '')}?text=${encodeURIComponent(`Hello Support, I want an update regarding my Order #${searchedOrder.id} (Customer: ${searchedOrder.customerName}).`)}`}
                  target="_blank"
                  rel="noreferrer"
                  className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-md shrink-0"
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                  <span>WhatsApp Helpline</span>
                </a>
              </div>

            </div>
          )}

        </div>

      </div>

      {/* Confirmation Modal */}
      {showConfirmModal && searchedOrder && (
        <DeliveryConfirmationModal
          isOpen={showConfirmModal}
          onClose={() => setShowConfirmModal(false)}
          order={searchedOrder}
          onConfirm={(orderId, rating, review) => {
            if (onConfirmReceived) {
              onConfirmReceived(orderId, rating, review);
            }
            setSearchedOrder({
              ...searchedOrder,
              customerReceived: true,
              customerReceivedAt: new Date().toISOString(),
              customerRating: rating,
              customerReview: review,
              status: 'Completed'
            });
            setShowConfirmModal(false);
          }}
        />
      )}
    </div>
  );
};
