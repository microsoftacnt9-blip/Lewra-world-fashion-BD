import React, { useState } from 'react';
import { AboutInfo, UserAccount } from '../types';
import { User, Mail, Phone, MapPin, Globe, Sparkles, MessageSquare, Edit3, CheckCircle2, Facebook, Youtube, Flag, Award, Calendar, ShieldCheck, Copy, Check, Smartphone, CreditCard } from 'lucide-react';
import { copyCleanPhoneNumber, extractCleanPhoneNumber } from '../utils/discountUtils';

interface AboutUsProps {
  aboutInfo: AboutInfo;
  currentUser?: UserAccount | null;
  onOpenAdmin: () => void;
}

export const AboutUs: React.FC<AboutUsProps> = ({ aboutInfo, currentUser, onOpenAdmin }) => {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const brandCountry = aboutInfo.brandOriginCountry || 'Bangladesh';
  const brandFlag = aboutInfo.brandOriginFlag || '🇧🇩';

  const isAdminUser = Boolean(
    currentUser?.email && (
      currentUser.email.toLowerCase().trim() === 'microsoftacnt9@gmail.com' ||
      currentUser.email.toLowerCase().trim().startsWith('microsoftacnt9@') ||
      currentUser.email.toLowerCase().trim() === 'admin@gmail.com'
    )
  );

  const handleCopy = (rawNumber: string | undefined, key: string) => {
    if (!rawNumber) return;
    const clean = copyCleanPhoneNumber(rawNumber);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2500);
  };

  return (
    <section id="about" className="py-24 relative bg-[#060912] border-t border-slate-800/80 overflow-hidden">
      {/* Background glow effects */}
      <div className="absolute top-1/2 left-0 w-80 h-80 bg-purple-600/10 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute bottom-0 right-10 w-96 h-96 bg-cyan-500/10 rounded-full blur-[150px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-900 border border-cyan-500/30 text-cyan-300 text-xs font-mono font-semibold uppercase tracking-wider mb-4">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              ABOUT OUR COMPANY & TEAM
            </div>
            <div className="flex flex-wrap items-center gap-3">
              <h2 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight font-['Space_Grotesk']">
                About <span className="text-gradient-cyan">{aboutInfo.companyName}</span>
              </h2>
              {/* Brand Origin Country Tag */}
              <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-gradient-to-r from-cyan-950/80 to-slate-900 border border-cyan-500/40 text-cyan-300 text-xs font-mono font-bold shadow-md">
                <span className="text-base leading-none">{brandFlag}</span>
                <span>{brandCountry} Brand</span>
                {aboutInfo.brandEstablishedYear && (
                  <span className="text-slate-400 font-normal border-l border-slate-700 pl-1.5 ml-0.5">
                    Est. {aboutInfo.brandEstablishedYear}
                  </span>
                )}
              </div>
            </div>
            <p className="text-slate-400 text-base mt-2 max-w-2xl">
              {aboutInfo.tagline}
            </p>
          </div>

          {isAdminUser && (
            <button
              onClick={onOpenAdmin}
              className="px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-cyan-500/40 text-cyan-300 text-xs font-mono font-semibold flex items-center gap-2 shadow-lg transition-all self-start md:self-auto"
            >
              <Edit3 className="w-4 h-4 text-cyan-400" />
              Edit About Us Details (বিবরণ পরিবর্তন করুন)
            </button>
          )}
        </div>

        {/* Content Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Main Story & Details (7 Cols) */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* Brand Origin & Heritage Highlight Card */}
            <div className="p-5 rounded-2xl bg-gradient-to-r from-cyan-950/40 via-slate-950/70 to-purple-950/30 border border-cyan-500/30 space-y-3 relative overflow-hidden shadow-xl">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-cyan-300 font-bold text-xs font-mono">
                  <Flag className="w-4 h-4 text-cyan-400" />
                  BRAND ORIGIN & HERITAGE (ব্র্যান্ডের মূল উৎস ও পরিচিতি)
                </div>
                <span className="text-xs font-mono px-2.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-bold flex items-center gap-1.5">
                  <span className="text-sm">{brandFlag}</span>
                  {brandCountry}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs font-mono">
                <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 space-y-1">
                  <span className="text-[10px] text-slate-400 uppercase flex items-center gap-1">
                    <Globe className="w-3 h-3 text-cyan-400" /> Origin Country
                  </span>
                  <span className="text-white font-bold text-sm block flex items-center gap-1.5">
                    <span>{brandFlag}</span>
                    {brandCountry}
                  </span>
                </div>

                <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 space-y-1">
                  <span className="text-[10px] text-slate-400 uppercase flex items-center gap-1">
                    <Calendar className="w-3 h-3 text-purple-400" /> Established Year
                  </span>
                  <span className="text-purple-300 font-bold text-sm block">
                    {aboutInfo.brandEstablishedYear || 'Active Store'}
                  </span>
                </div>

                <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 space-y-1">
                  <span className="text-[10px] text-slate-400 uppercase flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3 text-emerald-400" /> Quality Guarantee
                  </span>
                  <span className="text-emerald-400 font-bold text-sm block">
                    100% Authentic
                  </span>
                </div>
              </div>

              {aboutInfo.brandOriginStory && (
                <p className="text-xs text-slate-300 leading-relaxed font-sans bg-slate-950/60 p-3 rounded-xl border border-slate-800/80">
                  {aboutInfo.brandOriginStory}
                </p>
              )}
            </div>

            <div className="glass-card p-6 sm:p-8 rounded-2xl border border-slate-800 space-y-4">
              <h3 className="text-xl sm:text-2xl font-bold text-white font-['Space_Grotesk']">
                Who We Are & What We Do
              </h3>
              <p className="text-sm text-slate-300 leading-relaxed whitespace-pre-line">
                {aboutInfo.bio}
              </p>

              <div className="pt-4 grid grid-cols-1 sm:grid-cols-2 gap-4 border-t border-slate-800">
                <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-950/60 border border-slate-800">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-xs font-bold text-white">Genuine Products</h4>
                    <p className="text-[11px] text-slate-400">100% authentic tech & hardware with real warranty.</p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-950/60 border border-slate-800">
                  <CheckCircle2 className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-xs font-bold text-white">Dedicated Customer Support</h4>
                    <p className="text-[11px] text-slate-400">Quick response via WhatsApp & Direct Line.</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Address & Direct Contact Box */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="glass-card p-5 rounded-2xl border border-slate-800 flex items-start gap-3">
                <div className="p-2.5 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[10px] font-mono text-slate-400 uppercase block">OUR OFFICE ADDRESS</span>
                  <span className="text-xs font-bold text-white">{aboutInfo.address}</span>
                </div>
              </div>

              <div className="glass-card p-5 rounded-2xl border border-slate-800 flex items-start gap-3">
                <div className="p-2.5 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[10px] font-mono text-slate-400 uppercase block">PHONE NUMBER</span>
                  <a href={`tel:${aboutInfo.phone}`} className="text-xs font-bold text-emerald-300 hover:underline">
                    {aboutInfo.phone}
                  </a>
                </div>
              </div>
            </div>
          </div>

          {/* Founder / Contact Card (5 Cols) */}
          <div className="lg:col-span-5 space-y-6">
            <div className="glass-card p-6 sm:p-8 rounded-2xl border border-slate-800 space-y-6 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-500/10 rounded-full blur-2xl pointer-events-none" />

              <div className="flex items-center gap-4 pb-4 border-b border-slate-800">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-cyan-500 to-indigo-600 p-[1px]">
                  <div className="w-full h-full bg-slate-900 rounded-[15px] flex items-center justify-center text-cyan-400">
                    <User className="w-7 h-7" />
                  </div>
                </div>
                <div>
                  <h4 className="text-lg font-bold text-white font-['Space_Grotesk']">{aboutInfo.ownerName}</h4>
                  <p className="text-xs font-mono text-cyan-400">{aboutInfo.ownerRole}</p>
                </div>
              </div>

              {/* Direct Info List */}
              <div className="space-y-3 text-xs">
                {/* Brand Origin Info row */}
                <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950/80 border border-cyan-500/30">
                  <span className="text-slate-400 flex items-center gap-2">
                    <Globe className="w-4 h-4 text-cyan-400" />
                    Brand Origin Country
                  </span>
                  <span className="font-mono text-cyan-300 font-bold flex items-center gap-1.5">
                    <span>{brandFlag}</span>
                    <span>{brandCountry}</span>
                  </span>
                </div>

                <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                  <span className="text-slate-400 flex items-center gap-2">
                    <Mail className="w-4 h-4 text-cyan-400" />
                    Official Email
                  </span>
                  <a href={`mailto:${aboutInfo.email}`} className="font-mono text-white hover:text-cyan-300">
                    {aboutInfo.email}
                  </a>
                </div>

                <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                  <span className="text-slate-400 flex items-center gap-2">
                    <Phone className="w-4 h-4 text-emerald-400" />
                    Direct Call / Hotline
                  </span>
                  <div className="flex items-center gap-2">
                    <a href={`tel:${extractCleanPhoneNumber(aboutInfo.phone)}`} className="font-mono text-emerald-300 font-bold hover:underline">
                      {extractCleanPhoneNumber(aboutInfo.phone) || aboutInfo.phone}
                    </a>
                    <button
                      type="button"
                      onClick={() => handleCopy(aboutInfo.phone, 'phone')}
                      className="p-1 rounded bg-slate-900 border border-slate-700 text-slate-400 hover:text-cyan-300 transition-colors"
                      title="ক্লিক করে শুধুমাত্র নম্বর কপি করুন"
                    >
                      {copiedKey === 'phone' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    </button>
                  </div>
                </div>

                {aboutInfo.bkashNumber && (
                  <div className="flex items-center justify-between p-3 rounded-xl bg-pink-950/20 border border-pink-500/30">
                    <span className="text-pink-300 font-bold flex items-center gap-2">
                      <Smartphone className="w-4 h-4 text-pink-400" />
                      bKash (Send Money)
                    </span>
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-white font-bold">
                        {extractCleanPhoneNumber(aboutInfo.bkashNumber)}
                      </span>
                      <button
                        type="button"
                        onClick={() => handleCopy(aboutInfo.bkashNumber, 'bkash')}
                        className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold flex items-center gap-1 transition-all ${
                          copiedKey === 'bkash'
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                            : 'bg-pink-500/20 text-pink-300 hover:bg-pink-500/30 border border-pink-500/40'
                        }`}
                        title="শুধুমাত্র বিকাশ নম্বর কপি হবে"
                      >
                        {copiedKey === 'bkash' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                        <span>{copiedKey === 'bkash' ? 'Copied!' : 'Copy'}</span>
                      </button>
                    </div>
                  </div>
                )}

                {aboutInfo.nagadNumber && (
                  <div className="flex items-center justify-between p-3 rounded-xl bg-amber-950/20 border border-amber-500/30">
                    <span className="text-amber-300 font-bold flex items-center gap-2">
                      <CreditCard className="w-4 h-4 text-amber-400" />
                      Nagad (Send Money)
                    </span>
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-white font-bold">
                        {extractCleanPhoneNumber(aboutInfo.nagadNumber)}
                      </span>
                      <button
                        type="button"
                        onClick={() => handleCopy(aboutInfo.nagadNumber, 'nagad')}
                        className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold flex items-center gap-1 transition-all ${
                          copiedKey === 'nagad'
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                            : 'bg-amber-500/20 text-amber-300 hover:bg-amber-500/30 border border-amber-500/40'
                        }`}
                        title="শুধুমাত্র নগদ নম্বর কপি হবে"
                      >
                        {copiedKey === 'nagad' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                        <span>{copiedKey === 'nagad' ? 'Copied!' : 'Copy'}</span>
                      </button>
                    </div>
                  </div>
                )}

                {aboutInfo.whatsapp && (
                  <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                    <span className="text-slate-400 flex items-center gap-2">
                      <MessageSquare className="w-4 h-4 text-emerald-400" />
                      WhatsApp Message
                    </span>
                    <a
                      href={`https://wa.me/${aboutInfo.whatsapp.replace(/[^0-9]/g, '')}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="font-mono text-emerald-400 hover:underline font-bold"
                    >
                      Chat on WhatsApp
                    </a>
                  </div>
                )}
              </div>

              {/* Social Channels */}
              <div className="pt-2">
                <span className="text-[10px] font-mono text-slate-400 uppercase block mb-3">Connect With Us</span>
                <div className="flex items-center gap-3">
                  {aboutInfo.facebook && (
                    <a
                      href={aboutInfo.facebook}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-cyan-400 hover:border-cyan-500/50 transition-colors"
                      title="Facebook"
                    >
                      <Facebook className="w-4 h-4" />
                    </a>
                  )}
                  {aboutInfo.youtube && (
                    <a
                      href={aboutInfo.youtube}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-rose-400 hover:border-rose-500/50 transition-colors"
                      title="YouTube"
                    >
                      <Youtube className="w-4 h-4" />
                    </a>
                  )}
                  {aboutInfo.website && (
                    <a
                      href={aboutInfo.website}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-indigo-400 hover:border-indigo-500/50 transition-colors"
                      title="Website"
                    >
                      <Globe className="w-4 h-4" />
                    </a>
                  )}
                </div>
              </div>

              {/* Developer & Platform Company Badges */}
              {(aboutInfo.developerName || aboutInfo.platformCompany) && (
                <div className="pt-3 border-t border-slate-800 space-y-2">
                  <span className="text-[10px] font-mono text-cyan-400 uppercase block">Platform & Developer Partners</span>
                  {aboutInfo.platformCompany && (
                    <div className="text-xs text-slate-300 font-mono">
                      Platform: <strong className="text-white">{aboutInfo.platformCompany}</strong>
                    </div>
                  )}
                  {aboutInfo.developerName && (
                    <div className="text-xs text-slate-300 font-mono space-y-1">
                      <div>
                        Developed By:{' '}
                        {aboutInfo.developerWebsite ? (
                          <a href={aboutInfo.developerWebsite} target="_blank" rel="noopener noreferrer" className="text-cyan-300 hover:underline font-bold">
                            {aboutInfo.developerName}
                          </a>
                        ) : (
                          <strong className="text-cyan-300">{aboutInfo.developerName}</strong>
                        )}
                      </div>
                      {aboutInfo.developerPhone && (
                        <div className="text-[11px] text-slate-400 flex items-center gap-1.5 pt-0.5">
                          <Phone className="w-3 h-3 text-cyan-400" />
                          <span>Developer Contact: <a href={`tel:${aboutInfo.developerPhone}`} className="text-cyan-300 font-bold hover:underline">{aboutInfo.developerPhone}</a></span>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}

            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
