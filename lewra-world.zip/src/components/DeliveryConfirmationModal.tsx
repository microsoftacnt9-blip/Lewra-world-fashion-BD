import React, { useState } from 'react';
import { Order } from '../types';
import { X, CheckCircle2, Star, Sparkles, PackageCheck, ThumbsUp, ShieldCheck, Heart } from 'lucide-react';

interface DeliveryConfirmationModalProps {
  isOpen: boolean;
  onClose: () => void;
  order: Order | null;
  onConfirm: (orderId: string, rating: number, review: string) => void;
}

export const DeliveryConfirmationModal: React.FC<DeliveryConfirmationModalProps> = ({
  isOpen,
  onClose,
  order,
  onConfirm
}) => {
  const [rating, setRating] = useState<number>(5);
  const [hoverRating, setHoverRating] = useState<number>(0);
  const [reviewText, setReviewText] = useState<string>('পণ্যটি সঠিক সময়ে এবং অক্ষত অবস্থায় পেয়েছি। সেবার মান চমৎকার!');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  if (!isOpen || !order) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setTimeout(() => {
      onConfirm(order.id, rating, reviewText.trim());
      setIsSubmitting(false);
      setIsSuccess(true);
      setTimeout(() => {
        setIsSuccess(false);
        onClose();
      }, 1800);
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg rounded-2xl bg-[#090E1A] border border-emerald-500/40 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-emerald-950 via-slate-900 to-teal-950 border-b border-emerald-500/30 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
              <PackageCheck className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-white text-base sm:text-lg font-['Space_Grotesk']">
                পণ্য প্রাপ্তি নিশ্চিতকরণ (Mark as Received)
              </h3>
              <p className="text-xs text-emerald-300 font-mono">
                Order #{order.id} • {order.customerName}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 overflow-y-auto space-y-4">
          {isSuccess ? (
            <div className="py-10 text-center space-y-3 animate-in zoom-in-95 duration-200">
              <div className="w-16 h-16 rounded-full bg-emerald-500/20 border border-emerald-400 flex items-center justify-center mx-auto text-emerald-400">
                <CheckCircle2 className="w-10 h-10" />
              </div>
              <h4 className="text-xl font-bold text-white font-['Space_Grotesk']">
                ধন্যবাদ! ডেলিভারি নিশ্চিত হয়েছে
              </h4>
              <p className="text-xs text-slate-300 max-w-xs mx-auto">
                আপনার মতামত ও রেটিং সংরক্ষিত হয়েছে এবং অ্যাডমিন ড্যাশবোর্ডে আপডেট হয়ে গেছে।
              </p>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-300 text-xs font-mono">
                <Sparkles className="w-3.5 h-3.5" />
                <span>+50 Reward Points Added!</span>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              
              <div className="p-3.5 rounded-xl bg-emerald-950/30 border border-emerald-500/30 text-xs text-emerald-200 space-y-1">
                <div className="font-bold flex items-center gap-1.5 text-emerald-300">
                  <ShieldCheck className="w-4 h-4" />
                  <span>আপনি কি পার্সেলটি অক্ষত অবস্থায় হাতে পেয়ে বুঝে নিয়েছেন?</span>
                </div>
                <p className="text-[11px] text-slate-300">
                  কনফার্ম করার সাথে সাথে অ্যাডমিন প্যানেলে এটি ‘Verified Delivered’ হিসেবে মার্ক হবে এবং ওয়ারেন্টি সক্রিয় হবে।
                </p>
              </div>

              {/* Ordered Items Preview */}
              <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2 text-xs">
                <span className="font-mono text-slate-400 font-bold block">পণ্যসমূহ ({order.items.length}):</span>
                <div className="space-y-1">
                  {order.items.map((it, idx) => (
                    <div key={idx} className="flex justify-between text-slate-300">
                      <span>• {it.productName} (x{it.quantity})</span>
                      <span className="font-mono text-cyan-300">৳{(it.price * it.quantity).toLocaleString()}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Star Rating */}
              <div className="space-y-2 text-center py-2">
                <label className="block text-xs font-mono font-bold text-slate-300">
                  আপনার অভিজ্ঞতা রেটিং দিন (Rate Your Experience):
                </label>
                <div className="flex justify-center items-center gap-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setRating(star)}
                      onMouseEnter={() => setHoverRating(star)}
                      onMouseLeave={() => setHoverRating(0)}
                      className="p-1 text-2xl transition-transform hover:scale-125 focus:outline-none"
                    >
                      <Star
                        className={`w-8 h-8 ${
                          (hoverRating || rating) >= star
                            ? 'fill-amber-400 text-amber-400 filter drop-shadow-[0_0_8px_rgba(251,191,36,0.5)]'
                            : 'text-slate-700 hover:text-slate-500'
                        }`}
                      />
                    </button>
                  ))}
                </div>
                <span className="text-xs font-mono text-amber-400 font-bold block">
                  {rating === 5 ? '⭐⭐⭐⭐⭐ অসাধারণ / Excellent' :
                   rating === 4 ? '⭐⭐⭐⭐ খুব ভালো / Very Good' :
                   rating === 3 ? '⭐⭐⭐ মোটামুটি / Good' :
                   rating === 2 ? '⭐⭐ সন্তোষজনক নয় / Fair' : '⭐ খারাপ / Poor'}
                </span>
              </div>

              {/* Customer Feedback Note */}
              <div className="space-y-1.5">
                <label className="block text-xs font-mono font-bold text-slate-300">
                  মতামত ও রিভিউ লিখুন (Optional Feedback):
                </label>
                <textarea
                  value={reviewText}
                  onChange={(e) => setReviewText(e.target.value)}
                  rows={3}
                  placeholder="পণ্য ও সার্ভিসের কোয়ালিটি কেমন লেগেছে লিখুন..."
                  className="w-full bg-[#050811] border border-slate-700 rounded-xl p-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-400 resize-none font-sans"
                />
              </div>

              {/* Buttons */}
              <div className="pt-2 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-mono text-xs font-bold transition-all"
                >
                  বাতিল (Cancel)
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold text-xs font-mono flex items-center gap-2 transition-all shadow-lg shadow-emerald-500/20 disabled:opacity-50"
                >
                  <ThumbsUp className="w-4 h-4" />
                  <span>{isSubmitting ? 'নিশ্চিত করা হচ্ছে...' : 'হ্যাঁ, পণ্য পেয়েছি (Confirm Delivery)'}</span>
                </button>
              </div>

            </form>
          )}
        </div>

      </div>
    </div>
  );
};
