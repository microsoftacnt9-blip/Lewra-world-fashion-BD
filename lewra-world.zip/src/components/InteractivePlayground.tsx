import React, { useState } from 'react';
import { Sparkles, Terminal, Play, Copy, Check, Cpu, Code2, Layers, RefreshCw } from 'lucide-react';

export const InteractivePlayground: React.FC = () => {
  const [model, setModel] = useState<'lewra-omni' | 'lewra-flash' | 'lewra-agent'>('lewra-omni');
  const [prompt, setPrompt] = useState('Build a glassmorphic spatial HUD with real-time edge telemetry and sub-1ms quantum security.');
  const [isGenerating, setIsGenerating] = useState(false);
  const [copied, setCopied] = useState(false);
  const [outputCode, setOutputCode] = useState(`{
  "node": "LewraSpatialHUD",
  "status": "GENERATED",
  "spatialMetrics": {
    "renderLatencyMs": 0.85,
    "glassBlurPx": 24,
    "quantumLatticeActive": true
  },
  "agentCluster": [
    { "id": "agent-alpha", "task": "telemetry-stream" },
    { "id": "agent-beta", "task": "mesh-sync" }
  ]
}`);

  const samplePrompts = [
    'Build a glassmorphic spatial HUD with real-time edge telemetry and sub-1ms quantum security.',
    'Deploy 100 autonomous multi-agent workers for distributed event ingestion.',
    'Synthesize a 3D coordinate mesh with post-quantum lattice encryption.'
  ];

  const handleGenerate = () => {
    setIsGenerating(true);
    setTimeout(() => {
      setIsGenerating(false);
      setOutputCode(`{
  "node": "LewraSpatialNode_${Math.floor(Math.random() * 9000 + 1000)}",
  "timestamp": "${new Date().toISOString()}",
  "model": "${model}",
  "prompt": "${prompt}",
  "executionMetrics": {
    "latency": "${(Math.random() * 0.5 + 0.6).toFixed(2)}ms",
    "edgeLocationsSynced": 320,
    "securityStatus": "QUANTUM_SAFE"
  },
  "uiCodeSnippet": "import { LewraGlass } from '@lewra/core';\\nexport default () => <LewraGlass glow='cyan' blur={20} />;"
}`);
    }, 1000);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(outputCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <section id="playground" className="py-24 relative bg-[#070A12] border-t border-b border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-900 border border-purple-500/30 text-purple-300 text-xs font-mono font-semibold uppercase tracking-wider mb-4">
            <Sparkles className="w-3.5 h-3.5 text-purple-400" />
            INTERACTIVE AI STUDIO PLAYGROUND
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight font-['Space_Grotesk'] mb-4">
            Test Drive the <span className="text-gradient-cyan">Spatial AI Engine</span>
          </h2>
          <p className="text-slate-400 text-base sm:text-lg">
            Prompt the Lewra model live to generate spatial node configurations, multi-agent pipelines, and glassmorphic UI code.
          </p>
        </div>

        {/* Playground Card Container */}
        <div className="glass-card rounded-2xl border border-slate-700/80 max-w-5xl mx-auto overflow-hidden shadow-2xl">
          
          {/* Top Control Bar */}
          <div className="p-4 bg-[#090D18] border-b border-slate-800 flex flex-wrap items-center justify-between gap-4">
            
            {/* Model Selector */}
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono text-slate-400 uppercase">Model:</span>
              <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-xl border border-slate-800 text-xs font-medium">
                <button
                  onClick={() => setModel('lewra-omni')}
                  className={`px-3 py-1 rounded-lg transition-all ${
                    model === 'lewra-omni' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Lewra 3.0 Omni
                </button>
                <button
                  onClick={() => setModel('lewra-flash')}
                  className={`px-3 py-1 rounded-lg transition-all ${
                    model === 'lewra-flash' ? 'bg-purple-500 text-white font-bold' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Lewra Flash (0.5ms)
                </button>
                <button
                  onClick={() => setModel('lewra-agent')}
                  className={`px-3 py-1 rounded-lg transition-all ${
                    model === 'lewra-agent' ? 'bg-indigo-500 text-white font-bold' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Multi-Agent Orchestrator
                </button>
              </div>
            </div>

            <div className="text-xs font-mono text-emerald-400 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              API Server Ready
            </div>
          </div>

          {/* Prompt Input Area */}
          <div className="p-6 bg-[#070A12] space-y-4">
            
            <div>
              <label className="text-xs font-mono text-slate-400 uppercase block mb-2">
                Natural Language Spatial Prompt
              </label>
              <div className="relative">
                <textarea
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  rows={2}
                  className="w-full bg-[#0C111E] border border-slate-700/80 rounded-xl p-3.5 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-cyan-400/80 transition-colors font-mono"
                  placeholder="Describe your desired spatial AI node or agent workflow..."
                />
                <button
                  onClick={handleGenerate}
                  disabled={isGenerating}
                  className="absolute bottom-3 right-3 px-4 py-2 rounded-lg bg-gradient-to-r from-cyan-400 to-indigo-500 text-slate-950 text-xs font-bold hover:from-cyan-300 hover:to-indigo-400 transition-all flex items-center gap-1.5 shadow-lg shadow-cyan-500/20"
                >
                  {isGenerating ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <Play className="w-3.5 h-3.5 fill-current" />
                      Execute Generation
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Prompt Quick Starters */}
            <div className="flex flex-wrap items-center gap-2 pt-1">
              <span className="text-xs text-slate-500 font-mono">Try Preset:</span>
              {samplePrompts.map((p, idx) => (
                <button
                  key={idx}
                  onClick={() => setPrompt(p)}
                  className="text-xs text-slate-400 hover:text-cyan-300 bg-slate-900/80 hover:bg-slate-800 border border-slate-800 px-2.5 py-1 rounded-md transition-colors font-mono truncate max-w-xs"
                >
                  Preset #{idx + 1}
                </button>
              ))}
            </div>

            {/* Generated Code & Visual Output Split */}
            <div className="mt-6 pt-4 border-t border-slate-800/80 grid grid-cols-1 md:grid-cols-2 gap-4">
              
              {/* Code Panel */}
              <div className="bg-[#04070F] rounded-xl border border-slate-800 p-4 font-mono text-xs relative">
                <div className="flex items-center justify-between pb-2 mb-3 border-b border-slate-800 text-slate-400">
                  <span className="flex items-center gap-1.5 text-cyan-400">
                    <Code2 className="w-3.5 h-3.5" /> Output JSON / Specs
                  </span>
                  <button
                    onClick={handleCopy}
                    className="flex items-center gap-1 text-xs text-slate-400 hover:text-white px-2 py-1 rounded bg-slate-900 border border-slate-800"
                  >
                    {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    {copied ? 'Copied' : 'Copy'}
                  </button>
                </div>
                <pre className="overflow-x-auto text-slate-300 max-h-52">
                  <code>{outputCode}</code>
                </pre>
              </div>

              {/* Rendered Visual Card Preview */}
              <div className="bg-gradient-to-br from-[#090D18] to-[#12192C] rounded-xl border border-cyan-500/30 p-5 flex flex-col justify-between relative overflow-hidden">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-mono font-bold text-cyan-300 flex items-center gap-1.5">
                    <Layers className="w-3.5 h-3.5" /> Live Glass Render Preview
                  </span>
                  <span className="text-[10px] font-mono bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded border border-emerald-500/30">
                    60 FPS
                  </span>
                </div>

                <div className="p-4 rounded-xl glass-card border border-white/10 my-2 shadow-xl">
                  <p className="text-xs font-bold text-white mb-1">Lewra Spatial Component Node</p>
                  <p className="text-[11px] text-slate-300 leading-tight">
                    Active prompt: &quot;{prompt}&quot;
                  </p>
                  <div className="mt-3 flex items-center justify-between text-[10px] font-mono text-cyan-400">
                    <span>Latency: 0.88ms</span>
                    <span>State: Rendered</span>
                  </div>
                </div>

                <div className="text-[10px] font-mono text-slate-500 text-right">
                  Powered by Lewra 3.0 Engine
                </div>
              </div>

            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
