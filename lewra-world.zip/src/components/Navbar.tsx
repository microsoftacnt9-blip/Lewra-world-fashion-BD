import React, { useState, useEffect } from 'react';
import { Sparkles, Menu, X, ChevronRight, Cpu, Layers, Shield, Zap, ShoppingBag, Settings, User, LogIn, ShoppingCart, Heart, Truck, Gift } from 'lucide-react';
import { AboutInfo, UserAccount } from '../types';

interface NavbarProps {
  aboutInfo?: AboutInfo;
  currentUser?: UserAccount | null;
  onOpenGetStarted: () => void;
  onOpenKeynote: () => void;
  onOpenAdmin: () => void;
  onOpenProfile: () => void;
  ordersCount: number;
  cartItemsCount?: number;
  onOpenCart?: () => void;
  wishlistCount?: number;
  onOpenWishlist?: () => void;
  onOpenTracking?: () => void;
  onOpenLuckySpin?: () => void;
  onLogoClick?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ 
  aboutInfo, 
  currentUser, 
  onOpenGetStarted, 
  onOpenKeynote, 
  onOpenAdmin, 
  onOpenProfile, 
  ordersCount,
  cartItemsCount = 0,
  onOpenCart,
  wishlistCount = 0,
  onOpenWishlist,
  onOpenTracking,
  onOpenLuckySpin,
  onLogoClick
}) => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const websiteName = aboutInfo?.companyName || 'LEWRA WORLD';

  const isAdminUser = Boolean(
    currentUser?.email && (
      currentUser.email.toLowerCase().trim() === 'microsoftacnt9@gmail.com' ||
      currentUser.email.toLowerCase().trim().startsWith('microsoftacnt9@') ||
      currentUser.email.toLowerCase().trim() === 'admin@gmail.com'
    )
  );

  const handleLogoClick = (e: React.MouseEvent) => {
    // Notify parent / window that logo was clicked to arm secret Ctrl+A sequence
    if (onLogoClick) {
      onLogoClick();
    }
    try {
      window.dispatchEvent(new CustomEvent('lewra-logo-clicked', { detail: { timestamp: Date.now() } }));
    } catch {
      // ignore
    }
  };

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      scrolled ? 'py-3 glass-nav shadow-2xl shadow-cyan-950/20' : 'py-5 bg-transparent'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          
          {/* Logo with 3-click secret admin trigger */}
          <a
            href="#"
            onClick={handleLogoClick}
            className="flex items-center gap-3 group focus:outline-none cursor-pointer"
            title="Lewra World"
          >
            {aboutInfo?.logoUrl ? (
              <img
                src={aboutInfo.logoUrl}
                alt={websiteName}
                referrerPolicy="no-referrer"
                className="w-10 h-10 rounded-xl object-cover bg-slate-900 border border-cyan-500/40 p-0.5 shadow-lg shadow-cyan-500/20 group-hover:scale-105 transition-all duration-300"
              />
            ) : (
              <div className="relative w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 via-indigo-600 to-purple-600 p-[1px] shadow-lg shadow-cyan-500/20 group-hover:shadow-cyan-500/40 transition-all duration-300">
                <div className="w-full h-full bg-[#090D16] rounded-[11px] flex items-center justify-center relative overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/20 to-purple-500/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  <Sparkles className="w-5 h-5 text-cyan-400 group-hover:rotate-12 transition-transform duration-300" />
                </div>
              </div>
            )}
            <div className="flex flex-col">
              <span className="text-xl font-bold tracking-wider font-['Space_Grotesk'] text-white flex items-center gap-1.5 uppercase">
                {websiteName}
              </span>
            </div>
          </a>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-1 bg-zinc-900/80 border border-zinc-800 rounded-full px-4 py-1.5 backdrop-blur-md">
            <a href="#store" className="text-sm font-semibold text-zinc-300 hover:text-white px-3 py-1.5 rounded-full bg-zinc-800 border border-zinc-700 transition-all flex items-center gap-1.5">
              <ShoppingBag className="w-3.5 h-3.5 text-white" />
              Products Store
            </a>
          </nav>

          {/* CTA Buttons */}
          <div className="hidden md:flex items-center gap-2">
            {/* Spin & Win Discount Wheel Button */}
            {onOpenLuckySpin && Boolean(aboutInfo?.enableSpinWheel) && (
              <button
                onClick={onOpenLuckySpin}
                className="text-xs font-bold text-amber-300 hover:text-amber-200 px-3 py-2 rounded-xl border border-amber-500/40 bg-gradient-to-r from-amber-500/20 via-orange-500/20 to-amber-500/10 hover:border-amber-400 transition-all flex items-center gap-1.5 shadow-lg group animate-pulse"
                title="Spin & Win Discount Coupons (লাকি স্পিন হুইল)"
              >
                <Gift className="w-4 h-4 text-amber-400 group-hover:rotate-12 transition-transform" />
                <span className="hidden xl:inline">Spin & Win</span>
              </button>
            )}

            {/* Wishlist Button */}
            {onOpenWishlist && (
              <button
                onClick={onOpenWishlist}
                className="text-xs font-bold text-zinc-300 hover:text-white px-3 py-2 rounded-xl border border-zinc-800 bg-zinc-900/90 hover:bg-zinc-800 transition-all flex items-center gap-1.5 relative shadow-lg group"
                title="View Saved Wishlist"
              >
                <Heart className="w-4 h-4 text-rose-500 fill-rose-500/30 group-hover:fill-rose-500 transition-all" />
                <span className="hidden xl:inline">Wishlist</span>
                {wishlistCount > 0 && (
                  <span className="px-1.5 py-0.2 rounded-full bg-rose-500 text-white font-mono text-[10px] font-black">
                    {wishlistCount}
                  </span>
                )}
              </button>
            )}

            {/* Live Order Tracking Button */}
            {onOpenTracking && (
              <button
                onClick={onOpenTracking}
                className="text-xs font-bold text-zinc-300 hover:text-white px-3 py-2 rounded-xl border border-zinc-800 bg-zinc-900/90 hover:bg-zinc-800 transition-all flex items-center gap-1.5 shadow-lg group"
                title="Live Order Tracking"
              >
                <Truck className="w-4 h-4 text-cyan-400 group-hover:scale-110 transition-transform" />
                <span className="hidden xl:inline">Track Order</span>
              </button>
            )}

            {/* Cart Button */}
            {onOpenCart && (
              <button
                onClick={onOpenCart}
                className="text-xs font-bold text-white hover:text-zinc-200 px-3.5 py-2 rounded-xl border border-zinc-700 bg-zinc-900/90 hover:bg-zinc-800 transition-all flex items-center gap-2 relative shadow-lg group"
                title="View Shopping Cart"
              >
                <ShoppingCart className="w-4 h-4 text-white group-hover:scale-110 transition-transform" />
                <span>Cart</span>
                {cartItemsCount > 0 && (
                  <span className="px-1.5 py-0.5 rounded-full bg-white text-black font-mono text-[10px] font-black animate-pulse">
                    {cartItemsCount}
                  </span>
                )}
              </button>
            )}

            <button
              onClick={onOpenProfile}
              className="text-xs font-semibold text-zinc-300 hover:text-white px-3 py-1.5 rounded-xl border border-zinc-800 hover:border-zinc-700 bg-zinc-900/80 hover:bg-zinc-800 transition-all flex items-center gap-2 relative shadow-lg"
              title="Customer Profile & Order History"
            >
              {currentUser?.avatar ? (
                <img
                  src={currentUser.avatar}
                  alt={currentUser.name}
                  referrerPolicy="no-referrer"
                  className="w-5 h-5 rounded-full object-cover border border-zinc-600 shrink-0 shadow-sm"
                />
              ) : (
                <User className="w-3.5 h-3.5 text-zinc-400" />
              )}
              <span className="max-w-[130px] truncate">{currentUser ? currentUser.name : 'Profile'}</span>
            </button>

            {isAdminUser && !aboutInfo?.hideAdminButton && (
              <button
                onClick={onOpenAdmin}
                className="text-xs font-semibold text-zinc-300 hover:text-white px-3 py-2 rounded-xl border border-zinc-800 hover:border-zinc-700 bg-zinc-900/80 hover:bg-zinc-800 transition-all flex items-center gap-1.5 relative shadow-lg"
                title="Protected Admin Panel"
              >
                <Settings className="w-3.5 h-3.5 text-zinc-400" />
                <span>Admin</span>
                {ordersCount > 0 && (
                  <span className="px-1.5 py-0.2 rounded-full bg-white text-black font-mono text-[10px] font-black">
                    {ordersCount}
                  </span>
                )}
              </button>
            )}
            {aboutInfo?.enableKeynote && (
              <button
                onClick={onOpenKeynote}
                className="text-xs font-semibold text-zinc-300 hover:text-white px-3 py-2 rounded-xl border border-zinc-800 hover:border-zinc-700 bg-zinc-900/80 hover:bg-zinc-800 transition-all flex items-center gap-1.5"
              >
                <Zap className="w-3.5 h-3.5 text-amber-400" />
                Keynote
              </button>
            )}
            <button
              onClick={onOpenGetStarted}
              className="relative group overflow-hidden px-4 py-2 rounded-xl text-xs font-bold text-black bg-white hover:bg-zinc-200 transition-all duration-300 shadow-lg shadow-white/10 transform hover:-translate-y-0.5"
            >
              <span className="relative z-10 flex items-center gap-1">
                Get Started
                <ChevronRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
              </span>
            </button>
          </div>

          {/* Mobile Right Icons (Admin + Cart + Hamburger) */}
          <div className="md:hidden flex items-center gap-2">
            {isAdminUser && !aboutInfo?.hideAdminButton && (
              <button
                onClick={onOpenAdmin}
                className="p-2 rounded-lg bg-purple-950/40 border border-purple-500/50 text-purple-300 hover:text-purple-100 relative flex items-center justify-center shadow-lg active:scale-95 transition-all"
                aria-label="Open Admin Panel"
                title="Admin Panel (এডমিন প্যানেল)"
              >
                <Settings className="w-5 h-5 text-purple-400" />
                {ordersCount > 0 && (
                  <span className="absolute -top-1 -right-1 px-1.5 py-0.2 rounded-full bg-purple-500 text-white font-mono text-[10px] font-black animate-pulse">
                    {ordersCount}
                  </span>
                )}
              </button>
            )}

            {onOpenCart && (
              <button
                onClick={onOpenCart}
                className="p-2 rounded-lg bg-zinc-900 border border-zinc-700 text-white relative flex items-center justify-center active:scale-95 transition-all"
                aria-label="View Shopping Cart"
              >
                <ShoppingCart className="w-5 h-5 text-white" />
                {cartItemsCount > 0 && (
                  <span className="absolute -top-1 -right-1 px-1.5 py-0.2 rounded-full bg-white text-black font-mono text-[10px] font-black">
                    {cartItemsCount}
                  </span>
                )}
              </button>
            )}

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg bg-zinc-900 border border-zinc-800 text-zinc-300 hover:text-white active:scale-95 transition-all"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden glass-card mt-3 mx-4 rounded-2xl p-6 border border-slate-800 shadow-2xl animate-in slide-in-from-top duration-200">
          <div className="flex flex-col gap-3">
            <a
              href="#store"
              onClick={() => setMobileMenuOpen(false)}
              className="text-base font-bold text-cyan-300 hover:text-cyan-200 py-2 border-b border-slate-800/60 flex items-center justify-between"
            >
              <span>Products Store</span>
              <ShoppingBag className="w-4 h-4 text-cyan-400" />
            </a>

            {onOpenLuckySpin && Boolean(aboutInfo?.enableSpinWheel) && (
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenLuckySpin();
                }}
                className="w-full py-3 rounded-xl border border-amber-500/50 bg-gradient-to-r from-amber-500/20 to-orange-500/20 text-sm font-bold text-amber-300 flex items-center justify-center gap-2 shadow-lg animate-pulse"
              >
                <Gift className="w-4 h-4 text-amber-400" />
                <span>Spin & Win Discounts (লাকি স্পিন হুইল)</span>
              </button>
            )}
            
            {onOpenCart && (
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenCart();
                }}
                className="w-full py-3 rounded-xl border border-zinc-700 bg-zinc-900 text-sm font-bold text-white flex items-center justify-center gap-2 shadow-lg"
              >
                <ShoppingCart className="w-4 h-4 text-white" />
                <span>Shopping Cart {cartItemsCount > 0 ? `(${cartItemsCount})` : ''}</span>
              </button>
            )}

            {onOpenWishlist && (
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenWishlist();
                }}
                className="w-full py-3 rounded-xl border border-rose-500/40 bg-rose-950/40 text-sm font-bold text-rose-300 flex items-center justify-center gap-2 shadow-lg"
              >
                <Heart className="w-4 h-4 text-rose-500 fill-rose-500" />
                <span>Saved Wishlist {wishlistCount > 0 ? `(${wishlistCount})` : ''}</span>
              </button>
            )}

            {onOpenTracking && (
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenTracking();
                }}
                className="w-full py-3 rounded-xl border border-cyan-500/40 bg-cyan-950/40 text-sm font-bold text-cyan-300 flex items-center justify-center gap-2 shadow-lg"
              >
                <Truck className="w-4 h-4 text-cyan-400" />
                <span>Track Live Order</span>
              </button>
            )}

            <div className="pt-1 flex flex-col gap-2.5">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenProfile();
                }}
                className="w-full py-3 rounded-xl border border-emerald-500/40 bg-emerald-950/60 text-sm font-bold text-emerald-300 flex items-center justify-center gap-2"
              >
                {currentUser?.avatar ? (
                  <img
                    src={currentUser.avatar}
                    alt={currentUser.name}
                    referrerPolicy="no-referrer"
                    className="w-6 h-6 rounded-full object-cover border border-emerald-400 shrink-0"
                  />
                ) : (
                  <User className="w-4 h-4 text-emerald-400" />
                )}
                <span>{currentUser ? `Profile (${currentUser.name})` : 'Profile / Customer Login'}</span>
              </button>

              {isAdminUser && !aboutInfo?.hideAdminButton && (
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onOpenAdmin();
                  }}
                  className="w-full py-3 rounded-xl border border-purple-500/40 bg-purple-950/60 text-sm font-bold text-purple-300 flex items-center justify-center gap-2"
                >
                  <Settings className="w-4 h-4 text-purple-400" />
                  Admin Panel (Orders & Products)
                </button>
              )}
              {aboutInfo?.enableKeynote && (
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onOpenKeynote();
                  }}
                  className="w-full py-2.5 rounded-xl border border-slate-700 bg-slate-900/80 text-xs font-semibold text-slate-200 flex items-center justify-center gap-2"
                >
                  <Zap className="w-4 h-4 text-amber-400" />
                  Watch Keynote
                </button>
              )}
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenGetStarted();
                }}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-cyan-400 via-teal-300 to-indigo-400 text-slate-950 font-bold text-sm shadow-lg shadow-cyan-500/20"
              >
                Get Started
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

