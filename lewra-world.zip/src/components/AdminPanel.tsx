import React, { useState, useEffect } from 'react';
import { Product, Order, AboutInfo, Coupon, UserAccount } from '../types';
import { X, Plus, Trash2, Package, ShoppingCart, ShoppingBag, CheckCircle, Clock, Truck, AlertCircle, AlertTriangle, DollarSign, Edit3, Filter, Sparkles, User, Settings, Phone, MapPin, Mail, FileText, Video, Save, Check, Percent, ArrowUp, ArrowDown, Eye, EyeOff, Tag, Lock, Unlock, Key, ShieldCheck, LogOut, Shield, Smartphone, CreditCard, Upload, Image as ImageIcon, Users, Search, Receipt, Flame, Zap, Calendar, Timer, Palette, Gift, Star, ChevronRight, Play, Flag, Globe, BarChart3, Headphones, MessageCircle, Facebook, Instagram, Send, ExternalLink, Printer, Download, PackageCheck, ThumbsUp, HelpCircle } from 'lucide-react';
import { OrderReceiptModal } from './OrderReceiptModal';
import { AdminAnalytics } from './AdminAnalytics';
import { ShippingLabelModal } from './ShippingLabelModal';
import { isProductDiscountActive, getRemainingTime, getExpiryDateFromDays, checkCouponValidity, checkFlashSaleActive } from '../utils/discountUtils';

interface AdminPanelProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser?: UserAccount | null;
  onOpenProfile?: () => void;
  products: Product[];
  orders: Order[];
  users?: UserAccount[];
  aboutInfo: AboutInfo;
  coupons?: Coupon[];
  onAddProduct: (product: Product) => void;
  onUpdateProduct: (product: Product) => void;
  onDeleteProduct: (productId: string) => void;
  onUpdateOrderStatus: (orderId: string, status: Order['status'], confirmedAt?: string, estimatedDeliveryTime?: string) => void;
  onDeleteOrder: (orderId: string) => void;
  onUpdateOrder?: (order: Order) => void;
  onUpdateAboutInfo: (info: AboutInfo) => void;
  onUpdateCoupons?: (coupons: Coupon[]) => void;
  onDeleteUser?: (userId: string) => void;
}

export type AdminTab = 'orders' | 'products' | 'add_product' | 'coupons' | 'customers' | 'analytics' | 'support' | 'about_us' | 'security' | 'ai_assistant';

const AdminRefundForm: React.FC<{
  order: Order;
  onUpdateOrder?: (order: Order) => void;
}> = ({ order, onUpdateOrder }) => {
  const [adminSenderNum, setAdminSenderNum] = useState(order.adminRefundSenderNumber || '');
  const [refundTrxId, setRefundTrxId] = useState(order.adminRefundTrxId || '');
  const [adminMethod, setAdminMethod] = useState(order.adminRefundMethod || order.customerRefundMethod || order.paymentMethod || 'bKash');
  const [isSaved, setIsSaved] = useState(Boolean(order.adminRefundTrxId));

  const handleSaveRefund = (e: React.FormEvent) => {
    e.preventDefault();
    if (!adminSenderNum.trim() || !refundTrxId.trim() || !onUpdateOrder) return;

    const updated: Order = {
      ...order,
      adminRefundMethod: adminMethod,
      adminRefundSenderNumber: adminSenderNum.trim(),
      adminRefundTrxId: refundTrxId.trim().toUpperCase(),
      refundStatus: 'Refund Completed'
    };

    onUpdateOrder(updated);
    setIsSaved(true);
  };

  if (order.cancelledBy === 'Customer') {
    return (
      <div className="p-3 rounded-xl bg-rose-950/60 border border-rose-500/40 text-xs font-mono text-rose-300 mt-2">
        <span className="font-bold block">Customer-Initiated Cancellation:</span>
        <span className="text-[11px] text-rose-200">No refund is applicable according to store policy.</span>
      </div>
    );
  }

  return (
    <div className="p-3.5 rounded-xl bg-slate-950 border border-cyan-500/40 space-y-2 mt-2 text-xs font-mono">
      <div className="flex items-center justify-between">
        <span className="font-bold text-cyan-300 flex items-center gap-1.5">
          <DollarSign className="w-4 h-4 text-cyan-400" />
          Admin Refund Control Panel
        </span>
        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
          order.refundStatus === 'Refund Completed' || isSaved
            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
            : 'bg-amber-500/20 text-amber-300 border border-amber-500/30 animate-pulse'
        }`}>
          {order.refundStatus === 'Refund Completed' || isSaved ? 'REFUND COMPLETED' : 'REFUND PENDING'}
        </span>
      </div>

      <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 space-y-1.5 text-[11px]">
        <div className="flex items-center justify-between">
          <span className="text-slate-400">Customer Selected Method (পছন্দের মাধ্যম):</span>
          <span className="font-bold text-cyan-300 bg-cyan-950 px-2 py-0.5 rounded border border-cyan-500/30">
            {order.customerRefundMethod || 'Not selected yet'}
          </span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-slate-400">Customer Refund Target Mobile:</span>
          {order.refundRequestedNumber ? (
            <span className="font-bold text-amber-300">{order.refundRequestedNumber}</span>
          ) : (
            <span className="text-amber-400/90 italic">
              Waiting for customer (Default: {order.paymentSenderPhone || order.customerPhone || 'N/A'})
            </span>
          )}
        </div>
        <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1 border-t border-slate-800/80">
          <span>Original Payment: {order.paymentMethod || 'COD'}</span>
          <span>Original Sender: {order.paymentSenderPhone || 'N/A'}</span>
        </div>
      </div>

      {isSaved && order.adminRefundTrxId ? (
        <div className="p-2.5 rounded-lg bg-emerald-950/50 border border-emerald-500/30 text-[11px] space-y-1">
          <div className="flex justify-between">
            <span className="text-slate-400">Admin Refund Gateway Method:</span>
            <span className="font-bold text-pink-300">{order.adminRefundMethod || adminMethod}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">Admin Refund Sender Mobile:</span>
            <span className="font-bold text-cyan-300">{order.adminRefundSenderNumber || adminSenderNum}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">Refund TrxID:</span>
            <span className="font-bold text-emerald-300 uppercase">{order.adminRefundTrxId}</span>
          </div>
          <button
            type="button"
            onClick={() => setIsSaved(false)}
            className="text-[10px] text-cyan-400 hover:underline pt-1"
          >
            Edit Refund Info
          </button>
        </div>
      ) : (
        <form onSubmit={handleSaveRefund} className="space-y-2 pt-1">
          <div>
            <label className="text-[10px] text-slate-300 block mb-1">
              Select Payment Method Used by Admin for Refund *
            </label>
            <select
              value={adminMethod}
              onChange={(e) => setAdminMethod(e.target.value)}
              className="w-full bg-[#070A12] border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-pink-300 font-mono focus:outline-none focus:border-cyan-400"
            >
              {['bKash', 'Nagad', 'Rocket', 'Upay', 'CellFin', 'Bank Transfer'].map((m) => (
                <option key={m} value={m}>
                  {m}
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            <div>
              <label className="text-[10px] text-slate-300 block mb-1">
                Admin Refund Sender Mobile No *
              </label>
              <input
                type="text"
                required
                value={adminSenderNum}
                onChange={(e) => setAdminSenderNum(e.target.value)}
                placeholder="e.g. 018xxxxxxxx (Admin Number)"
                className="w-full bg-[#070A12] border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-cyan-300 font-mono focus:outline-none focus:border-cyan-400"
              />
            </div>

            <div>
              <label className="text-[10px] text-slate-300 block mb-1">
                Refund Transaction ID (TrxID) *
              </label>
              <input
                type="text"
                required
                value={refundTrxId}
                onChange={(e) => setRefundTrxId(e.target.value)}
                placeholder="e.g. TRX99887766"
                className="w-full bg-[#070A12] border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-amber-300 font-mono uppercase focus:outline-none focus:border-cyan-400"
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-2 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-extrabold text-xs flex items-center justify-center gap-1 transition-all shadow-md"
          >
            <Check className="w-3.5 h-3.5" />
            <span>Complete Refund & Add TrxID to Receipt</span>
          </button>
        </form>
      )}
    </div>
  );
};

export const AdminPanel: React.FC<AdminPanelProps> = ({
  isOpen,
  onClose,
  currentUser,
  onOpenProfile,
  products,
  orders,
  users = [],
  aboutInfo,
  coupons = [],
  onAddProduct,
  onUpdateProduct,
  onDeleteProduct,
  onUpdateOrderStatus,
  onDeleteOrder,
  onUpdateOrder,
  onUpdateAboutInfo,
  onUpdateCoupons,
  onDeleteUser
}) => {
  const [activeTab, setActiveTab] = useState<'orders' | 'products' | 'add_product' | 'coupons' | 'customers' | 'analytics' | 'support' | 'about_us' | 'security' | 'ai_assistant'>('orders');
  const [orderStatusFilter, setOrderStatusFilter] = useState<string>('All');
  const [customerSearchQuery, setCustomerSearchQuery] = useState<string>('');

  // AI Assistant State
  const [aiInput, setAiInput] = useState('');
  const [aiLogs, setAiLogs] = useState<Array<{ id: string; command: string; response: string; timestamp: string; success: boolean }>>([
    {
      id: 'log-1',
      command: 'System Initialization',
      response: '🤖 AI Store Assistant is online! আপনি বাংলায় বা ইংরেজিতে কমান্ড লিখে যেকোনো স্টোর আপডেট করতে পারেন (যেমন: কুপন তৈরি, ডেলিভারি চার্জ পরিবর্তন, নোটিশ বা পেমেন্ট নাম্বার আপডেট, নতুন প্রোডাক্ট যোগ)।',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      success: true
    }
  ]);
  const [isAiProcessing, setIsAiProcessing] = useState(false);

  // Admin authentication state
  const [adminEmail, setAdminEmail] = useState<string>(() => {
    try {
      return localStorage.getItem('lewra_admin_email') || 'microsoftacnt9@gmail.com';
    } catch (e) {
      return 'microsoftacnt9@gmail.com';
    }
  });

  const [adminPassword, setAdminPassword] = useState<string>(() => {
    try {
      return localStorage.getItem('lewra_admin_password') || 'tetra2026';
    } catch (e) {
      return 'tetra2026';
    }
  });

  const isCurrentUserAdmin = Boolean(
    currentUser?.email && (
      currentUser.email.toLowerCase() === adminEmail.toLowerCase() ||
      currentUser.email.toLowerCase() === 'microsoftacnt9@gmail.com' ||
      currentUser.email.toLowerCase() === 'admin@gmail.com'
    )
  );

  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    try {
      return localStorage.getItem('lewra_admin_authenticated') === 'true';
    } catch (e) {
      return false;
    }
  });

  // Automatically grant authentication if logged in with authorized Google account
  useEffect(() => {
    if (isCurrentUserAdmin) {
      setIsAuthenticated(true);
      try {
        localStorage.setItem('lewra_admin_authenticated', 'true');
      } catch (e) {
        console.error('Failed to set auth state', e);
      }
    }
  }, [isCurrentUserAdmin, currentUser]);

  const [emailInput, setEmailInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loginError, setLoginError] = useState('');
  const [rememberMe, setRememberMe] = useState(true);

  // Security tab state for changing email & password
  const [newEmailInput, setNewEmailInput] = useState('');
  const [currentPassInput, setCurrentPassInput] = useState('');
  const [newPassInput, setNewPassInput] = useState('');
  const [confirmPassInput, setConfirmPassInput] = useState('');
  const [securityMsg, setSecurityMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Customer management state
  const [deletingUserId, setDeletingUserId] = useState<string | null>(null);
  const [deletingOrderId, setDeletingOrderId] = useState<string | null>(null);

  // Coupon creation form state
  const [newCouponCode, setNewCouponCode] = useState('');
  const [newCouponType, setNewCouponType] = useState<'percent' | 'bdt'>('percent');
  const [newCouponValue, setNewCouponValue] = useState('');
  const [newCouponDuration, setNewCouponDuration] = useState<'always' | '3d' | '7d' | '15d' | '30d' | 'custom'>('7d');
  const [newCouponValidUntil, setNewCouponValidUntil] = useState<string>(() => getExpiryDateFromDays(7));
  const [newCouponNote, setNewCouponNote] = useState<string>('');

  // Product full edit modal state
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [editName, setEditName] = useState<string>('');
  const [editCategory, setEditCategory] = useState<string>('Spatial Hardware');
  const [editCustomCategory, setEditCustomCategory] = useState<string>('');
  const [isEditCategoryCustom, setIsEditCategoryCustom] = useState<boolean>(false);
  const [editPrice, setEditPrice] = useState<number>(0);
  const [editOriginalPrice, setEditOriginalPrice] = useState<number>(0);
  const [editDiscountPercent, setEditDiscountPercent] = useState<number>(0);
  const [editDiscountValidUntil, setEditDiscountValidUntil] = useState<string>('');
  const [editDiscountPreset, setEditDiscountPreset] = useState<'always' | '1d' | '3d' | '7d' | '15d' | '30d' | 'custom'>('always');
  const [editStock, setEditStock] = useState<number>(10);
  const [editTag, setEditTag] = useState<string>('');
  const [editImage, setEditImage] = useState<string>('');
  const [editImagesList, setEditImagesList] = useState<string[]>([]);
  const [newEditImageInput, setNewEditImageInput] = useState<string>('');
  const [editVideoUrl, setEditVideoUrl] = useState<string>('');
  const [editVideosList, setEditVideosList] = useState<string[]>([]);
  const [newEditVideoInput, setNewEditVideoInput] = useState<string>('');
  const [editDescription, setEditDescription] = useState<string>('');

  // Order confirmation & receipt & shipping label state
  const [viewingOrderReceipt, setViewingOrderReceipt] = useState<Order | null>(null);
  const [confirmingOrder, setConfirmingOrder] = useState<Order | null>(null);
  const [shippingLabelOrder, setShippingLabelOrder] = useState<Order | null>(null);
  const [selectedDeliveryTime, setSelectedDeliveryTime] = useState('Dhaka: 24-48 Hours | Outside Dhaka: 3-5 Business Days');
  const [supportSavedMessage, setSupportSavedMessage] = useState(false);

  // Form state for adding product
  const [newProductName, setNewProductName] = useState('');
  const [newProductCategory, setNewProductCategory] = useState('Spatial Hardware');
  const [customCategoryInput, setCustomCategoryInput] = useState('');
  const [isCustomCategoryMode, setIsCustomCategoryMode] = useState(false);
  const [newProductPrice, setNewProductPrice] = useState('');
  const [newProductStock, setNewProductStock] = useState('10');
  const [newProductDesc, setNewProductDesc] = useState('');
  const [newProductImage, setNewProductImage] = useState('https://images.unsplash.com/photo-1593508512255-86ab42a8e620?w=600&auto=format&fit=crop&q=80');
  const [newProductImagesList, setNewProductImagesList] = useState<string[]>([]);
  const [newExtraImageInput, setNewExtraImageInput] = useState<string>('');
  const [newProductVideoUrl, setNewProductVideoUrl] = useState('');
  const [newProductVideosList, setNewProductVideosList] = useState<string[]>([]);
  const [newExtraVideoInput, setNewExtraVideoInput] = useState<string>('');
  const [newProductTag, setNewProductTag] = useState('New Launch');

  // Form state for About Us
  const [editAbout, setEditAbout] = useState<AboutInfo>({ ...aboutInfo });
  const [aboutSavedMessage, setAboutSavedMessage] = useState(false);

  // Sync editAbout whenever aboutInfo changes or Admin opens
  useEffect(() => {
    if (aboutInfo) {
      setEditAbout({ ...aboutInfo });
    }
  }, [aboutInfo, isOpen]);

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const formattedEmail = emailInput.trim().toLowerCase();
    
    if (!formattedEmail.includes('@') || !formattedEmail.includes('.')) {
      setLoginError('অনুগ্রহ করে সঠিক জিমেইল/ইমেইল অ্যাড্রেস লিখুন!');
      return;
    }

    if (formattedEmail !== adminEmail.toLowerCase()) {
      setLoginError(`ভুল জিমেইল দেওয়া হয়েছে! সঠিক এডমিন জিমেইল লিখুন।`);
      return;
    }

    if (passwordInput.trim() !== adminPassword) {
      setLoginError('ভুল পাসওয়ার্ড! সঠিক এডমিন পাসওয়ার্ড দিন।');
      return;
    }

    setIsAuthenticated(true);
    setLoginError('');
    setEmailInput('');
    setPasswordInput('');
    if (rememberMe) {
      localStorage.setItem('lewra_admin_authenticated', 'true');
    }
  };

  const handleAdminLogout = () => {
    setIsAuthenticated(false);
    localStorage.removeItem('lewra_admin_authenticated');
    setEmailInput('');
    setPasswordInput('');
    setLoginError('');
  };

  const handleUpdatePassword = (e: React.FormEvent) => {
    e.preventDefault();
    setSecurityMsg(null);

    if (currentPassInput !== adminPassword) {
      setSecurityMsg({ type: 'error', text: 'বর্তমান পাসওয়ার্ডটি সঠিক নয়!' });
      return;
    }

    // Optional email change
    if (newEmailInput.trim()) {
      const formattedNewEmail = newEmailInput.trim().toLowerCase();
      if (!formattedNewEmail.includes('@') || !formattedNewEmail.includes('.')) {
        setSecurityMsg({ type: 'error', text: 'নতুন জিমেইল অ্যাড্রেসটি সঠিক ফরম্যাটে নয়!' });
        return;
      }
      setAdminEmail(formattedNewEmail);
      try {
        localStorage.setItem('lewra_admin_email', formattedNewEmail);
      } catch (err) {
        console.error('Failed to save email', err);
      }
    }

    // Optional password change
    if (newPassInput) {
      if (newPassInput.length < 4) {
        setSecurityMsg({ type: 'error', text: 'নতুন পাসওয়ার্ড অন্তত ৪ অক্ষরের হতে হবে!' });
        return;
      }
      if (newPassInput !== confirmPassInput) {
        setSecurityMsg({ type: 'error', text: 'নতুন পাসওয়ার্ড ২ টি মিলছে না!' });
        return;
      }
      setAdminPassword(newPassInput);
      try {
        localStorage.setItem('lewra_admin_password', newPassInput);
      } catch (err) {
        console.error('Failed to save password', err);
      }
    }

    setSecurityMsg({ type: 'success', text: 'এডমিন সিকিউরিটি তথ্য সফলভাবে আপডেট করা হয়েছে!' });
    setNewEmailInput('');
    setCurrentPassInput('');
    setNewPassInput('');
    setConfirmPassInput('');
  };

  const handleOpenEditProduct = (product: Product) => {
    setEditingProduct(product);
    setEditName(product.name);
    setEditPrice(product.price);
    setEditOriginalPrice(product.originalPrice || 0);
    setEditDiscountPercent(product.discountPercent || 0);
    setEditDiscountValidUntil(product.discountValidUntil || '');
    if (!product.discountValidUntil) {
      setEditDiscountPreset('always');
    } else {
      setEditDiscountPreset('custom');
    }
    setEditStock(product.stock ?? 10);
    setEditTag(product.tag || '');
    setEditImage(product.image || '');
    setEditImagesList(product.images ? [...product.images] : []);
    setNewEditImageInput('');
    setEditVideoUrl(product.videoUrl || '');
    setEditVideosList(product.videoUrls ? [...product.videoUrls] : []);
    setNewEditVideoInput('');
    setEditDescription(product.description || '');

    const defaultCats = ['Spatial Hardware', 'AI Hardware', 'Developer Tools', 'Security', 'Software License', 'Gadgets', 'Accessories'];
    if (defaultCats.includes(product.category)) {
      setEditCategory(product.category);
      setIsEditCategoryCustom(false);
      setEditCustomCategory('');
    } else {
      setEditCategory('CUSTOM');
      setEditCustomCategory(product.category);
      setIsEditCategoryCustom(true);
    }
  };

  const handleSaveProductEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct) return;

    // Use the exact selling price entered by admin
    const finalPrice = Math.max(1, Number(editPrice) || 0);
    const finalOriginal = Number(editOriginalPrice) || 0;
    let finalDiscount = Number(editDiscountPercent) || 0;

    if (finalOriginal > finalPrice && finalDiscount <= 0) {
      finalDiscount = Math.round(((finalOriginal - finalPrice) / finalOriginal) * 100);
    }

    const resolvedCategory = (isEditCategoryCustom || editCategory === 'CUSTOM')
      ? (editCustomCategory.trim() || 'General')
      : editCategory;

    // Filter unique valid extra images & videos
    const finalPrimaryImage = editImage.trim() || editingProduct.image;
    const finalExtraImages = editImagesList.map(img => img.trim()).filter(img => img && img !== finalPrimaryImage);
    const finalPrimaryVideo = editVideoUrl.trim() || undefined;
    const finalVideosList = Array.from(new Set([finalPrimaryVideo, ...editVideosList.map(v => v.trim())].filter(Boolean))) as string[];

    const updatedProduct: Product = {
      ...editingProduct,
      name: editName.trim() || editingProduct.name,
      category: resolvedCategory,
      price: finalPrice,
      originalPrice: finalOriginal > finalPrice ? finalOriginal : undefined,
      discountPercent: (finalOriginal > finalPrice && finalDiscount > 0) ? finalDiscount : (finalDiscount > 0 ? finalDiscount : undefined),
      discountValidUntil: finalDiscount > 0 && editDiscountPreset !== 'always' && editDiscountValidUntil ? editDiscountValidUntil : undefined,
      stock: Math.max(0, editStock),
      tag: editTag.trim() || undefined,
      image: finalPrimaryImage,
      images: finalExtraImages.length > 0 ? finalExtraImages : undefined,
      videoUrl: finalVideosList[0] || undefined,
      videoUrls: finalVideosList.length > 0 ? finalVideosList : undefined,
      description: editDescription.trim() || ''
    };

    onUpdateProduct(updatedProduct);
    setEditingProduct(null);
  };

  const handleQuickPriceChange = (product: Product, delta: number) => {
    const newPrice = Math.max(1, product.price + delta);
    const updated: Product = {
      ...product,
      price: newPrice
    };
    if (updated.originalPrice && updated.originalPrice > newPrice) {
      updated.discountPercent = Math.round(((updated.originalPrice - newPrice) / updated.originalPrice) * 100);
    }
    onUpdateProduct(updated);
  };

  const handleQuickDiscountPreset = (product: Product, percent: number, days: number) => {
    const basePrice = product.originalPrice && product.originalPrice > product.price ? product.originalPrice : product.price;
    const discountedPrice = Math.round(basePrice * (1 - percent / 100));
    const expiry = days > 0 ? getExpiryDateFromDays(days) : undefined;
    const updated: Product = {
      ...product,
      price: discountedPrice,
      originalPrice: basePrice,
      discountPercent: percent,
      discountValidUntil: expiry
    };
    onUpdateProduct(updated);
  };

  const handleClearDiscount = (product: Product) => {
    const originalPrice = product.originalPrice || product.price;
    const updated: Product = {
      ...product,
      price: originalPrice,
      originalPrice: undefined,
      discountPercent: undefined,
      discountValidUntil: undefined
    };
    onUpdateProduct(updated);
  };

  const handleQuickStockChange = (product: Product, delta: number) => {
    const newStock = Math.max(0, (product.stock || 0) + delta);
    onUpdateProduct({
      ...product,
      stock: newStock
    });
  };

  const handleSetStockDirect = (product: Product, targetStock: number) => {
    onUpdateProduct({
      ...product,
      stock: Math.max(0, targetStock)
    });
  };

  const handleConfirmOrderWithDetails = (order: Order) => {
    const confirmTime = new Date().toLocaleString();
    onUpdateOrderStatus(order.id, 'Processing', confirmTime, selectedDeliveryTime);
    setConfirmingOrder(null);
  };

  if (!isOpen) return null;

  // Render Admin Login Modal if not authenticated
  if (!isAuthenticated) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md animate-in fade-in duration-200">
        <div className="glass-card max-w-md w-full rounded-2xl border border-purple-500/30 p-6 sm:p-8 relative shadow-2xl text-white bg-slate-900/95 overflow-hidden">
          {/* Subtle Ambient Glow */}
          <div className="absolute -top-24 -left-24 w-48 h-48 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -bottom-24 -right-24 w-48 h-48 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

          {/* Close Button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Lock Icon Badge */}
          <div className="flex flex-col items-center text-center mb-6">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-purple-500/20 via-cyan-500/20 to-indigo-500/20 border border-purple-500/40 flex items-center justify-center mb-3 shadow-lg shadow-purple-500/20">
              <ShieldCheck className="w-7 h-7 text-purple-400 animate-pulse" />
            </div>
            <h2 className="text-xl sm:text-2xl font-bold font-['Space_Grotesk'] text-white">
              Admin Security Access
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              এডমিন প্যানেলে প্রবেশের জন্য আপনার অনুমোদিত জিমেইল অ্যাকাউন্ট বা পাসওয়ার্ড দিয়ে প্রবেশ করুন
            </p>
          </div>

          {/* Current User Google Account Status Card */}
          {currentUser ? (
            <div className={`p-4 rounded-xl border mb-5 transition-all ${
              isCurrentUserAdmin
                ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-200'
                : 'bg-amber-950/30 border-amber-500/40 text-amber-200'
            }`}>
              <div className="flex items-center gap-3">
                {currentUser.avatar ? (
                  <img src={currentUser.avatar} alt={currentUser.name} referrerPolicy="no-referrer" className="w-10 h-10 rounded-full object-cover border border-emerald-400 shrink-0" />
                ) : (
                  <div className="w-10 h-10 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center font-bold text-white shrink-0">
                    <User className="w-5 h-5" />
                  </div>
                )}
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold text-xs truncate text-white">{currentUser.name}</span>
                    {isCurrentUserAdmin && (
                      <span className="px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-mono text-[9px] font-bold border border-emerald-500/30">
                        Admin Verified
                      </span>
                    )}
                  </div>
                  <div className="text-[11px] text-slate-300 font-mono truncate">{currentUser.email}</div>
                </div>
              </div>

              {isCurrentUserAdmin ? (
                <div className="mt-3 pt-3 border-t border-emerald-500/30">
                  <button
                    type="button"
                    onClick={() => {
                      setIsAuthenticated(true);
                      localStorage.setItem('lewra_admin_authenticated', 'true');
                    }}
                    className="w-full py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-slate-950 font-extrabold text-xs font-mono flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20"
                  >
                    <Unlock className="w-4 h-4" />
                    লগইন সম্পন্ন: সরাসরি এডমিন প্যানেলে প্রবেশ করুন
                  </button>
                </div>
              ) : (
                <div className="mt-2 text-[11px] text-amber-300/90 font-mono leading-tight">
                  ⚠️ এই জিমেইল অ্যাকাউন্টে এডমিন অ্যাক্সেস নেই। এডমিন অ্যাকাউন্টে (<span className="text-cyan-300 font-bold">{adminEmail}</span>) লগইন করুন।
                </div>
              )}
            </div>
          ) : (
            <div className="p-3.5 rounded-xl bg-slate-950 border border-purple-500/30 mb-5 flex items-center justify-between gap-3 text-xs font-mono">
              <div>
                <span className="text-slate-300 font-bold block">Google Account Login</span>
                <span className="text-[11px] text-slate-400">আপনার এডমিন জিমেইলে লগইন থাকলে পাসওয়ার্ড ছাড়াই সরাসরি প্রবেশ করতে পারবেন</span>
              </div>
              {onOpenProfile && (
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenProfile();
                  }}
                  className="px-3 py-1.5 rounded-lg bg-purple-500/20 hover:bg-purple-500/30 text-purple-300 border border-purple-500/40 text-xs font-bold shrink-0 transition-colors"
                >
                  লগইন করুন
                </button>
              )}
            </div>
          )}

          {/* Login Form */}
          <form onSubmit={handleAdminLogin} className="space-y-4">
            <div>
              <label className="text-xs font-mono text-slate-300 block mb-1.5 flex items-center justify-between">
                <span>Admin Gmail (এডমিন জিমেইল) *</span>
                <span className="text-[10px] text-cyan-400 font-normal">Gmail Verified</span>
              </label>

              <div className="relative">
                <input
                  type="email"
                  required
                  value={emailInput}
                  onChange={(e) => {
                    setEmailInput(e.target.value);
                    if (loginError) setLoginError('');
                  }}
                  placeholder="e.g. admin@gmail.com"
                  className="w-full bg-[#070A12] border border-slate-700 focus:border-purple-400 rounded-xl pl-10 pr-3.5 py-2.5 text-sm text-white font-mono focus:outline-none transition-colors"
                />
                <Mail className="w-4 h-4 text-purple-400 absolute left-3 top-1/2 -translate-y-1/2" />
              </div>
            </div>

            <div>
              <label className="text-xs font-mono text-slate-300 block mb-1.5 flex items-center justify-between">
                <span>Admin Password (এডমিন পাসওয়ার্ড) *</span>
                <span className="text-[10px] text-cyan-400 font-normal">Protected Area</span>
              </label>

              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={passwordInput}
                  onChange={(e) => {
                    setPasswordInput(e.target.value);
                    if (loginError) setLoginError('');
                  }}
                  placeholder="Enter admin password..."
                  className="w-full bg-[#070A12] border border-slate-700 focus:border-purple-400 rounded-xl pl-10 pr-10 py-2.5 text-sm text-white font-mono focus:outline-none transition-colors"
                />
                <Lock className="w-4 h-4 text-purple-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white p-1"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Error Message Alert */}
            {loginError && (
              <div className="p-3 rounded-xl bg-rose-500/15 border border-rose-500/40 text-rose-300 text-xs font-mono flex items-center gap-2 animate-in fade-in">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>{loginError}</span>
              </div>
            )}



            {/* Remember Me Checkbox */}
            <div className="flex items-center justify-between text-xs text-slate-400 pt-1">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="rounded bg-slate-900 border-slate-700 text-purple-500 focus:ring-purple-400"
                />
                <span>Remember session on this device</span>
              </label>
            </div>

            {/* Submit Login Button */}
            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-gradient-to-r from-purple-500 via-indigo-500 to-cyan-500 hover:from-purple-400 hover:to-cyan-400 text-white font-bold text-xs font-mono uppercase tracking-wider flex items-center justify-center gap-2 transition-all shadow-lg shadow-purple-500/25"
            >
              <Lock className="w-4 h-4" />
              Access Admin Panel (লগইন করুন)
            </button>
          </form>
        </div>
      </div>
    );
  }

  const handleAddProductSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProductName || !newProductPrice) return;

    const finalCategory = (isCustomCategoryMode || newProductCategory === 'CUSTOM')
      ? (customCategoryInput.trim() || 'General')
      : newProductCategory;

    const finalPrimaryImage = newProductImage || 'https://images.unsplash.com/photo-1593508512255-86ab42a8e620?w=600&auto=format&fit=crop&q=80';
    const finalExtraImages = newProductImagesList.map(img => img.trim()).filter(img => img && img !== finalPrimaryImage);
    const finalPrimaryVideo = newProductVideoUrl.trim() || undefined;
    const finalVideosList = Array.from(new Set([finalPrimaryVideo, ...newProductVideosList.map(v => v.trim())].filter(Boolean))) as string[];

    const product: Product = {
      id: `prod-${Date.now()}`,
      name: newProductName,
      category: finalCategory,
      price: parseFloat(newProductPrice) || 0,
      stock: parseInt(newProductStock) || 0,
      description: newProductDesc,
      image: finalPrimaryImage,
      images: finalExtraImages.length > 0 ? finalExtraImages : undefined,
      videoUrl: finalVideosList[0] || undefined,
      videoUrls: finalVideosList.length > 0 ? finalVideosList : undefined,
      tag: newProductTag,
      featured: true
    };

    onAddProduct(product);
    
    // Reset form
    setNewProductName('');
    setNewProductPrice('');
    setNewProductDesc('');
    setNewProductImage('https://images.unsplash.com/photo-1593508512255-86ab42a8e620?w=600&auto=format&fit=crop&q=80');
    setNewProductImagesList([]);
    setNewExtraImageInput('');
    setNewProductVideoUrl('');
    setNewProductVideosList([]);
    setNewExtraVideoInput('');
    setCustomCategoryInput('');
    setIsCustomCategoryMode(false);
    setActiveTab('products');
  };

  const handleSaveAboutUsSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateAboutInfo(editAbout);
    setAboutSavedMessage(true);
    setTimeout(() => setAboutSavedMessage(false), 3000);
  };

  const handleAddCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCouponCode.trim() || !newCouponValue || !onUpdateCoupons) return;
    const val = parseFloat(newCouponValue) || 0;
    const newC: Coupon = {
      id: `c-${Date.now()}`,
      code: newCouponCode.trim().toUpperCase(),
      active: true,
      ...(newCouponType === 'percent' ? { discountPercent: val } : { discountBDT: val }),
      validUntil: newCouponDuration !== 'always' && newCouponValidUntil ? newCouponValidUntil : undefined,
      note: newCouponNote.trim() || undefined
    };
    onUpdateCoupons([newC, ...coupons]);
    setNewCouponCode('');
    setNewCouponValue('');
    setNewCouponNote('');
  };

  const handleToggleCoupon = (couponId: string) => {
    if (!onUpdateCoupons) return;
    onUpdateCoupons(coupons.map(c => c.id === couponId ? { ...c, active: !c.active } : c));
  };

  const handleDeleteCoupon = (couponId: string) => {
    if (!onUpdateCoupons) return;
    onUpdateCoupons(coupons.filter(c => c.id !== couponId));
  };

  const handleExecuteAiCommand = async (customCmd?: string) => {
    const rawCmd = (customCmd || aiInput).trim();
    if (!rawCmd) return;

    setIsAiProcessing(true);
    const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const lower = rawCmd.toLowerCase();
    let responseText = '';
    let isSuccess = true;

    await new Promise(r => setTimeout(r, 500));

    // 1. Coupon commands: "coupon", "কুপন", "discount", "ছাড়"
    if (lower.includes('coupon') || lower.includes('কুপন') || lower.includes('discount') || lower.includes('ছাড়')) {
      const numbers = rawCmd.match(/\d+/g);
      const val = numbers ? parseInt(numbers[0]) : 10;
      const codeMatch = rawCmd.match(/[A-Za-z0-9_]{3,15}/g);
      const codeCandidate = codeMatch?.find(c => c.toUpperCase() !== 'COUPON' && c.toUpperCase() !== 'OFF' && c.toUpperCase() !== 'DISCOUNT' && !/^\d+$/.test(c)) || `OFFER${val}`;
      const code = codeCandidate.toUpperCase();

      if (onUpdateCoupons) {
        const isPercent = val <= 100;
        const newC: Coupon = {
          id: `c-${Date.now()}`,
          code,
          active: true,
          ...(isPercent ? { discountPercent: val } : { discountBDT: val })
        };
        onUpdateCoupons([newC, ...coupons]);
        responseText = `🎉 AI Success: New Coupon "${code}" generated with ${isPercent ? val + '%' : '৳' + val + ' BDT'} discount! (কুপনটি আপনার স্টোরে সক্রিয় করা হয়েছে)`;
      } else {
        responseText = `⚠️ Coupons manager is not connected.`;
        isSuccess = false;
      }
    }
    // 2. Delivery Charge commands: "delivery", "ডেলিভারি", "dhaka", "ঢাকা", "charge"
    else if (lower.includes('delivery') || lower.includes('ডেলিভারি') || lower.includes('চার্জ')) {
      const numbers = rawCmd.match(/\d+/g);
      if (numbers && numbers.length >= 1) {
        const inside = parseInt(numbers[0]);
        const outside = numbers.length >= 2 ? parseInt(numbers[1]) : inside * 2;
        const updated: AboutInfo = {
          ...aboutInfo,
          deliveryChargeInsideDhaka: inside,
          deliveryChargeOutsideDhaka: outside
        };
        onUpdateAboutInfo(updated);
        responseText = `🚚 AI Success: Delivery charges updated! Inside Dhaka: ৳${inside} BDT, Outside Dhaka: ৳${outside} BDT.`;
      } else {
        responseText = `⚠️ Please mention charges e.g., "Set delivery charge inside dhaka 70 BDT and outside 130 BDT"`;
        isSuccess = false;
      }
    }
    // 3. Notice / Announcement commands: "notice", "নোটিশ", "header", "ঘোষণা", "title"
    else if (lower.includes('store title') || lower.includes('store subtitle') || lower.includes('দোকান শিরোনাম') || lower.includes('স্টোর শিরোনাম') || lower.includes('স্টোর টাইটেল')) {
      const updated: AboutInfo = {
        ...aboutInfo,
        storeTitle: rawCmd.replace(/store title|স্টোর শিরোনাম|স্টোর টাইটেল|দোকান শিরোনাম/gi, '').trim() || aboutInfo.storeTitle
      };
      onUpdateAboutInfo(updated);
      responseText = `🛒 AI Success: Product Store section title updated!`;
    }
    else if (lower.includes('notice') || lower.includes('নোটিশ') || lower.includes('ঘোষণা') || lower.includes('header')) {
      const noticeText = rawCmd.replace(/set notice|set header|নোটিশ|ঘোষণা|দাও|করো/gi, '').trim() || rawCmd;
      const updated: AboutInfo = {
        ...aboutInfo,
        siteNotice: noticeText,
        headerTitle: noticeText
      };
      onUpdateAboutInfo(updated);
      responseText = `📢 AI Success: Homepage banner & notice updated to: "${noticeText}"`;
    }
    // 4. Payment Number / Instructions: "bkash", "বিকাশ", "nagad", "নগদ", "phone", "নম্বর", "পেমেন্ট"
    else if (lower.includes('bkash') || lower.includes('বিকাশ') || lower.includes('nagad') || lower.includes('নগদ') || lower.includes('payment') || lower.includes('পেমেন্ট')) {
      const numbers = rawCmd.match(/01[3-9]\d{8}/g);
      if (numbers && numbers.length > 0) {
        const phoneList = numbers.join(', ');
        const updated: AboutInfo = {
          ...aboutInfo,
          paymentInstructions: `Send Money to Admin bKash/Nagad Number: ${phoneList}`
        };
        onUpdateAboutInfo(updated);
        responseText = `💳 AI Success: Payment gateway numbers updated to ${phoneList}!`;
      } else {
        const updated: AboutInfo = {
          ...aboutInfo,
          paymentInstructions: rawCmd
        };
        onUpdateAboutInfo(updated);
        responseText = `💳 AI Success: Payment instructions updated to: "${rawCmd}"`;
      }
    }
    // 5. Add Product: "product", "পণ্য", "প্রোডাক্ট", "add", "যোগ"
    else if (lower.includes('product') || lower.includes('পণ্য') || lower.includes('প্রোডাক্ট') || lower.includes('add') || lower.includes('যোগ')) {
      const numbers = rawCmd.match(/\d+/g);
      const priceVal = numbers ? parseInt(numbers[0]) : 990;
      const cleanedTitle = rawCmd.replace(/add product|new product|পণ্য যোগ করো|প্রোডাক্ট/gi, '').trim() || 'AI Custom Item';
      const prodName = cleanedTitle.length > 2 ? cleanedTitle : 'Premium Tech Item';
      const newProd: Product = {
        id: `prod-${Date.now()}`,
        name: prodName,
        category: lower.includes('phone') ? 'AI Hardware' : 'Gadgets',
        price: priceVal,
        stock: 20,
        description: `High quality ${prodName} featuring premium design, verified authenticity, official warranty, and fast home delivery across Bangladesh.`,
        image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600&auto=format&fit=crop&q=80',
        featured: true
      };
      onAddProduct(newProd);
      responseText = `📦 AI Success: Product "${newProd.name}" added successfully with price ৳${priceVal} BDT!`;
    }
    // 6. Lewra Workspace & Ecosystem Showcase Commands: "workspace", "showcase", "ওয়ার্কস্পেস", "শোকেস", "system active", "ইকোসিস্টেম"
    else if (lower.includes('workspace') || lower.includes('showcase') || lower.includes('ওয়ার্কস্পেস') || lower.includes('শোকেস') || lower.includes('ecosystem') || lower.includes('ইকোসিস্টেম')) {
      if (lower.includes('hide') || lower.includes('remove') || lower.includes('লুকা') || lower.includes('বন্ধ') || lower.includes('ডিলিট') || lower.includes('মুছে')) {
        const updated: AboutInfo = { ...aboutInfo, hideHeroShowcase: true };
        onUpdateAboutInfo(updated);
        responseText = `🖥️ AI Success: "Lewra World Workspace & Ecosystem Showcase" হোমপেজ থেকে সম্পূর্ণ রিমুভ / লুকানো হয়েছে!`;
      } else if (lower.includes('show') || lower.includes('add') || lower.includes('দেখা') || lower.includes('চালু') || lower.includes('যুক্ত')) {
        const updated: AboutInfo = { ...aboutInfo, hideHeroShowcase: false };
        onUpdateAboutInfo(updated);
        responseText = `🖥️ AI Success: "Lewra World Workspace & Ecosystem Showcase" হোমপেজে পুনরায় সক্রিয় / যুক্ত করা হয়েছে!`;
      } else {
        const updated: AboutInfo = {
          ...aboutInfo,
          heroWorkspaceTitle: rawCmd.includes('title') ? rawCmd.split('title')[1].trim() : aboutInfo.heroWorkspaceTitle
        };
        onUpdateAboutInfo(updated);
        responseText = `🖥️ AI Success: Workspace settings updated: "${rawCmd}"`;
      }
    }
    // 7. Hide / Show Admin Button
    else if (lower.includes('hide admin') || lower.includes('লুকান') || lower.includes('গোপন')) {
      const updated: AboutInfo = { ...aboutInfo, hideAdminButton: true };
      onUpdateAboutInfo(updated);
      responseText = `🔒 AI Success: Public Admin Panel button hidden! Access via ?admin=true or footer link.`;
    } else if (lower.includes('show admin') || lower.includes('দেখান')) {
      const updated: AboutInfo = { ...aboutInfo, hideAdminButton: false };
      onUpdateAboutInfo(updated);
      responseText = `🔓 AI Success: Public Admin Panel button is now visible on website header!`;
    }
    // General AI acknowledgment
    else {
      responseText = `🤖 AI Processed Command: "${rawCmd}". AI has reviewed store configuration. (টিপস: আপনি কমান্ড দিতে পারেন যেমন: "কুপন তৈরি করো EID20", "ডেলিভারি চার্জ ৮০ টাকা করো", "নোটিশ সেট করো ফ্রি ডেলিভারি")`;
    }

    setAiLogs(prev => [
      {
        id: `log-${Date.now()}`,
        command: rawCmd,
        response: responseText,
        timestamp: timeStr,
        success: isSuccess
      },
      ...prev
    ]);

    setAiInput('');
    setIsAiProcessing(false);
  };

  const handleExportOrdersCSV = () => {
    if (!orders || orders.length === 0) {
      alert('কোনো অর্ডার রিপোর্ট ডাউনলোড করার মতো ডাটা নেই!');
      return;
    }
    const headers = ['Order ID', 'Date', 'Customer Name', 'Phone', 'Email', 'Address', 'Items Ordered', 'Total Amount (BDT)', 'Advance Paid', 'Due Amount', 'Payment Method', 'Status', 'Customer Verified Received', 'Rating (1-5)', 'Customer Feedback/Review'];
    const rows = orders.map(o => {
      const adv = o.advancePaid !== undefined ? o.advancePaid : (o.paymentMethod === 'Cash on Delivery' ? 0 : o.totalAmount);
      const due = o.dueAmount !== undefined ? o.dueAmount : Math.max(0, o.totalAmount - adv);
      const itemsList = o.items.map(i => `${i.productName} [Qty: ${i.quantity}, Price: ৳${i.price}]`).join(' | ');
      return [
        `"${o.id}"`,
        `"${new Date(o.createdAt).toLocaleString()}"`,
        `"${(o.customerName || '').replace(/"/g, '""')}"`,
        `"${(o.customerPhone || '').replace(/"/g, '""')}"`,
        `"${(o.customerEmail || '').replace(/"/g, '""')}"`,
        `"${(o.shippingAddress || '').replace(/"/g, '""')}"`,
        `"${itemsList.replace(/"/g, '""')}"`,
        o.totalAmount,
        adv,
        due,
        `"${o.paymentMethod}"`,
        `"${o.status}"`,
        o.customerReceived ? '"YES (Verified)"' : '"Pending Delivery"',
        o.customerRating || '""',
        `"${(o.customerReview || '').replace(/"/g, '""')}"`
      ];
    });

    const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `orders_report_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const totalRevenue = orders
    .filter(o => o.status === 'Completed' || o.customerReceived)
    .reduce((sum, o) => sum + o.totalAmount, 0);

  const pendingCount = orders.filter(o => o.status === 'Pending').length;

  const filteredOrders = orders.filter(o => {
    if (orderStatusFilter === 'All') return true;
    if (orderStatusFilter === 'Received') return o.customerReceived;
    return o.status === orderStatusFilter;
  });

  const statusColors: Record<Order['status'], string> = {
    Pending: 'bg-amber-500/20 text-amber-300 border-amber-500/40',
    Processing: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40',
    Shipped: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/40',
    Completed: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40',
    Cancelled: 'bg-rose-500/20 text-rose-300 border-rose-500/40'
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-0 sm:p-4 bg-slate-950/90 backdrop-blur-md animate-in fade-in duration-200">
      <div className="glass-card border-0 sm:border border-slate-700 max-w-5xl w-full h-[100dvh] sm:h-[90vh] rounded-none sm:rounded-2xl flex flex-col overflow-hidden shadow-2xl relative">
        
        {/* Header */}
        <div className="p-3.5 sm:p-6 bg-slate-900/95 border-b border-slate-800 flex flex-row items-center justify-between gap-2 shrink-0">
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-cyan-400 shrink-0" />
              <h2 className="text-base sm:text-2xl font-bold text-white font-['Space_Grotesk'] truncate">
                Admin Dashboard
              </h2>
              <span className="hidden sm:inline-block px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 text-[10px] font-mono font-bold">
                Mobile & Web Master
              </span>
            </div>
            <p className="text-[11px] text-slate-400 truncate mt-0.5">
              পণ্য ও কাস্টমার অর্ডার কন্ট্রোল প্যানেল
            </p>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={handleAdminLogout}
              className="px-2.5 py-1.5 sm:px-3 sm:py-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 text-[11px] sm:text-xs font-mono font-bold flex items-center gap-1 transition-all"
              title="Lock & Logout Admin Panel"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Logout</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 sm:p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors"
              title="Close Admin Panel"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Top Summary Metrics */}
        <div className="grid grid-cols-3 gap-1.5 sm:gap-4 p-2.5 sm:p-4 bg-[#090D18] border-b border-slate-800 text-xs font-mono shrink-0">
          <div className="p-2 sm:p-3 rounded-xl bg-slate-900/80 border border-slate-800">
            <span className="text-slate-400 block text-[9px] sm:text-[10px] truncate">TOTAL REVENUE</span>
            <span className="text-sm sm:text-lg font-bold text-emerald-400">৳{totalRevenue.toLocaleString()}</span>
          </div>
          <div className="p-2 sm:p-3 rounded-xl bg-slate-900/80 border border-slate-800">
            <span className="text-slate-400 block text-[9px] sm:text-[10px] truncate">ORDERS</span>
            <span className="text-sm sm:text-lg font-bold text-cyan-400">{orders.length}</span>
          </div>
          <div className="p-2 sm:p-3 rounded-xl bg-slate-900/80 border border-slate-800">
            <span className="text-slate-400 block text-[9px] sm:text-[10px] truncate">PENDING</span>
            <span className="text-sm sm:text-lg font-bold text-amber-400">{pendingCount}</span>
          </div>
        </div>

        {/* Mobile Quick Dropdown Tab Selector (Visible on small screens) */}
        <div className="md:hidden bg-slate-950 p-2.5 border-b border-slate-800 flex items-center gap-2 shrink-0">
          <span className="text-xs font-mono text-cyan-400 shrink-0 font-bold">সেকশন:</span>
          <select
            value={activeTab}
            onChange={(e) => {
              const val = e.target.value as AdminTab;
              if (val === 'support' || val === 'about_us') {
                setEditAbout({ ...aboutInfo });
              }
              if (val === 'security') {
                setSecurityMsg(null);
              }
              setActiveTab(val);
            }}
            className="w-full bg-[#0E1526] border border-cyan-500/40 text-cyan-200 text-xs font-bold font-mono rounded-xl px-3 py-2 focus:outline-none focus:border-cyan-400 cursor-pointer"
          >
            <option value="orders">📦 Customer Orders ({orders.length})</option>
            <option value="products">🏷️ Products Catalog ({products.length})</option>
            <option value="add_product">➕ Add New Product (নতুন পণ্য)</option>
            <option value="coupons">🎟️ Coupons & Discounts ({coupons.length})</option>
            <option value="customers">👥 Registered Customers ({users.length})</option>
            <option value="analytics">📊 Analytics & Reports</option>
            <option value="support">🎧 Support & Social Links</option>
            <option value="about_us">⚙️ Website & Store Settings</option>
            <option value="security">🔒 Security & Password</option>
            <option value="ai_assistant">🤖 AI Store Assistant</option>
          </select>
        </div>

        {/* Tab Navigation for Desktop / Tablet */}
        <div className="hidden md:flex border-b border-slate-800 bg-slate-950 px-4 pt-2 gap-2 text-xs font-medium overflow-x-auto shrink-0">
          <button
            onClick={() => setActiveTab('orders')}
            className={`px-4 py-3 rounded-t-xl flex items-center gap-2 border-t border-x transition-all shrink-0 ${
              activeTab === 'orders'
                ? 'bg-[#0E1526] text-cyan-300 border-cyan-500/50 font-bold'
                : 'bg-transparent text-slate-400 border-transparent hover:text-slate-200'
            }`}
          >
            <ShoppingCart className="w-4 h-4" />
            Customer Orders ({orders.length})
          </button>

          <button
            onClick={() => setActiveTab('products')}
            className={`px-4 py-3 rounded-t-xl flex items-center gap-2 border-t border-x transition-all shrink-0 ${
              activeTab === 'products'
                ? 'bg-[#0E1526] text-cyan-300 border-cyan-500/50 font-bold'
                : 'bg-transparent text-slate-400 border-transparent hover:text-slate-200'
            }`}
          >
            <Package className="w-4 h-4" />
            Products Catalog ({products.length})
          </button>

          <button
            onClick={() => setActiveTab('add_product')}
            className={`px-4 py-3 rounded-t-xl flex items-center gap-2 border-t border-x transition-all shrink-0 ${
              activeTab === 'add_product'
                ? 'bg-[#0E1526] text-cyan-300 border-cyan-500/50 font-bold'
                : 'bg-transparent text-slate-400 border-transparent hover:text-slate-200'
            }`}
          >
            <Plus className="w-4 h-4 text-emerald-400" />
            Add Product (নতুন পণ্য)
          </button>

          <button
            onClick={() => setActiveTab('coupons')}
            className={`px-4 py-3 rounded-t-xl flex items-center gap-2 border-t border-x transition-all shrink-0 ${
              activeTab === 'coupons'
                ? 'bg-[#0E1526] text-cyan-300 border-cyan-500/50 font-bold'
                : 'bg-transparent text-slate-400 border-transparent hover:text-slate-200'
            }`}
          >
            <Tag className="w-4 h-4 text-amber-400" />
            Coupons & Discounts ({coupons.length})
          </button>

          <button
            onClick={() => setActiveTab('customers')}
            className={`px-4 py-3 rounded-t-xl flex items-center gap-2 border-t border-x transition-all shrink-0 ${
              activeTab === 'customers'
                ? 'bg-[#0E1526] text-emerald-300 border-emerald-500/50 font-bold'
                : 'bg-transparent text-slate-400 border-transparent hover:text-slate-200'
            }`}
          >
            <Users className="w-4 h-4 text-emerald-400" />
            Registered Customers ({users.length})
          </button>

          <button
            onClick={() => setActiveTab('analytics')}
            className={`px-4 py-3 rounded-t-xl flex items-center gap-2 border-t border-x transition-all shrink-0 ${
              activeTab === 'analytics'
                ? 'bg-[#0E1526] text-cyan-300 border-cyan-500/50 font-bold shadow-lg shadow-cyan-500/10'
                : 'bg-transparent text-slate-400 border-transparent hover:text-slate-200'
            }`}
          >
            <BarChart3 className="w-4 h-4 text-cyan-400" />
            Analytics & Reports (অ্যানালিটিক্স)
          </button>

          <button
            onClick={() => {
              setEditAbout({ ...aboutInfo });
              setActiveTab('support');
            }}
            className={`px-4 py-3 rounded-t-xl flex items-center gap-2 border-t border-x transition-all shrink-0 ${
              activeTab === 'support'
                ? 'bg-[#0E1526] text-emerald-300 border-emerald-500/50 font-bold shadow-lg shadow-emerald-500/10'
                : 'bg-transparent text-slate-400 border-transparent hover:text-slate-200'
            }`}
          >
            <Headphones className="w-4 h-4 text-emerald-400" />
            <span>Support & Links</span>
          </button>

          <button
            onClick={() => {
              setEditAbout({ ...aboutInfo });
              setActiveTab('about_us');
            }}
            className={`px-4 py-3 rounded-t-xl flex items-center gap-2 border-t border-x transition-all shrink-0 ${
              activeTab === 'about_us'
                ? 'bg-[#0E1526] text-cyan-300 border-cyan-500/50 font-bold'
                : 'bg-transparent text-slate-400 border-transparent hover:text-slate-200'
            }`}
          >
            <Settings className="w-4 h-4 text-cyan-400" />
            Settings
          </button>

          <button
            onClick={() => {
              setActiveTab('security');
              setSecurityMsg(null);
            }}
            className={`px-4 py-3 rounded-t-xl flex items-center gap-2 border-t border-x transition-all shrink-0 ${
              activeTab === 'security'
                ? 'bg-[#0E1526] text-purple-300 border-purple-500/50 font-bold'
                : 'bg-transparent text-slate-400 border-transparent hover:text-slate-200'
            }`}
          >
            <Key className="w-4 h-4 text-purple-400" />
            Security
          </button>

          <button
            onClick={() => setActiveTab('ai_assistant')}
            className={`px-4 py-3 rounded-t-xl flex items-center gap-2 border-t border-x transition-all shrink-0 ${
              activeTab === 'ai_assistant'
                ? 'bg-[#0E1526] text-amber-300 border-amber-500/50 font-bold shadow-lg shadow-amber-500/10'
                : 'bg-transparent text-amber-300/80 hover:text-amber-200 border-transparent'
            }`}
          >
            <Sparkles className="w-4 h-4 text-amber-400 animate-pulse" />
            <span>AI Command</span>
          </button>
        </div>

        {/* Tab Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-[#0B0F1D]">

          {/* TAB 1: ORDERS LIST */}
          {activeTab === 'orders' && (
            <div className="space-y-4">
              
              {/* Order Status Filters & CSV Export */}
              <div className="flex flex-wrap items-center justify-between gap-3 pb-2">
                <div className="flex items-center gap-1.5 overflow-x-auto pb-1 max-w-full">
                  <span className="text-xs font-mono text-slate-400 flex items-center gap-1 shrink-0">
                    <Filter className="w-3.5 h-3.5" /> Filter:
                  </span>
                  {[
                    { key: 'All', label: `All (${orders.length})` },
                    { key: 'Pending', label: `Pending (${orders.filter(o => o.status === 'Pending').length})` },
                    { key: 'Processing', label: `Processing (${orders.filter(o => o.status === 'Processing').length})` },
                    { key: 'Shipped', label: `Shipped (${orders.filter(o => o.status === 'Shipped').length})` },
                    { key: 'Completed', label: `Completed (${orders.filter(o => o.status === 'Completed').length})` },
                    { key: 'Received', label: `✅ Received (${orders.filter(o => o.customerReceived).length})` },
                    { key: 'Cancelled', label: `Cancelled (${orders.filter(o => o.status === 'Cancelled').length})` }
                  ].map(st => (
                    <button
                      key={st.key}
                      onClick={() => setOrderStatusFilter(st.key)}
                      className={`px-3 py-1 rounded-lg text-xs font-mono transition-all shrink-0 ${
                        orderStatusFilter === st.key
                          ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/50 font-bold shadow-md shadow-cyan-950/40'
                          : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
                      }`}
                    >
                      {st.label}
                    </button>
                  ))}
                </div>

                <button
                  type="button"
                  onClick={handleExportOrdersCSV}
                  className="px-3.5 py-1.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 text-xs font-mono font-bold flex items-center gap-1.5 transition-all shadow-md shrink-0 ml-auto"
                  title="Export orders to CSV file for Excel / Courier upload"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Export Orders to CSV (অর্ডার এক্সপোর্ট)</span>
                </button>
              </div>

              {filteredOrders.length === 0 ? (
                <div className="text-center py-16 text-slate-500 text-xs font-mono">
                  No orders found for this filter.
                </div>
              ) : (
                <div className="space-y-4">
                  {filteredOrders.map((ord) => (
                    <div
                      key={ord.id}
                      className="p-4 sm:p-5 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-slate-700 transition-all space-y-3"
                    >
                      {/* Order Header */}
                      <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-800">
                        <div className="flex items-center gap-3">
                          <span className="font-mono text-sm font-bold text-white bg-slate-800 px-2.5 py-1 rounded-lg border border-slate-700">
                            {ord.id}
                          </span>
                          <span className="text-xs text-slate-400 font-mono">
                            {new Date(ord.createdAt).toLocaleString()}
                          </span>
                          {ord.customerReceived && (
                            <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-[10px] font-mono font-bold flex items-center gap-1">
                              <PackageCheck className="w-3 h-3 text-emerald-400" />
                              Customer Received
                            </span>
                          )}
                        </div>

                        {/* Status Switcher & Confirmation Action */}
                        <div className="flex flex-wrap items-center gap-2">
                          <button
                            onClick={() => setShippingLabelOrder(ord)}
                            className="px-2.5 py-1 rounded-lg bg-indigo-500/15 hover:bg-indigo-500/25 text-indigo-300 border border-indigo-500/30 text-xs font-mono font-bold flex items-center gap-1 transition-all"
                            title="Print Courier Shipping Label & Barcode (শিপিং লেবেল প্রিন্ট)"
                          >
                            <Printer className="w-3.5 h-3.5 text-indigo-400" />
                            Print Label
                          </button>

                          <button
                            onClick={() => setViewingOrderReceipt(ord)}
                            className="px-2.5 py-1 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 text-xs font-mono font-bold flex items-center gap-1"
                            title="View Official Receipt"
                          >
                            <Eye className="w-3.5 h-3.5 text-cyan-400" />
                            View Receipt
                          </button>

                          {ord.status === 'Pending' && (
                            <button
                              onClick={() => {
                                setConfirmingOrder(ord);
                              }}
                              className="px-3 py-1 rounded-lg bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 text-slate-950 font-bold text-xs font-mono flex items-center gap-1 shadow-md"
                            >
                              <CheckCircle className="w-3.5 h-3.5 text-slate-950" />
                              Confirm Order (কনফার্ম করুন)
                            </button>
                          )}

                          <select
                            value={ord.status}
                            onChange={(e) => onUpdateOrderStatus(ord.id, e.target.value as Order['status'])}
                            className={`px-2.5 py-1 rounded-lg text-xs font-mono font-bold border focus:outline-none cursor-pointer ${statusColors[ord.status]}`}
                          >
                            <option value="Pending" className="bg-slate-900 text-amber-300">Pending</option>
                            <option value="Processing" className="bg-slate-900 text-cyan-300">Processing</option>
                            <option value="Shipped" className="bg-slate-900 text-indigo-300">Shipped</option>
                            <option value="Completed" className="bg-slate-900 text-emerald-300">Completed</option>
                            <option value="Cancelled" className="bg-slate-900 text-rose-300">Cancelled</option>
                          </select>

                          <button
                            type="button"
                            onClick={() => setDeletingOrderId(deletingOrderId === ord.id ? null : ord.id)}
                            className={`px-2.5 py-1 rounded-lg text-xs font-mono font-bold flex items-center gap-1.5 transition-all border ${
                              deletingOrderId === ord.id
                                ? 'bg-rose-600 text-white border-rose-500 shadow-md shadow-rose-950/50'
                                : 'bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border-rose-500/30'
                            }`}
                            title="Delete Order (অর্ডার ডিলেট করুন)"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>Delete</span>
                          </button>
                        </div>
                      </div>

                      {/* Order Permanent Delete Confirmation Box */}
                      {deletingOrderId === ord.id && (
                        <div className="p-3.5 rounded-xl bg-rose-950/80 border border-rose-500/60 space-y-2 animate-in fade-in text-xs font-mono">
                          <div className="flex items-center gap-2 text-rose-300 font-bold">
                            <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                            <span>অর্ডার স্থায়ীভাবে ডিলেট করার কনফার্মেশন:</span>
                          </div>
                          <p className="text-[11px] text-slate-200">
                            আপনি কি সত্যি অর্ডার <strong className="text-white font-bold">#{ord.id}</strong> (কাস্টমার: {ord.customerName}, মোট: ৳{ord.totalAmount}) স্থায়ীভাবে ডিলেট করতে চান? এটি স্টোর ডাটাবেস ও অর্ডার লিস্ট থেকে সম্পূর্ণ মুছে যাবে।
                          </p>
                          <div className="flex items-center justify-end gap-2 pt-1">
                            <button
                              type="button"
                              onClick={() => setDeletingOrderId(null)}
                              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-mono"
                            >
                              বাতিল (Cancel)
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                onDeleteOrder(ord.id);
                                setDeletingOrderId(null);
                              }}
                              className="px-3.5 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-mono font-bold flex items-center gap-1.5 shadow-lg shadow-rose-950/60"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                              <span>হ্যাঁ, অর্ডার ডিলেট করুন</span>
                            </button>
                          </div>
                        </div>
                      )}

                      {/* Customer Details */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                        <div className="space-y-1 bg-slate-950/60 p-3 rounded-xl border border-slate-800/80">
                          <span className="text-[10px] font-mono text-cyan-400 uppercase block mb-1">Customer Info</span>
                          <div className="flex items-center gap-2 text-white font-medium">
                            <User className="w-3.5 h-3.5 text-slate-400" />
                            {ord.customerName}
                          </div>
                          <div className="flex items-center gap-2 text-slate-300">
                            <Mail className="w-3.5 h-3.5 text-slate-400" />
                            {ord.customerEmail}
                          </div>
                          {ord.customerPhone && (
                            <div className="flex flex-wrap items-center justify-between gap-1.5 pt-1">
                              <div className="flex items-center gap-2 text-slate-300">
                                <Phone className="w-3.5 h-3.5 text-slate-400" />
                                <span className="font-mono">{ord.customerPhone}</span>
                              </div>
                              <div className="flex items-center gap-1.5">
                                <a
                                  href={`tel:${ord.customerPhone}`}
                                  className="px-2 py-1 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 text-[11px] font-bold flex items-center gap-1 transition-all active:scale-95"
                                  title="Direct Call Customer (মোবাইল থেকে সরাসরি কল করুন)"
                                >
                                  <Phone className="w-3 h-3 text-emerald-400" />
                                  <span>কল করুন</span>
                                </a>
                                <a
                                  href={`https://wa.me/880${ord.customerPhone.replace(/[^0-9]/g, '').replace(/^0+/, '')}`}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="px-2 py-1 rounded-lg bg-emerald-600/30 hover:bg-emerald-600/40 text-emerald-200 border border-emerald-500/50 text-[11px] font-bold flex items-center gap-1 transition-all active:scale-95"
                                  title="WhatsApp Message Customer (হোয়াটসঅ্যাপে মেসেজ পাঠান)"
                                >
                                  <MessageCircle className="w-3 h-3 text-emerald-400" />
                                  <span>WhatsApp</span>
                                </a>
                              </div>
                            </div>
                          )}
                          {ord.shippingAddress && (
                            <div className="flex items-start gap-2 text-slate-300 pt-1">
                              <MapPin className="w-3.5 h-3.5 text-slate-400 mt-0.5" />
                              <span>{ord.shippingAddress}</span>
                            </div>
                          )}

                          {/* Payment Gateway Badges */}
                          <div className="pt-2 mt-1 border-t border-slate-800/80 font-mono text-[11px] space-y-1">
                            <div className="flex items-center justify-between">
                              <span className="text-slate-400">Payment:</span>
                              <span className="font-bold text-pink-300 bg-pink-950/60 px-2 py-0.5 rounded border border-pink-500/30">
                                {ord.paymentMethod || 'Cash on Delivery'}
                              </span>
                            </div>
                            {ord.paymentSenderPhone && (
                              <div className="flex items-center justify-between">
                                <span className="text-slate-400">Sender Mobile:</span>
                                <span className="font-bold text-amber-300">{ord.paymentSenderPhone}</span>
                              </div>
                            )}
                            {ord.paymentTrxId && (
                              <div className="flex items-center justify-between">
                                <span className="text-slate-400">TrxID:</span>
                                <span className="font-bold text-cyan-300 tracking-wider bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-500/30 uppercase">
                                  {ord.paymentTrxId}
                                </span>
                              </div>
                            )}
                          </div>
                        </div>

                        {/* Order Items & Total */}
                        <div className="space-y-2 bg-slate-950/60 p-3 rounded-xl border border-slate-800/80">
                          <span className="text-[10px] font-mono text-cyan-400 uppercase block">Items Ordered</span>
                          {ord.items.map((item, idx) => (
                            <div key={idx} className="flex items-center justify-between text-xs text-slate-200">
                              <span>
                                {item.productName} <strong className="text-cyan-300 font-mono">x{item.quantity}</strong>
                              </span>
                              <span className="font-mono">৳{item.price * item.quantity}</span>
                            </div>
                          ))}
                          <div className="pt-2 border-t border-slate-800 flex items-center justify-between font-bold">
                            <span className="text-slate-400">Total Amount:</span>
                            <span className="text-cyan-300 font-mono text-sm">৳{ord.totalAmount} BDT</span>
                          </div>

                          {(() => {
                            const adv = ord.advancePaid !== undefined 
                              ? ord.advancePaid 
                              : (ord.paymentMethod === 'Cash on Delivery' ? 0 : ord.totalAmount);
                            const due = ord.dueAmount !== undefined 
                              ? ord.dueAmount 
                              : Math.max(0, ord.totalAmount - adv);
                            return (
                              <div className="grid grid-cols-2 gap-2 pt-1 border-t border-slate-800/80 text-[11px] font-mono">
                                <div className="flex items-center justify-between p-1.5 rounded bg-emerald-950/40 border border-emerald-500/30">
                                  <span className="text-emerald-300 font-bold">Advance:</span>
                                  <span className="text-emerald-400 font-extrabold">৳{adv}</span>
                                </div>
                                <div className="flex items-center justify-between p-1.5 rounded bg-amber-950/40 border border-amber-500/30">
                                  <span className="text-amber-300 font-bold">Due:</span>
                                  <span className="text-amber-400 font-extrabold">৳{due}</span>
                                </div>
                              </div>
                            );
                          })()}

                          {ord.notes && (
                            <div className="text-[11px] text-amber-300/80 italic pt-1 border-t border-slate-800/60 flex items-center gap-1">
                              <FileText className="w-3 h-3 text-amber-400" />
                              Note: {ord.notes}
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Customer Delivery Confirmation & Review Banner */}
                      {ord.customerReceived && (
                        <div className="p-3.5 rounded-xl bg-gradient-to-r from-emerald-950/80 to-teal-950/80 border border-emerald-500/50 space-y-2 animate-in fade-in">
                          <div className="flex flex-wrap items-center justify-between gap-2">
                            <div className="flex items-center gap-2">
                              <div className="w-8 h-8 rounded-lg bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
                                <PackageCheck className="w-4 h-4" />
                              </div>
                              <div>
                                <span className="font-bold text-white text-xs flex items-center gap-1.5">
                                  ✅ কাস্টমার পণ্য ডেলিভারি বুঝে পেয়েছে (Customer Verified Received)
                                </span>
                                {ord.customerReceivedAt && (
                                  <span className="text-[10px] text-emerald-400/80 font-mono">
                                    কনফার্মেশনের সময়: {new Date(ord.customerReceivedAt).toLocaleString()}
                                  </span>
                                )}
                              </div>
                            </div>

                            {ord.customerRating && (
                              <div className="flex items-center gap-1 px-3 py-1 rounded-lg bg-slate-900/90 border border-amber-500/30">
                                <span className="text-slate-300 text-xs font-mono">Rating:</span>
                                <div className="flex items-center text-amber-400">
                                  {[...Array(ord.customerRating)].map((_, i) => (
                                    <Star key={i} className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                                  ))}
                                </div>
                                <span className="text-xs font-bold font-mono text-amber-300 ml-1">
                                  {ord.customerRating}/5
                                </span>
                              </div>
                            )}
                          </div>

                          {ord.customerReview && (
                            <div className="p-2.5 rounded-lg bg-black/40 border border-emerald-500/20 text-xs text-slate-200 italic font-sans flex items-start gap-2">
                              <span className="text-emerald-400 font-bold not-italic">Customer Review:</span>
                              <span>"{ord.customerReview}"</span>
                            </div>
                          )}
                        </div>
                      )}

                      {/* Refund Management Control Panel for Cancelled Orders */}
                      {ord.status === 'Cancelled' && (
                        <AdminRefundForm order={ord} onUpdateOrder={onUpdateOrder} />
                      )}

                    </div>
                  ))}
                </div>
              )}

            </div>
          )}

          {/* TAB 2: PRODUCTS CATALOG */}
          {activeTab === 'products' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-slate-400 font-mono">Total {products.length} Products in Store</span>
                <button
                  onClick={() => setActiveTab('add_product')}
                  className="px-3 py-1.5 rounded-lg bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30 border border-emerald-500/40 text-xs font-mono font-bold flex items-center gap-1"
                >
                  <Plus className="w-3.5 h-3.5" />
                  Add Product
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {products.map((p) => (
                  <div key={p.id} className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex flex-col justify-between space-y-3">
                    <div className="flex items-start gap-3">
                      <img
                        src={p.image}
                        alt={p.name}
                        referrerPolicy="no-referrer"
                        className="w-16 h-16 rounded-lg object-cover border border-slate-800"
                      />
                      <div className="flex-1 min-w-0">
                        <span className="text-[10px] font-mono text-cyan-400 block">{p.category}</span>
                        <h4 className="text-sm font-bold text-white truncate font-['Space_Grotesk']">{p.name}</h4>
                        <div className="flex flex-wrap items-center gap-2 mt-1 font-mono text-xs">
                          <span className="text-emerald-400 font-bold">৳{p.price}</span>
                          {p.originalPrice && p.originalPrice > p.price && (
                            <span className="text-slate-500 line-through text-[11px]">৳{p.originalPrice}</span>
                          )}
                          {(() => {
                            const isActive = isProductDiscountActive(p);
                            const percent = p.discountPercent || (p.originalPrice && p.originalPrice > p.price ? Math.round(((p.originalPrice - p.price) / p.originalPrice) * 100) : null);
                            if (isActive && percent) {
                              const remaining = p.discountValidUntil ? getRemainingTime(p.discountValidUntil) : null;
                              return (
                                <span className="px-1.5 py-0.5 rounded bg-rose-500/20 text-rose-300 text-[10px] border border-rose-500/30 font-bold flex items-center gap-1">
                                  <Flame className="w-2.5 h-2.5 text-rose-400" />
                                  -{percent}%
                                  {remaining ? ` (${remaining.formattedText})` : ''}
                                </span>
                              );
                            } else if (p.discountPercent && !isActive) {
                              return (
                                <span className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 text-[10px] border border-slate-700 font-mono">
                                  ছাড় শেষ (Expired)
                                </span>
                              );
                            }
                            return null;
                          })()}
                          <span className="text-slate-400 ml-auto">Stock: {p.stock}</span>
                        </div>
                      </div>
                    </div>

                    <p className="text-xs text-slate-400 line-clamp-2">{p.description}</p>

                    {/* Quick Discount & Promotion Manager */}
                    <div className="p-2 rounded-lg bg-slate-950/80 border border-slate-800 space-y-1.5">
                      <div className="flex items-center justify-between text-[10px] font-mono">
                        <span className="text-slate-400 font-bold flex items-center gap-1">
                          <Percent className="w-3 h-3 text-rose-400" />
                          Quick Discount (দ্রুত ছাড় দিন):
                        </span>
                        {p.discountPercent && isProductDiscountActive(p) ? (
                          <button
                            onClick={() => handleClearDiscount(p)}
                            className="text-rose-400 hover:text-rose-300 font-bold text-[9px] underline flex items-center gap-0.5"
                            title="Remove Discount"
                          >
                            <X className="w-2.5 h-2.5" />
                            ছাড় বাতিল
                          </button>
                        ) : (
                          <span className="text-slate-500 text-[9px]">No discount</span>
                        )}
                      </div>

                      <div className="flex flex-wrap items-center gap-1 text-[10px] font-mono">
                        <button
                          onClick={() => handleQuickDiscountPreset(p, 10, 3)}
                          className="px-2 py-0.5 rounded bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 border border-rose-500/30 font-bold"
                          title="10% Discount for 3 Days"
                        >
                          ⚡ 10% (3d)
                        </button>
                        <button
                          onClick={() => handleQuickDiscountPreset(p, 20, 7)}
                          className="px-2 py-0.5 rounded bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 border border-rose-500/30 font-bold"
                          title="20% Discount for 7 Days (1 Week)"
                        >
                          ⚡ 20% (7d)
                        </button>
                        <button
                          onClick={() => handleQuickDiscountPreset(p, 30, 15)}
                          className="px-2 py-0.5 rounded bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 border border-rose-500/30 font-bold"
                          title="30% Discount for 15 Days"
                        >
                          ⚡ 30% (15d)
                        </button>
                        <button
                          onClick={() => handleOpenEditProduct(p)}
                          className="px-2 py-0.5 rounded bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 font-bold ml-auto flex items-center gap-1"
                          title="Custom Discount & Duration"
                        >
                          <Edit3 className="w-2.5 h-2.5" />
                          Custom
                        </button>
                      </div>
                    </div>

                    {/* Stock Control Quick Action Bar */}
                    <div className="p-2 rounded-lg bg-slate-950/80 border border-slate-800 space-y-1.5">
                      <div className="flex items-center justify-between text-[10px] font-mono">
                        <span className="text-slate-400 font-bold flex items-center gap-1">
                          <Package className="w-3 h-3 text-cyan-400" />
                          Stock Control (স্টক কন্ট্রোল):
                        </span>
                        <span
                          className={`font-bold px-1.5 py-0.5 rounded ${
                            p.stock === 0
                              ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 animate-pulse'
                              : p.stock <= 5
                              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                              : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                          }`}
                        >
                          {p.stock === 0 ? '0 (Out of Stock)' : `${p.stock} Units Available`}
                        </span>
                      </div>

                      <div className="flex flex-wrap items-center gap-1 text-[10px] font-mono">
                        <button
                          onClick={() => handleQuickStockChange(p, -1)}
                          disabled={p.stock <= 0}
                          className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-rose-300 border border-slate-700 font-bold"
                          title="Reduce stock by 1"
                        >
                          -1
                        </button>
                        <button
                          onClick={() => handleQuickStockChange(p, 1)}
                          className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-slate-700 font-bold"
                          title="Add 1 to stock"
                        >
                          +1
                        </button>
                        <button
                          onClick={() => handleQuickStockChange(p, 10)}
                          className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-700 font-bold"
                          title="Add 10 to stock"
                        >
                          +10
                        </button>
                        {p.stock > 0 ? (
                          <button
                            onClick={() => handleSetStockDirect(p, 0)}
                            className="px-2 py-0.5 rounded bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 font-bold ml-auto"
                            title="Mark as Out of Stock (0)"
                          >
                            Set Stock Out (0)
                          </button>
                        ) : (
                          <button
                            onClick={() => handleSetStockDirect(p, 10)}
                            className="px-2 py-0.5 rounded bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 font-bold ml-auto"
                            title="Restock with 10 units"
                          >
                            Restock +10
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Direct Quick Price Edit Box */}
                    <div className="p-2.5 rounded-xl bg-slate-950/90 border border-slate-800 space-y-2">
                      <div className="flex items-center justify-between text-xs font-mono">
                        <span className="text-slate-300 font-bold flex items-center gap-1">
                          <Tag className="w-3.5 h-3.5 text-cyan-400" />
                          Price (বিক্রয় মূল্য ৳):
                        </span>
                        <span className="text-[10px] text-slate-400">টাইপ করে Enter চাপুন বা Change করুন</span>
                      </div>

                      <div className="flex items-center gap-1.5">
                        <div className="relative flex-1">
                          <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-cyan-400 font-mono font-bold text-xs">৳</span>
                          <input
                            type="number"
                            min="1"
                            key={`price-input-${p.id}-${p.price}`}
                            defaultValue={p.price}
                            onBlur={(e) => {
                              const val = Number(e.target.value);
                              if (val > 0 && val !== p.price) {
                                handleQuickPriceChange(p, val - p.price);
                              }
                            }}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') {
                                const val = Number((e.target as HTMLInputElement).value);
                                if (val > 0 && val !== p.price) {
                                  handleQuickPriceChange(p, val - p.price);
                                }
                              }
                            }}
                            className="w-full bg-[#070A12] border border-cyan-500/40 focus:border-cyan-400 rounded-lg pl-6 pr-2 py-1 text-sm font-mono font-black text-cyan-300 focus:outline-none"
                            placeholder="Price"
                          />
                        </div>

                        <button
                          type="button"
                          onClick={() => handleQuickPriceChange(p, -100)}
                          className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-rose-300 border border-slate-700 text-[10px] font-mono font-bold"
                          title="Decrease ৳100"
                        >
                          -100
                        </button>
                        <button
                          type="button"
                          onClick={() => handleQuickPriceChange(p, 100)}
                          className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-slate-700 text-[10px] font-mono font-bold"
                          title="Increase ৳100"
                        >
                          +100
                        </button>
                      </div>
                    </div>

                    <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between gap-2">
                      <button
                        type="button"
                        onClick={() => handleOpenEditProduct(p)}
                        className="px-3 py-1.5 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 text-xs font-mono font-bold flex items-center gap-1.5 transition-all shadow-sm flex-1 justify-center"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                        Edit Product (সব এডিট করুন)
                      </button>

                      <button
                        type="button"
                        onClick={() => onDeleteProduct(p.id)}
                        className="p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 text-xs flex items-center gap-1"
                        title="Delete Product"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: ADD NEW PRODUCT */}
          {activeTab === 'add_product' && (
            <div className="max-w-xl mx-auto p-6 rounded-2xl bg-slate-900/90 border border-slate-800">
              <h3 className="text-lg font-bold text-white mb-1 font-['Space_Grotesk']">
                Add New Product to Store (পণ্য যোগ করুন)
              </h3>
              <p className="text-xs text-slate-400 mb-6">
                Enter details below to publish a new product to Lewra World store.
              </p>

              <form onSubmit={handleAddProductSubmit} className="space-y-4">
                <div>
                  <label className="text-xs font-mono text-slate-300 block mb-1">Product Name *</label>
                  <input
                    type="text"
                    required
                    value={newProductName}
                    onChange={(e) => setNewProductName(e.target.value)}
                    placeholder="e.g. Lewra Neural Controller Pro"
                    className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-xs font-mono text-slate-300 block">
                        Product Category *
                      </label>
                      <button
                        type="button"
                        onClick={() => setIsCustomCategoryMode(!isCustomCategoryMode)}
                        className="text-[10px] font-mono text-cyan-400 hover:text-cyan-300 underline"
                      >
                        {isCustomCategoryMode ? '← Select Existing' : '+ Custom'}
                      </button>
                    </div>

                    {!isCustomCategoryMode ? (
                      <select
                        value={newProductCategory}
                        onChange={(e) => {
                          if (e.target.value === 'CUSTOM') {
                            setIsCustomCategoryMode(true);
                          } else {
                            setNewProductCategory(e.target.value);
                          }
                        }}
                        className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-400 font-mono"
                      >
                        {Array.from(
                          new Set([
                            'Spatial Hardware',
                            'AI Hardware',
                            'Developer Tools',
                            'Security',
                            'Software License',
                            'Gadgets',
                            'Accessories',
                            ...products.map((p) => p.category)
                          ])
                        ).map((cat) => (
                          <option key={cat} value={cat}>
                            {cat}
                          </option>
                        ))}
                        <option value="CUSTOM">+ Type New Custom Category</option>
                      </select>
                    ) : (
                      <input
                        type="text"
                        required
                        value={customCategoryInput}
                        onChange={(e) => setCustomCategoryInput(e.target.value)}
                        placeholder="e.g. Gaming Gear, AI Chips"
                        className="w-full bg-[#070A12] border border-cyan-500/50 rounded-xl px-3.5 py-2 text-xs text-cyan-300 font-bold focus:outline-none focus:border-cyan-400 font-mono"
                      />
                    )}
                  </div>

                  <div>
                    <label className="text-xs font-mono text-slate-300 block mb-1">Price (৳ BDT) *</label>
                    <input
                      type="number"
                      required
                      step="1"
                      value={newProductPrice}
                      onChange={(e) => setNewProductPrice(e.target.value)}
                      placeholder="e.g. 15000"
                      className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-400 font-mono"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-mono text-slate-300 block mb-1">Initial Stock</label>
                    <input
                      type="number"
                      value={newProductStock}
                      onChange={(e) => setNewProductStock(e.target.value)}
                      placeholder="e.g. 20"
                      className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-400 font-mono"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-mono text-slate-300 block mb-1">Badge Tag</label>
                    <input
                      type="text"
                      value={newProductTag}
                      onChange={(e) => setNewProductTag(e.target.value)}
                      placeholder="e.g. New Launch"
                      className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-400 font-mono"
                    />
                  </div>
                </div>

                {/* Product Media Section: Images & Videos */}
                <div className="space-y-4 p-4 rounded-xl bg-slate-950/80 border border-slate-800">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono font-bold text-cyan-300 flex items-center gap-1.5">
                      <ImageIcon className="w-4 h-4 text-cyan-400" />
                      PRODUCT PHOTOS & GALLERY (ছবি যোগ করুন - ৭টা বা যত খুশি)
                    </span>
                    <span className="text-[10px] font-mono text-slate-400">
                      Total: {1 + newProductImagesList.length} Pics
                    </span>
                  </div>

                  {/* Primary Main Image */}
                  <div>
                    <label className="text-xs font-mono text-slate-300 block mb-1">
                      Main Primary Photo (মূল প্রধান ছবি) *
                    </label>
                    <div className="space-y-2">
                      <input
                        type="text"
                        value={newProductImage}
                        onChange={(e) => setNewProductImage(e.target.value)}
                        placeholder="https://... or upload below"
                        className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-400 font-mono"
                      />
                      <div className="flex items-center gap-2">
                        <label className="cursor-pointer px-3 py-1.5 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/40 text-cyan-300 text-xs font-mono font-bold flex items-center gap-1.5 transition-all">
                          <Upload className="w-3.5 h-3.5 text-cyan-400" />
                          Upload Main Pic (মূল ছবি ফাইল)
                          <input
                            type="file"
                            accept="image/*"
                            className="hidden"
                            onChange={(e) => {
                              const file = e.target.files?.[0];
                              if (file) {
                                const reader = new FileReader();
                                reader.onloadend = () => {
                                  if (typeof reader.result === 'string') {
                                    setNewProductImage(reader.result);
                                  }
                                };
                                reader.readAsDataURL(file);
                              }
                            }}
                          />
                        </label>
                        {newProductImage && (
                          <img src={newProductImage} alt="Main Preview" referrerPolicy="no-referrer" className="w-8 h-8 rounded border border-slate-700 object-cover shrink-0" />
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Additional Gallery Photos */}
                  <div className="pt-2 border-t border-slate-800 space-y-2">
                    <label className="text-xs font-mono text-slate-300 block font-bold">
                      Extra Gallery Photos (অতিরিক্ত ছবি - ২য়, ৩য়, ৭ম বা যত ইচ্ছা)
                    </label>

                    {/* Extra images thumbnail list */}
                    {newProductImagesList.length > 0 && (
                      <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 pt-1">
                        {newProductImagesList.map((imgUrl, idx) => (
                          <div key={idx} className="relative group rounded-lg overflow-hidden border border-slate-700 bg-slate-900 aspect-square">
                            <img src={imgUrl} alt={`Photo ${idx + 2}`} referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                            <button
                              type="button"
                              onClick={() => setNewProductImagesList(newProductImagesList.filter((_, i) => i !== idx))}
                              className="absolute top-1 right-1 p-1 rounded-full bg-rose-950/80 text-rose-300 border border-rose-500/40 hover:bg-rose-900 transition-all opacity-90 group-hover:opacity-100"
                              title="Delete photo"
                            >
                              <X className="w-3 h-3" />
                            </button>
                            <span className="absolute bottom-1 left-1 px-1.5 py-0.5 rounded bg-black/70 text-[9px] font-mono text-cyan-300 font-bold">
                              #{idx + 2}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Add extra image inputs (URL or Multi-file Upload) */}
                    <div className="flex flex-col sm:flex-row gap-2 pt-1">
                      <input
                        type="text"
                        value={newExtraImageInput}
                        onChange={(e) => setNewExtraImageInput(e.target.value)}
                        placeholder="Paste image URL here..."
                        className="flex-1 bg-[#070A12] border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-400 font-mono"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          if (newExtraImageInput.trim()) {
                            setNewProductImagesList([...newProductImagesList, newExtraImageInput.trim()]);
                            setNewExtraImageInput('');
                          }
                        }}
                        className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 font-mono text-xs font-bold shrink-0 border border-slate-700"
                      >
                        + Add URL
                      </button>
                      <label className="cursor-pointer px-3 py-1.5 rounded-xl bg-indigo-500/20 hover:bg-indigo-500/30 border border-indigo-500/40 text-indigo-300 text-xs font-mono font-bold flex items-center justify-center gap-1.5 transition-all shrink-0">
                        <Upload className="w-3.5 h-3.5 text-indigo-400" />
                        + Upload Pics (একাধিক ছবি)
                        <input
                          type="file"
                          accept="image/*"
                          multiple
                          className="hidden"
                          onChange={(e) => {
                            const files = e.target.files;
                            if (files) {
                              Array.from(files).forEach((file: File) => {
                                const reader = new FileReader();
                                reader.onloadend = () => {
                                  if (typeof reader.result === 'string') {
                                    setNewProductImagesList((prev) => [...prev, reader.result as string]);
                                  }
                                };
                                reader.readAsDataURL(file);
                              });
                            }
                          }}
                        />
                      </label>
                    </div>
                  </div>

                  {/* Product Videos Section */}
                  <div className="pt-3 border-t border-slate-800 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-mono font-bold text-indigo-300 flex items-center gap-1.5">
                        <Play className="w-4 h-4 text-indigo-400 fill-indigo-400" />
                        PRODUCT VIDEOS & DEMOS (ভিডিও ডেমো - ২টি বা যত খুশি)
                      </span>
                      <span className="text-[10px] font-mono text-slate-400">
                        Total: {(newProductVideoUrl ? 1 : 0) + newProductVideosList.length} Vids
                      </span>
                    </div>

                    {/* Primary Video */}
                    <div>
                      <label className="text-[11px] font-mono text-slate-300 block mb-1">
                        Primary Video (১ম ভিডিও - সরাসরি MP4 ফাইল আপলোড বা লিঙ্ক)
                      </label>
                      <input
                        type="text"
                        value={newProductVideoUrl}
                        onChange={(e) => setNewProductVideoUrl(e.target.value)}
                        placeholder="Direct video link (.mp4/webm), video URL or choose file below..."
                        className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-400 font-mono"
                      />
                      <div className="flex items-center gap-2 mt-1.5">
                        <label className="cursor-pointer px-3 py-1.5 rounded-xl bg-indigo-500/20 hover:bg-indigo-500/30 border border-indigo-500/40 text-indigo-300 text-xs font-mono font-bold flex items-center gap-1.5 transition-all">
                          <Upload className="w-3.5 h-3.5 text-indigo-400" />
                          Upload Video File (সরাসরি ভিডিও ফাইল আপলোড)
                          <input
                            type="file"
                            accept="video/*"
                            className="hidden"
                            onChange={(e) => {
                              const file = e.target.files?.[0];
                              if (file) {
                                const reader = new FileReader();
                                reader.onloadend = () => {
                                  if (typeof reader.result === 'string') {
                                    setNewProductVideoUrl(reader.result);
                                  }
                                };
                                reader.readAsDataURL(file);
                              }
                            }}
                          />
                        </label>
                        {newProductVideoUrl && (
                          <span className="text-[10px] font-mono text-emerald-400 flex items-center gap-1">
                            <Check className="w-3 h-3" /> Video Loaded
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Extra Videos List */}
                    {newProductVideosList.length > 0 && (
                      <div className="space-y-1.5 pt-1">
                        {newProductVideosList.map((vUrl, idx) => (
                          <div key={idx} className="flex items-center justify-between p-2 rounded-lg bg-slate-900 border border-slate-800 text-xs font-mono text-slate-300">
                            <span className="truncate max-w-[80%] flex items-center gap-1.5 text-indigo-300">
                              <Play className="w-3 h-3 fill-indigo-400 shrink-0" />
                              Video #{idx + 2}: {vUrl.startsWith('data:video') ? 'Uploaded Video File' : vUrl}
                            </span>
                            <button
                              type="button"
                              onClick={() => setNewProductVideosList(newProductVideosList.filter((_, i) => i !== idx))}
                              className="p-1 rounded bg-rose-950 text-rose-400 hover:bg-rose-900 border border-rose-500/40"
                              title="Delete video"
                            >
                              <X className="w-3 h-3" />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Add extra video input (Direct File Upload + Direct Link) */}
                    <div className="flex flex-col sm:flex-row gap-2 pt-1">
                      <input
                        type="text"
                        value={newExtraVideoInput}
                        onChange={(e) => setNewExtraVideoInput(e.target.value)}
                        placeholder="Add 2nd/3rd video link or direct URL..."
                        className="flex-1 bg-[#070A12] border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-indigo-400 font-mono"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          if (newExtraVideoInput.trim()) {
                            setNewProductVideosList([...newProductVideosList, newExtraVideoInput.trim()]);
                            setNewExtraVideoInput('');
                          }
                        }}
                        className="px-3 py-1.5 rounded-xl bg-indigo-600/30 hover:bg-indigo-600/40 border border-indigo-500/40 text-indigo-300 font-mono text-xs font-bold shrink-0"
                      >
                        + Add Link
                      </button>
                      <label className="cursor-pointer px-3 py-1.5 rounded-xl bg-indigo-500/20 hover:bg-indigo-500/30 border border-indigo-500/40 text-indigo-300 text-xs font-mono font-bold flex items-center justify-center gap-1.5 transition-all shrink-0">
                        <Upload className="w-3.5 h-3.5 text-indigo-400" />
                        + Upload Video
                        <input
                          type="file"
                          accept="video/*"
                          multiple
                          className="hidden"
                          onChange={(e) => {
                            const files = e.target.files;
                            if (files) {
                              Array.from(files).forEach((file: File) => {
                                const reader = new FileReader();
                                reader.onloadend = () => {
                                  if (typeof reader.result === 'string') {
                                    setNewProductVideosList((prev) => [...prev, reader.result as string]);
                                  }
                                };
                                reader.readAsDataURL(file);
                              });
                            }
                          }}
                        />
                      </label>
                    </div>
                  </div>

                </div>

                <div>
                  <label className="text-xs font-mono text-slate-300 block mb-1">Description</label>
                  <textarea
                    rows={3}
                    value={newProductDesc}
                    onChange={(e) => setNewProductDesc(e.target.value)}
                    placeholder="Write a short summary of product features..."
                    className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-400 to-cyan-500 hover:from-emerald-300 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-lg shadow-emerald-500/20"
                >
                  <Plus className="w-4 h-4" />
                  Publish Product To Store
                </button>
              </form>
            </div>
          )}

          {/* TAB 4: ABOUT US EDITOR */}
          {activeTab === 'about_us' && (
            <div className="max-w-2xl mx-auto p-6 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-6">
              <div>
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-bold text-white font-['Space_Grotesk']">
                      Website Name, Branding & Payment Settings (ওয়েবসাইট সেটিংস)
                    </h3>
                    <p className="text-xs text-slate-400 mt-0.5">
                      এখানে আপনি আপনার সাইটের নাম, লোগো, বিকাশ ও নগদ নম্বর ও বিবরণ পরিবর্তন করে সেভ করতে পারবেন।
                    </p>
                  </div>
                  <button
                    type="submit"
                    form="about-settings-form"
                    className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-400 via-cyan-400 to-indigo-500 hover:from-emerald-300 hover:to-indigo-400 text-slate-950 font-extrabold text-xs flex items-center gap-1.5 transition-all shadow-lg shadow-cyan-500/30 hover:scale-105 shrink-0"
                  >
                    <Save className="w-4 h-4" />
                    Save Settings (সেভ করুন)
                  </button>
                </div>
              </div>

              {aboutSavedMessage && (
                <div className="p-3.5 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2 font-bold animate-in fade-in">
                  <Check className="w-4 h-4 text-emerald-400" />
                  Website Settings, Name & Payment details saved successfully!
                </div>
              )}

              <form id="about-settings-form" onSubmit={handleSaveAboutUsSubmit} className="space-y-4">
                {/* Website Name & Branding Configuration */}
                <div className="p-4 rounded-xl bg-gradient-to-r from-purple-950/50 via-cyan-950/30 to-slate-900 border border-purple-500/40 space-y-4 shadow-lg">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-purple-300 font-bold text-xs font-mono">
                      <Sparkles className="w-4 h-4 text-purple-400" />
                      WEBSITE BRANDING, NAME & LOGO (ওয়েবসাইটের নাম ও লোগো)
                    </div>
                    <button
                      type="submit"
                      className="px-3 py-1.5 rounded-lg bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold text-[11px] flex items-center gap-1 transition-all"
                    >
                      <Save className="w-3.5 h-3.5" />
                      Quick Save Name
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs font-mono text-slate-200 block mb-1 font-bold">
                        Website Name / Brand Title (ওয়েবসাইটের নাম) *
                      </label>
                      <input
                        type="text"
                        required
                        value={editAbout.companyName}
                        onChange={(e) => setEditAbout({ ...editAbout, companyName: e.target.value })}
                        placeholder="e.g. My Custom Brand Store"
                        className="w-full bg-[#070A12] border border-purple-500/50 rounded-xl px-3.5 py-2.5 text-xs text-white font-bold focus:outline-none focus:border-purple-400 font-mono shadow-inner"
                      />
                      <p className="text-[11px] text-slate-400 mt-1">
                        এই নামটি নেভবার লোগো, ফুটার, ব্রাউজার ট্যাব এবং সম্পূর্ণ সাইটে পরিবর্তন হবে।
                      </p>
                    </div>

                    <div>
                      <label className="text-xs font-mono text-slate-200 block mb-1 font-bold">
                        Website Tagline / Slogan (ট্যাগলাইন বা স্লোগান)
                      </label>
                      <input
                        type="text"
                        value={editAbout.tagline}
                        onChange={(e) => setEditAbout({ ...editAbout, tagline: e.target.value })}
                        placeholder="e.g. Leading Tech & Hardware Solutions"
                        className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-purple-400 font-mono"
                      />
                      <p className="text-[11px] text-slate-400 mt-1">
                        ওয়েবসাইটের স্লোগান বা সাবটাইটেল হিসেবে কাজ করবে।
                      </p>
                    </div>
                  </div>

                  {/* Logo Image URL field with live preview & direct file upload */}
                  <div className="pt-2 border-t border-purple-500/30">
                    <label className="text-xs font-mono text-cyan-300 block mb-1 font-bold flex items-center justify-between">
                      <span>Website Main Logo Image (ওয়েবসাইটের লোগো ছবি/লিঙ্ক)</span>
                      {editAbout.logoUrl && (
                        <button
                          type="button"
                          onClick={() => setEditAbout({ ...editAbout, logoUrl: '' })}
                          className="text-[10px] text-rose-400 hover:underline font-normal"
                        >
                          Remove Logo (ডিফল্ট লোগোতে ফেরত যান)
                        </button>
                      )}
                    </label>
                    <div className="flex gap-3 items-center">
                      <div className="w-12 h-12 rounded-xl bg-slate-950 border border-slate-700 flex items-center justify-center shrink-0 overflow-hidden">
                        {editAbout.logoUrl ? (
                          <img
                            src={editAbout.logoUrl}
                            alt="Logo Preview"
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <ImageIcon className="w-6 h-6 text-slate-600" />
                        )}
                      </div>
                      <div className="flex-1 space-y-1.5">
                        <input
                          type="text"
                          value={editAbout.logoUrl || ''}
                          onChange={(e) => setEditAbout({ ...editAbout, logoUrl: e.target.value })}
                          placeholder="https://... or choose logo file below"
                          className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-slate-200 focus:outline-none focus:border-cyan-400 font-mono"
                        />
                        <label className="cursor-pointer inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-purple-500/20 hover:bg-purple-500/30 border border-purple-500/40 text-purple-300 text-[11px] font-mono font-bold transition-all">
                          <Upload className="w-3 h-3 text-purple-400" />
                          Upload Logo Pic (লোগো ফাইল আপলোড)
                          <input
                            type="file"
                            accept="image/*"
                            className="hidden"
                            onChange={(e) => {
                              const file = e.target.files?.[0];
                              if (file) {
                                const reader = new FileReader();
                                reader.onloadend = () => {
                                  if (typeof reader.result === 'string') {
                                    setEditAbout({ ...editAbout, logoUrl: reader.result });
                                  }
                                };
                                reader.readAsDataURL(file);
                              }
                            }}
                          />
                        </label>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Brand Origin & Country Configuration Card */}
                <div className="p-4 rounded-xl bg-gradient-to-r from-cyan-950/50 via-blue-950/40 to-slate-900 border border-cyan-500/40 space-y-4 shadow-lg">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-cyan-300 font-bold text-xs font-mono">
                      <Flag className="w-4 h-4 text-cyan-400" />
                      BRAND ORIGIN & COUNTRY SETTINGS (ব্র্যান্ডটি কোন দেশের / উৎস দেশ নির্ধারণ)
                    </div>
                    <button
                      type="submit"
                      className="px-3 py-1.5 rounded-lg bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold text-[11px] flex items-center gap-1 transition-all"
                    >
                      <Save className="w-3.5 h-3.5" />
                      Save Country
                    </button>
                  </div>

                  <p className="text-[11px] text-slate-300">
                    আপনার ব্র্যান্ডটি কোন দেশের তা নির্বাচন করুন বা সরাসরি লিখে দিন। এটি About Us সেকশনে এবং ব্র্যান্ড পরিচিতিতে ব্যাজ ও ফ্ল্যাগ সহ সুন্দরভাবে প্রদর্শিত হবে।
                  </p>

                  {/* Preset Country Buttons */}
                  <div className="space-y-1.5">
                    <span className="text-[11px] font-mono font-bold text-slate-300 block">
                      Quick Country Presets (এক ক্লিকে দেশ নির্বাচন করুন):
                    </span>
                    <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-2 text-xs font-mono">
                      {[
                        { name: 'Bangladesh', flag: '🇧🇩' },
                        { name: 'United States (USA)', flag: '🇺🇸' },
                        { name: 'Japan', flag: '🇯🇵' },
                        { name: 'Germany', flag: '🇩🇪' },
                        { name: 'United Kingdom', flag: '🇬🇧' },
                        { name: 'China', flag: '🇨🇳' },
                        { name: 'South Korea', flag: '🇰🇷' },
                        { name: 'Singapore', flag: '🇸🇬' },
                        { name: 'UAE (Dubai)', flag: '🇦🇪' },
                        { name: 'India', flag: '🇮🇳' },
                        { name: 'Italy', flag: '🇮🇹' },
                        { name: 'Global / International', flag: '🌐' }
                      ].map((item) => {
                        const isSelected = editAbout.brandOriginCountry === item.name;
                        return (
                          <button
                            key={item.name}
                            type="button"
                            onClick={() => {
                              setEditAbout({
                                ...editAbout,
                                brandOriginCountry: item.name,
                                brandOriginFlag: item.flag
                              });
                            }}
                            className={`p-2 rounded-xl border flex items-center gap-2 transition-all ${
                              isSelected
                                ? 'bg-cyan-500/20 border-cyan-400 text-cyan-200 font-bold shadow-md shadow-cyan-950/60 scale-105'
                                : 'bg-slate-950/80 border-slate-800 text-slate-300 hover:border-slate-600 hover:text-white'
                            }`}
                          >
                            <span className="text-lg leading-none">{item.flag}</span>
                            <span className="text-[11px] truncate">{item.name}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Manual Inputs for Country, Flag, Est. Year, and Story */}
                  <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 pt-2 border-t border-cyan-500/20">
                    <div className="sm:col-span-5">
                      <label className="text-xs font-mono text-slate-200 block mb-1 font-bold">
                        Country of Origin (ব্র্যান্ডের মূল দেশ) *
                      </label>
                      <input
                        type="text"
                        value={editAbout.brandOriginCountry || ''}
                        onChange={(e) => setEditAbout({ ...editAbout, brandOriginCountry: e.target.value })}
                        placeholder="e.g. Bangladesh, United States, Japan..."
                        className="w-full bg-[#070A12] border border-cyan-500/50 rounded-xl px-3.5 py-2 text-xs text-white font-bold font-mono focus:outline-none focus:border-cyan-400"
                      />
                    </div>

                    <div className="sm:col-span-3">
                      <label className="text-xs font-mono text-slate-200 block mb-1 font-bold">
                        Flag / Symbol (পতাকা/ইমোজি)
                      </label>
                      <input
                        type="text"
                        value={editAbout.brandOriginFlag || ''}
                        onChange={(e) => setEditAbout({ ...editAbout, brandOriginFlag: e.target.value })}
                        placeholder="e.g. 🇧🇩, 🇺🇸, 🇯🇵, 🌐"
                        className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-amber-300 font-bold font-mono focus:outline-none focus:border-cyan-400 text-center"
                      />
                    </div>

                    <div className="sm:col-span-4">
                      <label className="text-xs font-mono text-slate-200 block mb-1 font-bold">
                        Established Year (প্রতিষ্ঠার সাল)
                      </label>
                      <input
                        type="text"
                        value={editAbout.brandEstablishedYear || ''}
                        onChange={(e) => setEditAbout({ ...editAbout, brandEstablishedYear: e.target.value })}
                        placeholder="e.g. 2024 or Since 2022"
                        className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-purple-300 font-bold font-mono focus:outline-none focus:border-cyan-400"
                      />
                    </div>

                    <div className="sm:col-span-12">
                      <label className="text-xs font-mono text-slate-200 block mb-1 font-bold">
                        Brand Origin Tagline & Mission (ব্র্যান্ডের উৎস ও পরিচিতি সম্পর্কিত সংক্ষিপ্ত বার্তা)
                      </label>
                      <textarea
                        rows={2}
                        value={editAbout.brandOriginStory || ''}
                        onChange={(e) => setEditAbout({ ...editAbout, brandOriginStory: e.target.value })}
                        placeholder="e.g. Proudly founded & engineered in Bangladesh, providing premium hardware solutions for global tech enthusiasts."
                        className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-slate-200 focus:outline-none focus:border-cyan-400 leading-relaxed font-mono"
                      />
                    </div>
                  </div>
                </div>

                {/* Payment Gateway Configuration Card */}
                <div className="p-4 rounded-xl bg-gradient-to-r from-pink-950/40 via-amber-950/30 to-slate-900 border border-pink-500/40 space-y-4 shadow-lg">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-pink-300 font-bold text-xs font-mono">
                      <Smartphone className="w-4 h-4 text-pink-400" />
                      PAYMENT GATEWAY CONFIGURATION (বিকাশ ও নগদ পেমেন্ট নম্বর ও লোগো)
                    </div>
                    <button
                      type="submit"
                      className="px-3 py-1.5 rounded-lg bg-pink-500 hover:bg-pink-400 text-white font-bold text-[11px] flex items-center gap-1 transition-all"
                    >
                      <Save className="w-3.5 h-3.5" />
                      Save Numbers & Logos
                    </button>
                  </div>

                  <p className="text-[11px] text-slate-300">
                    এখানে আপনার বিকাশ, নগদ ও রকেট নম্বর এবং তাদের লোগো সরাসরি ডিভাইস থেকে ফাইল আপলোড অথবা লিঙ্ক পেস্ট করে সেভ করুন।
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    {/* bKash Section */}
                    <div className="p-3 rounded-xl bg-pink-950/30 border border-pink-500/40 space-y-2">
                      <div className="flex items-center gap-2">
                        {editAbout.bkashLogoUrl ? (
                          <img src={editAbout.bkashLogoUrl} alt="bKash Logo" referrerPolicy="no-referrer" className="w-6 h-6 rounded object-cover" />
                        ) : (
                          <Smartphone className="w-5 h-5 text-pink-400" />
                        )}
                        <span className="text-xs font-bold text-pink-300 font-mono">bKash (বিকাশ)</span>
                      </div>
                      <div>
                        <label className="text-[10px] font-mono text-slate-300 block mb-0.5 font-bold">bKash Mobile Number *</label>
                        <input
                          type="text"
                          value={editAbout.bkashNumber || ''}
                          onChange={(e) => setEditAbout({ ...editAbout, bkashNumber: e.target.value })}
                          placeholder="01700-000000 (Personal)"
                          className="w-full bg-[#070A12] border border-pink-500/50 rounded-lg px-2.5 py-1.5 text-xs text-white font-mono font-bold focus:outline-none focus:border-pink-400"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] font-mono text-slate-300 block mb-0.5">bKash Logo Image / Upload</label>
                        <input
                          type="text"
                          value={editAbout.bkashLogoUrl || ''}
                          onChange={(e) => setEditAbout({ ...editAbout, bkashLogoUrl: e.target.value })}
                          placeholder="https://..."
                          className="w-full bg-[#070A12] border border-slate-700 rounded-lg px-2.5 py-1.5 text-[11px] text-pink-200 font-mono focus:outline-none focus:border-pink-400"
                        />
                        <label className="cursor-pointer mt-1 inline-flex items-center gap-1 text-[10px] font-mono text-pink-400 hover:text-pink-300 font-bold">
                          <Upload className="w-3 h-3" />
                          Choose bKash Logo Pic
                          <input
                            type="file"
                            accept="image/*"
                            className="hidden"
                            onChange={(e) => {
                              const file = e.target.files?.[0];
                              if (file) {
                                const reader = new FileReader();
                                reader.onloadend = () => {
                                  if (typeof reader.result === 'string') {
                                    setEditAbout({ ...editAbout, bkashLogoUrl: reader.result });
                                  }
                                };
                                reader.readAsDataURL(file);
                              }
                            }}
                          />
                        </label>
                      </div>
                    </div>

                    {/* Nagad Section */}
                    <div className="p-3 rounded-xl bg-amber-950/30 border border-amber-500/40 space-y-2">
                      <div className="flex items-center gap-2">
                        {editAbout.nagadLogoUrl ? (
                          <img src={editAbout.nagadLogoUrl} alt="Nagad Logo" referrerPolicy="no-referrer" className="w-6 h-6 rounded object-cover" />
                        ) : (
                          <Smartphone className="w-5 h-5 text-amber-400" />
                        )}
                        <span className="text-xs font-bold text-amber-300 font-mono">Nagad (নগদ)</span>
                      </div>
                      <div>
                        <label className="text-[10px] font-mono text-slate-300 block mb-0.5 font-bold">Nagad Mobile Number *</label>
                        <input
                          type="text"
                          value={editAbout.nagadNumber || ''}
                          onChange={(e) => setEditAbout({ ...editAbout, nagadNumber: e.target.value })}
                          placeholder="01800-000000 (Personal)"
                          className="w-full bg-[#070A12] border border-amber-500/50 rounded-lg px-2.5 py-1.5 text-xs text-white font-mono font-bold focus:outline-none focus:border-amber-400"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] font-mono text-slate-300 block mb-0.5">Nagad Logo Image / Upload</label>
                        <input
                          type="text"
                          value={editAbout.nagadLogoUrl || ''}
                          onChange={(e) => setEditAbout({ ...editAbout, nagadLogoUrl: e.target.value })}
                          placeholder="https://..."
                          className="w-full bg-[#070A12] border border-slate-700 rounded-lg px-2.5 py-1.5 text-[11px] text-amber-200 font-mono focus:outline-none focus:border-amber-400"
                        />
                        <label className="cursor-pointer mt-1 inline-flex items-center gap-1 text-[10px] font-mono text-amber-400 hover:text-amber-300 font-bold">
                          <Upload className="w-3 h-3" />
                          Choose Nagad Logo Pic
                          <input
                            type="file"
                            accept="image/*"
                            className="hidden"
                            onChange={(e) => {
                              const file = e.target.files?.[0];
                              if (file) {
                                const reader = new FileReader();
                                reader.onloadend = () => {
                                  if (typeof reader.result === 'string') {
                                    setEditAbout({ ...editAbout, nagadLogoUrl: reader.result });
                                  }
                                };
                                reader.readAsDataURL(file);
                              }
                            }}
                          />
                        </label>
                      </div>
                    </div>

                    {/* Rocket Section */}
                    <div className="p-3 rounded-xl bg-purple-950/30 border border-purple-500/40 space-y-2">
                      <div className="flex items-center gap-2">
                        {editAbout.rocketLogoUrl ? (
                          <img src={editAbout.rocketLogoUrl} alt="Rocket Logo" referrerPolicy="no-referrer" className="w-6 h-6 rounded object-cover" />
                        ) : (
                          <Smartphone className="w-5 h-5 text-purple-400" />
                        )}
                        <span className="text-xs font-bold text-purple-300 font-mono">Rocket (রকেট)</span>
                      </div>
                      <div>
                        <label className="text-[10px] font-mono text-slate-300 block mb-0.5 font-bold">Rocket Mobile Number</label>
                        <input
                          type="text"
                          value={editAbout.rocketNumber || ''}
                          onChange={(e) => setEditAbout({ ...editAbout, rocketNumber: e.target.value })}
                          placeholder="01900-000000 (Personal)"
                          className="w-full bg-[#070A12] border border-purple-500/50 rounded-lg px-2.5 py-1.5 text-xs text-white font-mono font-bold focus:outline-none focus:border-purple-400"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] font-mono text-slate-300 block mb-0.5">Rocket Logo Image / Upload</label>
                        <input
                          type="text"
                          value={editAbout.rocketLogoUrl || ''}
                          onChange={(e) => setEditAbout({ ...editAbout, rocketLogoUrl: e.target.value })}
                          placeholder="https://..."
                          className="w-full bg-[#070A12] border border-slate-700 rounded-lg px-2.5 py-1.5 text-[11px] text-purple-200 font-mono focus:outline-none focus:border-purple-400"
                        />
                        <label className="cursor-pointer mt-1 inline-flex items-center gap-1 text-[10px] font-mono text-purple-400 hover:text-purple-300 font-bold">
                          <Upload className="w-3 h-3" />
                          Choose Rocket Logo Pic
                          <input
                            type="file"
                            accept="image/*"
                            className="hidden"
                            onChange={(e) => {
                              const file = e.target.files?.[0];
                              if (file) {
                                const reader = new FileReader();
                                reader.onloadend = () => {
                                  if (typeof reader.result === 'string') {
                                    setEditAbout({ ...editAbout, rocketLogoUrl: reader.result });
                                  }
                                };
                                reader.readAsDataURL(file);
                              }
                            }}
                          />
                        </label>
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-mono text-slate-300 block mb-1 font-bold">
                      Payment Instructions (পেমেন্ট নির্দেশিকা টেক্সট)
                    </label>
                    <textarea
                      rows={2}
                      value={editAbout.paymentInstructions || ''}
                      onChange={(e) => setEditAbout({ ...editAbout, paymentInstructions: e.target.value })}
                      placeholder="Send Money or Cash Out to our official number, then enter your TrxID below..."
                      className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-slate-200 focus:outline-none focus:border-pink-400 leading-relaxed font-mono"
                    />
                  </div>
                </div>

                {/* Cash on Delivery, Card Toggles & Delivery Charge Settings */}
                <div className="p-4 rounded-xl bg-gradient-to-r from-emerald-950/40 via-cyan-950/30 to-slate-900 border border-emerald-500/40 space-y-4 shadow-lg">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-emerald-300 font-bold text-xs font-mono">
                      <Truck className="w-4 h-4 text-emerald-400" />
                      PAYMENT TOGGLES & DELIVERY CHARGE RATES
                    </div>
                    <button
                      type="submit"
                      className="px-3 py-1.5 rounded-lg bg-emerald-400 hover:bg-emerald-300 text-slate-950 font-bold text-[11px] flex items-center gap-1 transition-all"
                    >
                      <Save className="w-3.5 h-3.5" />
                      Save Toggles & Rates
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* Payment Toggles */}
                    <div className="space-y-3 bg-[#070A12] p-3 rounded-xl border border-slate-800">
                      <span className="text-xs font-mono font-bold text-slate-200 block">Enable/Disable Payment Options:</span>
                      
                      <label className="flex items-center gap-2 cursor-pointer select-none">
                        <input
                          type="checkbox"
                          checked={editAbout.enableCashOnDelivery !== false}
                          onChange={(e) => setEditAbout({ ...editAbout, enableCashOnDelivery: e.target.checked })}
                          className="w-4 h-4 accent-emerald-500 rounded"
                        />
                        <span className="text-xs text-slate-200 font-mono">Enable Cash on Delivery</span>
                      </label>

                      <label className="flex items-center gap-2 cursor-pointer select-none">
                        <input
                          type="checkbox"
                          checked={editAbout.enableCardPayment !== false}
                          onChange={(e) => setEditAbout({ ...editAbout, enableCardPayment: e.target.checked })}
                          className="w-4 h-4 accent-cyan-500 rounded"
                        />
                        <span className="text-xs text-slate-200 font-mono">Enable Card / Bank Transfer</span>
                      </label>
                    </div>

                    {/* Delivery Charge Rates */}
                    <div className="space-y-3 bg-[#070A12] p-3 rounded-xl border border-slate-800">
                      <span className="text-xs font-mono font-bold text-slate-200 block">Delivery Charge Rates:</span>
                      
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="text-[10px] font-mono text-cyan-300 block mb-0.5 font-bold">Inside Dhaka (৳)</label>
                          <input
                            type="number"
                            value={editAbout.deliveryChargeInsideDhaka ?? 60}
                            onChange={(e) => setEditAbout({ ...editAbout, deliveryChargeInsideDhaka: parseInt(e.target.value) || 0 })}
                            className="w-full bg-[#0C111E] border border-cyan-500/50 rounded-lg px-2.5 py-1.5 text-xs text-cyan-300 font-mono font-bold focus:outline-none focus:border-cyan-400"
                          />
                        </div>

                        <div>
                          <label className="text-[10px] font-mono text-indigo-300 block mb-0.5 font-bold">Outside Dhaka (৳)</label>
                          <input
                            type="number"
                            value={editAbout.deliveryChargeOutsideDhaka ?? 130}
                            onChange={(e) => setEditAbout({ ...editAbout, deliveryChargeOutsideDhaka: parseInt(e.target.value) || 0 })}
                            className="w-full bg-[#0C111E] border border-indigo-500/50 rounded-lg px-2.5 py-1.5 text-xs text-indigo-300 font-mono font-bold focus:outline-none focus:border-indigo-400"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="text-[10px] font-mono text-slate-300 block mb-0.5 font-bold">
                          Delivery Note / Terms
                        </label>
                        <input
                          type="text"
                          value={editAbout.deliveryNote || ''}
                          onChange={(e) => setEditAbout({ ...editAbout, deliveryNote: e.target.value })}
                          placeholder="Home delivery available in 1-2 days within Dhaka, 2-4 days outside..."
                          className="w-full bg-[#0C111E] border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 font-mono focus:outline-none focus:border-cyan-400"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Comprehensive Promotional Banner & Flash Sale Campaign Customizer */}
                <div className="p-4 rounded-2xl bg-gradient-to-br from-slate-900 via-[#0a0f1d] to-slate-950 border border-amber-500/40 space-y-5 shadow-2xl">
                  {/* Header Title & Master Toggle */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
                    <div>
                      <div className="flex items-center gap-2 text-amber-300 font-bold text-sm font-mono">
                        <Flame className="w-5 h-5 text-rose-400 animate-pulse" />
                        <span>PROMOTIONAL BANNER & FLASH SALE CUSTOMIZER (ব্যানার ও অফার কাস্টমাইজেশন)</span>
                      </div>
                      <p className="text-xs text-slate-400 mt-0.5">
                        ওয়েবসাইটের একদম শীর্ষে আকর্ষণীয় অফার বা ডিসকাউন্ট ব্যানার নিজের পছন্দমতো ডিজাইন করুন।
                      </p>
                    </div>

                    <label className="relative inline-flex items-center cursor-pointer gap-2.5 shrink-0 bg-slate-950/80 px-3.5 py-1.5 rounded-xl border border-slate-800">
                      <span className="text-xs font-mono font-bold text-amber-300">
                        {editAbout.flashSaleActive ? '🔥 Banner Active (ব্যানার চালু)' : 'Banner Inactive (ব্যানার বন্ধ)'}
                      </span>
                      <input
                        type="checkbox"
                        checked={editAbout.flashSaleActive || false}
                        onChange={(e) => setEditAbout({ ...editAbout, flashSaleActive: e.target.checked })}
                        className="sr-only peer"
                      />
                      <div className="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[8px] after:right-[16px] peer-checked:after:right-[4px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-rose-500"></div>
                    </label>
                  </div>

                  {/* One-Click Ready-made Banner Templates */}
                  <div className="space-y-2">
                    <span className="text-[11px] font-mono font-bold text-cyan-300 flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                      QUICK BANNER TEMPLATES (এক ক্লিকে রেডিমেড ব্যানার সেট করুন):
                    </span>
                    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 text-xs font-mono">
                      {[
                        {
                          name: '🔥 Flash Sale',
                          theme: 'fire' as const,
                          badge: '🔥 20% OFF FLASH SALE',
                          title: '⚡ Limited Time Flash Sale is Live on all Tech Gadgets!',
                          subtitle: 'Order before timer expires to claim special discounts.',
                          btnText: 'SHOP NOW (ছাড় নিন)',
                          percent: 20,
                          days: 3
                        },
                        {
                          name: '🎁 Eid / Puja',
                          theme: 'emerald' as const,
                          badge: '🎁 FESTIVAL SPECIAL DEAL',
                          title: '🌙 Eid & Festive Mega Tech Discounts across Bangladesh!',
                          subtitle: 'Enjoy instant flat discount & fast home delivery.',
                          btnText: 'EXPLORE OFFERS',
                          percent: 25,
                          days: 7
                        },
                        {
                          name: '⚡ Cyber Tech',
                          theme: 'cyber' as const,
                          badge: '⚡ NEW TECH LAUNCH',
                          title: '🚀 Next-Gen Lewra Spatial Core HUD & Devices Now Available',
                          subtitle: 'Pre-order now with exclusive warranty package.',
                          btnText: 'GET STARTED',
                          percent: 15,
                          days: 15
                        },
                        {
                          name: '✨ Gold Luxury',
                          theme: 'gold' as const,
                          badge: '✨ VIP EXCLUSIVE OFFER',
                          title: '👑 Premium Hardware & Enterprise Solution Mega Discount',
                          subtitle: 'Special privileges for our early hardware adopters.',
                          btnText: 'CLAIM VIP ACCESS',
                          percent: 30,
                          days: 30
                        },
                        {
                          name: '💎 Royal Purple',
                          theme: 'purple' as const,
                          badge: '💎 SPECIAL WEEKEND DROP',
                          title: '🔮 Weekend Tech Bonanza - Save big on Developer Kits!',
                          subtitle: 'Grab top hardware kits at unbeatable prices.',
                          btnText: 'ORDER NOW',
                          percent: 18,
                          days: 2
                        },
                        {
                          name: '📢 Announcement',
                          theme: 'midnight' as const,
                          badge: '📢 STORE NOTICE',
                          title: '📦 Official Store Hardware Delivery & Setup Hotline Active',
                          subtitle: 'Need help? Contact support via WhatsApp anytime.',
                          btnText: 'VIEW PRODUCTS',
                          percent: 0,
                          days: 0
                        }
                      ].map((tpl, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => {
                            setEditAbout({
                              ...editAbout,
                              flashSaleActive: true,
                              flashSaleTheme: tpl.theme,
                              flashSaleBadgeText: tpl.badge,
                              flashSaleTitle: tpl.title,
                              flashSaleSubtitle: tpl.subtitle,
                              flashSaleButtonText: tpl.btnText,
                              flashSaleDiscountPercent: tpl.percent > 0 ? tpl.percent : undefined,
                              flashSaleValidUntil: tpl.days > 0 ? getExpiryDateFromDays(tpl.days) : ''
                            });
                          }}
                          className="p-2 rounded-xl bg-slate-950/80 border border-slate-700/80 hover:border-amber-400 hover:bg-slate-900 text-slate-200 text-left transition-all group"
                        >
                          <div className="font-bold text-amber-300 group-hover:text-amber-200">{tpl.name}</div>
                          <div className="text-[10px] text-slate-400 truncate mt-0.5">{tpl.theme} theme</div>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Real-time Interactive Live Preview Box */}
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs font-mono">
                      <span className="text-slate-300 font-bold flex items-center gap-1.5">
                        <Eye className="w-3.5 h-3.5 text-cyan-400" />
                        LIVE BANNER PREVIEW (ওয়েবসাইটে যেমন দেখাবে):
                      </span>
                      <span className="text-[10px] text-amber-400/90 font-mono">
                        Theme: {editAbout.flashSaleTheme || 'fire'}
                      </span>
                    </div>

                    <div className="rounded-xl overflow-hidden border border-slate-700 shadow-inner bg-slate-950">
                      <div
                        className={`py-2.5 px-3 sm:px-5 flex flex-col md:flex-row items-center justify-between gap-2.5 text-xs text-white ${
                          editAbout.flashSaleTheme === 'gold'
                            ? 'bg-gradient-to-r from-amber-950 via-yellow-950 to-orange-950'
                            : editAbout.flashSaleTheme === 'cyber'
                            ? 'bg-gradient-to-r from-cyan-950 via-blue-950 to-indigo-950'
                            : editAbout.flashSaleTheme === 'emerald'
                            ? 'bg-gradient-to-r from-emerald-950 via-teal-950 to-slate-900'
                            : editAbout.flashSaleTheme === 'purple'
                            ? 'bg-gradient-to-r from-purple-950 via-fuchsia-950 to-indigo-950'
                            : editAbout.flashSaleTheme === 'sunset'
                            ? 'bg-gradient-to-r from-pink-950 via-rose-950 to-amber-950'
                            : editAbout.flashSaleTheme === 'midnight'
                            ? 'bg-gradient-to-r from-slate-950 via-zinc-900 to-neutral-950'
                            : 'bg-gradient-to-r from-rose-950 via-red-950 to-orange-950'
                        }`}
                        style={
                          editAbout.flashSaleBgImage
                            ? {
                                backgroundImage: `linear-gradient(to right, rgba(10, 10, 20, 0.88), rgba(15, 10, 25, 0.82)), url('${editAbout.flashSaleBgImage}')`,
                                backgroundSize: 'cover',
                                backgroundPosition: 'center'
                              }
                            : undefined
                        }
                      >
                        <div className="flex items-center gap-2 flex-wrap justify-center md:justify-start">
                          <span className="px-2 py-0.5 rounded-full bg-amber-500 text-slate-950 font-extrabold text-[10px] font-mono tracking-wider flex items-center gap-1 uppercase">
                            <Flame className="w-3 h-3 fill-slate-950" />
                            {editAbout.flashSaleBadgeText || (editAbout.flashSaleDiscountPercent ? `${editAbout.flashSaleDiscountPercent}% OFF FLASH SALE` : 'LIMITED DISCOUNT OFFER')}
                          </span>
                          <span className="font-bold text-xs font-['Space_Grotesk'] text-white">
                            {editAbout.flashSaleTitle || 'Special Store Discount Offer is Live!'}
                          </span>
                          {editAbout.flashSaleSubtitle && (
                            <span className="hidden lg:inline text-[11px] text-slate-300 border-l border-slate-700 pl-2">
                              {editAbout.flashSaleSubtitle}
                            </span>
                          )}
                        </div>

                        <div className="flex items-center gap-2.5 shrink-0">
                          {!editAbout.flashSaleHideTimer && (
                            <div className="flex items-center gap-1 text-[10px] font-mono bg-slate-950/80 px-2 py-0.5 rounded-lg border border-slate-700 text-amber-300 font-bold">
                              <Clock className="w-3 h-3 text-amber-400" />
                              <span>ENDS IN: 03d : 12h : 45m : 22s</span>
                            </div>
                          )}
                          {!editAbout.flashSaleHideButton && (
                            <span className="px-2.5 py-1 rounded-lg bg-amber-500 text-slate-950 font-extrabold text-[10px] font-mono flex items-center gap-1 shadow">
                              <Zap className="w-3 h-3 fill-slate-950" />
                              {editAbout.flashSaleButtonText || 'SHOP NOW (ছাড় নিন)'}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Banner Theme Palette Selector */}
                  <div className="space-y-2">
                    <span className="text-xs font-mono font-bold text-slate-200 flex items-center gap-1.5">
                      <Palette className="w-3.5 h-3.5 text-amber-400" />
                      BANNER COLOR THEME (ব্যানারের কালার থিম নির্বাচন করুন):
                    </span>
                    <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2 text-xs font-mono">
                      {[
                        { key: 'fire', label: '🔥 Fire Red', color: 'from-rose-600 to-orange-500' },
                        { key: 'gold', label: '✨ Festive Gold', color: 'from-amber-500 to-yellow-400' },
                        { key: 'cyber', label: '⚡ Cyber Blue', color: 'from-cyan-500 to-blue-500' },
                        { key: 'emerald', label: '🌿 Emerald Green', color: 'from-emerald-500 to-teal-400' },
                        { key: 'purple', label: '💎 Royal Purple', color: 'from-purple-500 to-pink-500' },
                        { key: 'sunset', label: '🌅 Sunset Coral', color: 'from-pink-500 to-amber-400' },
                        { key: 'midnight', label: '🌑 Midnight Dark', color: 'from-slate-700 to-zinc-900' }
                      ].map((th) => (
                        <button
                          key={th.key}
                          type="button"
                          onClick={() => setEditAbout({ ...editAbout, flashSaleTheme: th.key as any })}
                          className={`p-2 rounded-xl border text-center transition-all flex flex-col items-center gap-1.5 ${
                            (editAbout.flashSaleTheme || 'fire') === th.key
                              ? 'bg-slate-900 border-amber-400 text-white font-bold shadow-lg shadow-amber-950/50 scale-105'
                              : 'bg-slate-950/80 border-slate-800 text-slate-400 hover:border-slate-600'
                          }`}
                        >
                          <div className={`w-full h-3 rounded bg-gradient-to-r ${th.color}`} />
                          <span className="text-[11px]">{th.label}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Banner Content Inputs */}
                  <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 pt-2 border-t border-slate-800">
                    <div className="sm:col-span-4">
                      <label className="text-xs font-mono text-slate-200 block mb-1 font-bold">
                        Top Badge Pill Text (ব্যাজের লেখা)
                      </label>
                      <input
                        type="text"
                        value={editAbout.flashSaleBadgeText || ''}
                        onChange={(e) => setEditAbout({ ...editAbout, flashSaleBadgeText: e.target.value })}
                        placeholder="e.g. 🔥 20% OFF FLASH SALE"
                        className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3 py-2 text-xs text-amber-300 font-bold font-mono focus:outline-none focus:border-amber-400"
                      />
                    </div>

                    <div className="sm:col-span-8">
                      <label className="text-xs font-mono text-slate-200 block mb-1 font-bold">
                        Main Headline / Title (ব্যানারের প্রধান শিরোনাম)
                      </label>
                      <input
                        type="text"
                        value={editAbout.flashSaleTitle || ''}
                        onChange={(e) => setEditAbout({ ...editAbout, flashSaleTitle: e.target.value })}
                        placeholder="e.g. ⚡ Flash Discount Sale Live - Up to 20% OFF on All Hardware!"
                        className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-bold focus:outline-none focus:border-amber-400"
                      />
                    </div>

                    <div className="sm:col-span-8">
                      <label className="text-xs font-mono text-slate-200 block mb-1 font-bold">
                        Subtitle / Offer Note (সাবটাইটেল / স্লোগান)
                      </label>
                      <input
                        type="text"
                        value={editAbout.flashSaleSubtitle || ''}
                        onChange={(e) => setEditAbout({ ...editAbout, flashSaleSubtitle: e.target.value })}
                        placeholder="e.g. Limited time promotional campaign. Order before timer runs out."
                        className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-300 focus:outline-none focus:border-amber-400"
                      />
                    </div>

                    <div className="sm:col-span-4">
                      <label className="text-xs font-mono text-slate-200 block mb-1 font-bold">
                        Discount % (ছাড়ের শতকরা হার)
                      </label>
                      <input
                        type="number"
                        min="0"
                        max="100"
                        value={editAbout.flashSaleDiscountPercent ?? ''}
                        onChange={(e) => setEditAbout({ ...editAbout, flashSaleDiscountPercent: e.target.value ? parseInt(e.target.value) : undefined })}
                        placeholder="e.g. 20"
                        className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3 py-2 text-xs text-amber-300 font-mono font-bold focus:outline-none focus:border-amber-400"
                      />
                    </div>
                  </div>

                  {/* Button & Action Link Configuration */}
                  <div className="p-3.5 rounded-xl bg-slate-950/90 border border-slate-800 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-mono font-bold text-amber-300 flex items-center gap-1.5">
                        <Zap className="w-3.5 h-3.5 text-amber-400" />
                        ACTION BUTTON SETTINGS (অ্যাকশন বাটন কাস্টমাইজেশন)
                      </span>
                      <label className="relative inline-flex items-center cursor-pointer gap-2 shrink-0">
                        <span className="text-[11px] font-mono text-slate-300">
                          {editAbout.flashSaleHideButton ? 'Button Hidden' : 'Button Shown'}
                        </span>
                        <input
                          type="checkbox"
                          checked={!editAbout.flashSaleHideButton}
                          onChange={(e) => setEditAbout({ ...editAbout, flashSaleHideButton: !e.target.checked })}
                          className="sr-only peer"
                        />
                        <div className="w-9 h-5 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-amber-500"></div>
                      </label>
                    </div>

                    {!editAbout.flashSaleHideButton && (
                      <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 pt-1 border-t border-slate-800/80">
                        <div className="sm:col-span-4">
                          <label className="text-[11px] font-mono text-slate-300 block mb-1">Button Text (বাটনের লেখা)</label>
                          <input
                            type="text"
                            value={editAbout.flashSaleButtonText || ''}
                            onChange={(e) => setEditAbout({ ...editAbout, flashSaleButtonText: e.target.value })}
                            placeholder="e.g. SHOP NOW (ছাড় নিন)"
                            className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-amber-400"
                          />
                        </div>

                        <div className="sm:col-span-4">
                          <label className="text-[11px] font-mono text-slate-300 block mb-1">Click Action (বাটনে ক্লিক করলে যা হবে)</label>
                          <select
                            value={editAbout.flashSaleButtonAction || 'scroll_products'}
                            onChange={(e) => setEditAbout({ ...editAbout, flashSaleButtonAction: e.target.value as any })}
                            className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-amber-300 focus:outline-none focus:border-amber-400"
                          >
                            <option value="scroll_products">Scroll to Store Products (প্রডাক্ট সেকশনে যাবে)</option>
                            <option value="scroll_pricing">Scroll to Pricing Plans (প্রাইসিং সেকশনে যাবে)</option>
                            <option value="scroll_features">Scroll to Features (ফিচার সেকশনে যাবে)</option>
                            <option value="custom_url">Custom External Link (অন্য কোনো ওয়েবসাইট/লিঙ্ক)</option>
                          </select>
                        </div>

                        {editAbout.flashSaleButtonAction === 'custom_url' && (
                          <div className="sm:col-span-4">
                            <label className="text-[11px] font-mono text-slate-300 block mb-1">Custom Link URL (লিঙ্ক ইউআরএল)</label>
                            <input
                              type="url"
                              value={editAbout.flashSaleButtonUrl || ''}
                              onChange={(e) => setEditAbout({ ...editAbout, flashSaleButtonUrl: e.target.value })}
                              placeholder="https://..."
                              className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-cyan-300 focus:outline-none focus:border-cyan-400"
                            />
                          </div>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Countdown Timer & Duration Controls */}
                  <div className="p-3.5 rounded-xl bg-slate-950/90 border border-slate-800 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-mono font-bold text-amber-300 flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5 text-amber-400" />
                        COUNTDOWN TIMER & EXPIRY DURATION (কাউন্টডাউন টাইমার ও মেয়াদ)
                      </span>
                      <label className="relative inline-flex items-center cursor-pointer gap-2 shrink-0">
                        <span className="text-[11px] font-mono text-slate-300">
                          {editAbout.flashSaleHideTimer ? 'Timer Hidden' : 'Timer Shown'}
                        </span>
                        <input
                          type="checkbox"
                          checked={!editAbout.flashSaleHideTimer}
                          onChange={(e) => setEditAbout({ ...editAbout, flashSaleHideTimer: !e.target.checked })}
                          className="sr-only peer"
                        />
                        <div className="w-9 h-5 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-amber-500"></div>
                      </label>
                    </div>

                    {!editAbout.flashSaleHideTimer && (
                      <div className="space-y-2 pt-1 border-t border-slate-800/80">
                        <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5 text-[11px] font-mono">
                          {[
                            { label: '১ দিন (Flash)', days: 1 },
                            { label: '৩ দিন (Weekend)', days: 3 },
                            { label: '৭ দিন (১ সপ্তাহ)', days: 7 },
                            { label: '১৫ দিন (পক্ষ)', days: 15 },
                            { label: '৩০ দিন (১ মাস)', days: 30 },
                            { label: 'স্থায়ী (No Expiry)', days: 0 }
                          ].map((preset, idx) => (
                            <button
                              key={idx}
                              type="button"
                              onClick={() => {
                                if (preset.days > 0) {
                                  setEditAbout({ ...editAbout, flashSaleValidUntil: getExpiryDateFromDays(preset.days) });
                                } else {
                                  setEditAbout({ ...editAbout, flashSaleValidUntil: '' });
                                }
                              }}
                              className="py-1.5 px-2 rounded-lg bg-slate-900/90 text-slate-300 border border-slate-700 hover:border-amber-400 hover:text-amber-300 font-bold transition-all text-center"
                            >
                              {preset.label}
                            </button>
                          ))}
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                          <div>
                            <label className="text-[11px] font-mono text-slate-300 block mb-1">
                              ক্যাম্পেইন শেষ হওয়ার নির্দিষ্ট তারিখ ও সময় (Expiry Date & Time):
                            </label>
                            <input
                              type="datetime-local"
                              value={editAbout.flashSaleValidUntil ? editAbout.flashSaleValidUntil.slice(0, 16) : ''}
                              onChange={(e) => {
                                setEditAbout({
                                  ...editAbout,
                                  flashSaleValidUntil: e.target.value ? new Date(e.target.value).toISOString() : ''
                                });
                              }}
                              className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-amber-300 font-mono focus:outline-none focus:border-amber-400"
                            />
                          </div>

                          <div className="flex flex-col justify-end">
                            {editAbout.flashSaleValidUntil && getRemainingTime(editAbout.flashSaleValidUntil) && (
                              <div className="p-2 rounded-lg bg-amber-950/40 border border-amber-500/40 text-amber-300 font-mono text-[11px] font-bold flex items-center gap-1.5">
                                <Timer className="w-3.5 h-3.5 text-amber-400" />
                                <span>অফার বাকি: {getRemainingTime(editAbout.flashSaleValidUntil)?.formattedText}</span>
                              </div>
                            )}
                            {!editAbout.flashSaleValidUntil && (
                              <span className="text-[11px] text-slate-400 font-mono italic">
                                ✓ কোনো নির্দিষ্ট মেয়াদ নেই (যতক্ষণ ব্যানার চালু থাকবে নিরবচ্ছিন্ন চলবে)।
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Optional Custom Background Image for Banner */}
                  <div className="p-3.5 rounded-xl bg-slate-950/90 border border-slate-800 space-y-2">
                    <span className="text-xs font-mono font-bold text-slate-200 flex items-center gap-1.5">
                      <ImageIcon className="w-3.5 h-3.5 text-cyan-400" />
                      CUSTOM BANNER BACKGROUND IMAGE (ঐচ্ছিক ব্যাকগ্রাউন্ড ইমেজ):
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-12 gap-2">
                      <input
                        type="url"
                        value={editAbout.flashSaleBgImage || ''}
                        onChange={(e) => setEditAbout({ ...editAbout, flashSaleBgImage: e.target.value })}
                        placeholder="https://images.unsplash.com/... (ব্যানার ছবির লিঙ্ক দিন বা খালি রাখুন)"
                        className="sm:col-span-9 bg-[#070A12] border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-400 font-mono"
                      />
                      {editAbout.flashSaleBgImage && (
                        <button
                          type="button"
                          onClick={() => setEditAbout({ ...editAbout, flashSaleBgImage: '' })}
                          className="sm:col-span-3 py-1.5 px-2.5 rounded-xl bg-rose-500/20 text-rose-300 border border-rose-500/30 text-xs font-mono font-bold hover:bg-rose-500/30"
                        >
                          Remove Image (ছবি মুছুন)
                        </button>
                      )}
                    </div>
                  </div>
                </div>

                {/* Public Website Admin Access Visibility Control */}
                <div className="p-4 rounded-xl bg-purple-950/40 border border-purple-500/40 space-y-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-xs font-bold text-purple-300 font-mono">
                        Hide Admin Panel Button on Public Website (পাবলিক নেভবার থেকে এডমিন বাটন লুকান)
                      </h4>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        সক্রিয় করলে সাধারণ কাস্টমাররা ওয়েবসাইটে কোনো Admin Button দেখতে পাবে না। আপনি ইউআরএলে <code className="text-cyan-300 font-bold">?admin=true</code> বা <code className="text-cyan-300 font-bold">#admin</code> যোগ করে, কীবোর্ডে <code className="text-cyan-300 font-bold">Ctrl+Shift+A</code> চেপে অথবা লোগোতে ৩ বার ক্লিক করে ঢুকতে পারবেন।
                      </p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer shrink-0 ml-3">
                      <input
                        type="checkbox"
                        checked={editAbout.hideAdminButton || false}
                        onChange={(e) => setEditAbout({ ...editAbout, hideAdminButton: e.target.checked })}
                        className="sr-only peer"
                      />
                      <div className="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
                    </label>
                  </div>
                </div>

                {/* Homepage Header & Top Badge Text Configuration */}
                <div className="p-4 rounded-xl bg-slate-950/80 border border-cyan-500/30 space-y-3">
                  <div className="flex items-center gap-2 text-cyan-400 font-bold text-xs font-mono">
                    <Sparkles className="w-4 h-4" />
                    HOMEPAGE HERO HEADER & BADGE (হোমপেজের মূল হেডার ও টপ ব্যাজ সম্পাদনা)
                  </div>

                  <div>
                    <label className="text-xs font-mono text-slate-300 block mb-1 font-bold">
                      Hero Top Badge Text (হেডারের উপরের ছোট পিল ব্যাজ)
                    </label>
                    <input
                      type="text"
                      value={editAbout.heroTopBadgeText || ''}
                      onChange={(e) => setEditAbout({ ...editAbout, heroTopBadgeText: e.target.value })}
                      placeholder="e.g. LEWRA 3.0 SPATIAL CORE RELEASED"
                      className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-cyan-300 font-bold font-mono focus:outline-none focus:border-cyan-400"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-mono text-slate-300 block mb-1 font-bold">
                      Homepage Main Title / Headline (হোমপেজের মূল হেডার/শিরোনাম)
                    </label>
                    <textarea
                      rows={2}
                      value={editAbout.heroTitle || ''}
                      onChange={(e) => setEditAbout({ ...editAbout, heroTitle: e.target.value })}
                      placeholder="e.g. Lewra World Tech & Hardware Ecosystem Platform"
                      className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white font-bold focus:outline-none focus:border-cyan-400 leading-normal"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-mono text-slate-300 block mb-1 font-bold">
                      Homepage Subtitle / Description (হোমপেজের সাবটাইটেল/বিবরণ)
                    </label>
                    <textarea
                      rows={2}
                      value={editAbout.heroSubtitle || ''}
                      onChange={(e) => setEditAbout({ ...editAbout, heroSubtitle: e.target.value })}
                      placeholder="e.g. Discover cutting-edge spatial devices, premium hardware tech..."
                      className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-slate-200 focus:outline-none focus:border-cyan-400 leading-relaxed"
                    />
                  </div>
                </div>

                {/* Lewra World Workspace & Ecosystem Showcase Configuration */}
                <div className="p-4 rounded-xl bg-slate-950/80 border border-purple-500/40 space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="flex items-center gap-2 text-purple-400 font-bold text-xs font-mono">
                      <Sparkles className="w-4 h-4 text-purple-400" />
                      <span>HERO 3D SHOWCASE & WORKSPACE (শোকেস, ওয়ার্কস্পেস ও ইকোসিস্টেম সেটিংস)</span>
                    </div>
                    
                    {/* Master Toggle for Showing/Hiding Entire Showcase */}
                    <label className="relative inline-flex items-center cursor-pointer gap-2 shrink-0">
                      <span className="text-[11px] font-mono font-semibold text-slate-300">
                        {editAbout.hideHeroShowcase ? 'Showcase Hidden (লুকানো)' : 'Showcase Active (দৃশ্যমান)'}
                      </span>
                      <input
                        type="checkbox"
                        checked={!editAbout.hideHeroShowcase}
                        onChange={(e) => setEditAbout({ ...editAbout, hideHeroShowcase: !e.target.checked })}
                        className="sr-only peer"
                      />
                      <div className="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
                    </label>
                  </div>

                  {!editAbout.hideHeroShowcase ? (
                    <div className="space-y-3 pt-2 border-t border-slate-800/80 text-xs font-mono">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        {/* Top Window Bar Title */}
                        <div>
                          <div className="flex items-center justify-between mb-1">
                            <label className="text-slate-300 block">
                              Workspace Bar Title (উইন্ডো বার টেক্সট)
                            </label>
                            <button
                              type="button"
                              onClick={() => setEditAbout({ ...editAbout, hideHeroWorkspaceTitle: !editAbout.hideHeroWorkspaceTitle })}
                              className={`text-[10px] px-2 py-0.5 rounded transition-colors ${editAbout.hideHeroWorkspaceTitle ? 'bg-rose-500/20 text-rose-300' : 'bg-emerald-500/20 text-emerald-300'}`}
                            >
                              {editAbout.hideHeroWorkspaceTitle ? '❌ Hidden (লুকানো)' : '✓ Shown (দৃশ্যমান)'}
                            </button>
                          </div>
                          <input
                            type="text"
                            value={editAbout.heroWorkspaceTitle || ''}
                            onChange={(e) => setEditAbout({ ...editAbout, heroWorkspaceTitle: e.target.value })}
                            placeholder="e.g. Lewra World Workspace"
                            disabled={editAbout.hideHeroWorkspaceTitle}
                            className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-purple-300 font-bold focus:outline-none focus:border-purple-400 disabled:opacity-40"
                          />
                        </div>

                        {/* System Active Status Text */}
                        <div>
                          <div className="flex items-center justify-between mb-1">
                            <label className="text-slate-300 block">
                              Status Badge Text (স্ট্যাটাস ব্যাজ টেক্সট)
                            </label>
                            <button
                              type="button"
                              onClick={() => setEditAbout({ ...editAbout, hideHeroSystemStatus: !editAbout.hideHeroSystemStatus })}
                              className={`text-[10px] px-2 py-0.5 rounded transition-colors ${editAbout.hideHeroSystemStatus ? 'bg-rose-500/20 text-rose-300' : 'bg-emerald-500/20 text-emerald-300'}`}
                            >
                              {editAbout.hideHeroSystemStatus ? '❌ Hidden (লুকানো)' : '✓ Shown (দৃশ্যমান)'}
                            </button>
                          </div>
                          <input
                            type="text"
                            value={editAbout.heroSystemStatus || ''}
                            onChange={(e) => setEditAbout({ ...editAbout, heroSystemStatus: e.target.value })}
                            placeholder="e.g. System Active"
                            disabled={editAbout.hideHeroSystemStatus}
                            className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-cyan-300 font-bold focus:outline-none focus:border-cyan-400 disabled:opacity-40"
                          />
                        </div>
                      </div>

                      {/* Showcase Image URL & Alt */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="text-slate-300 block mb-1">
                            Showcase Image URL (শোকেস 3D ইমেজ লিংক)
                          </label>
                          <input
                            type="text"
                            value={editAbout.heroShowcaseImage || ''}
                            onChange={(e) => setEditAbout({ ...editAbout, heroShowcaseImage: e.target.value })}
                            placeholder="e.g. /src/assets/images/lewra_hero_3d_1785996301280.jpg or https://..."
                            className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-slate-200 focus:outline-none focus:border-purple-400"
                          />
                        </div>

                        <div>
                          <label className="text-slate-300 block mb-1">
                            Showcase Alt / Ecosystem Title (ইমেজ ট্যাগ / ইকোসিস্টেম নাম)
                          </label>
                          <input
                            type="text"
                            value={editAbout.heroShowcaseAlt || ''}
                            onChange={(e) => setEditAbout({ ...editAbout, heroShowcaseAlt: e.target.value })}
                            placeholder="e.g. Lewra World Products & Ecosystem"
                            className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-slate-200 focus:outline-none focus:border-purple-400"
                          />
                        </div>
                      </div>

                      {/* Mini Live Preview Box */}
                      <div className="p-3 bg-slate-900/70 rounded-xl border border-slate-800 space-y-2">
                        <span className="text-[10px] text-slate-400 font-bold block">SHOWCASE PREVIEW (এডমিন লাইভ প্রিভিউ):</span>
                        <div className="rounded-lg overflow-hidden border border-slate-700 bg-slate-950 p-2 space-y-1.5 shadow-md">
                          {(!editAbout.hideHeroWorkspaceTitle || !editAbout.hideHeroSystemStatus) && (
                            <div className="flex items-center justify-between text-[10px] bg-slate-900 px-2 py-1 rounded border border-slate-800">
                              <div className="flex items-center gap-1.5">
                                <span className="w-2 h-2 rounded-full bg-red-500" />
                                <span className="w-2 h-2 rounded-full bg-yellow-500" />
                                <span className="w-2 h-2 rounded-full bg-emerald-500" />
                                {!editAbout.hideHeroWorkspaceTitle && (
                                  <span className="text-slate-200 ml-1 font-semibold">{editAbout.heroWorkspaceTitle || 'Lewra World Workspace'}</span>
                                )}
                              </div>
                              {!editAbout.hideHeroSystemStatus && (
                                <span className="text-cyan-400 flex items-center gap-1 font-semibold">
                                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                                  {editAbout.heroSystemStatus || 'System Active'}
                                </span>
                              )}
                            </div>
                          )}
                          <div className="h-24 bg-slate-900 rounded overflow-hidden relative border border-slate-800/80">
                            <img
                              src={editAbout.heroShowcaseImage || '/src/assets/images/lewra_hero_3d_1785996301280.jpg'}
                              alt={editAbout.heroShowcaseAlt || 'Lewra World Products & Ecosystem'}
                              className="w-full h-full object-cover opacity-85"
                              onError={(e) => {
                                (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&auto=format&fit=crop&q=80';
                              }}
                            />
                            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent flex items-end p-2">
                              <span className="text-[11px] text-cyan-300 font-sans font-bold">{editAbout.heroShowcaseAlt || 'Lewra World Products & Ecosystem'}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <p className="text-[11px] text-amber-400/90 font-mono bg-amber-950/30 p-2.5 rounded-lg border border-amber-500/30">
                      💡 হোমপেজ থেকে "Lewra World Workspace & Ecosystem" শোকেস সেকশনটি সম্পূর্ণ রিমুভ / লুকানো রয়েছে। এটি পুনরায় হোমপেজে যুক্ত করতে উপরের সুইচে ক্লিক করুন।
                    </p>
                  )}
                </div>

                {/* Product Store Section Header Configuration */}
                <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-slate-900 via-[#0a0f1d] to-slate-950 border border-amber-500/40 space-y-4 shadow-xl">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
                    <div className="flex items-center gap-2 text-amber-300 font-bold text-xs font-mono">
                      <ShoppingBag className="w-4 h-4 text-amber-400" />
                      <span>PRODUCT STORE SECTION HEADER (প্রোডাক্ট স্টোর টেক্সট ও শিরোনাম কাস্টমাইজেশন)</span>
                    </div>
                    <button
                      type="submit"
                      className="px-3 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs flex items-center gap-1 transition-all shadow-md self-start sm:self-auto shrink-0"
                    >
                      <Save className="w-3.5 h-3.5" />
                      Save Store Header (সেভ করুন)
                    </button>
                  </div>

                  <p className="text-xs text-slate-400">
                    প্রোডাক্ট স্টোর সেকশনের উপরের ব্যাজ, মূল শিরোনাম (Main Title) এবং সাবটাইটেল/বিবরণ আপনার পছন্দমতো পরিবর্তন করুন।
                  </p>

                  {/* Quick Preset Templates for Store Header */}
                  <div className="space-y-1.5">
                    <span className="text-[11px] font-mono font-bold text-amber-300 flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                      QUICK STORE HEADER TEMPLATES (এক ক্লিকে সাজানো টেমপ্লেট):
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2 text-xs font-mono">
                      {[
                        {
                          name: '🚀 Spatial Tech & Hardware',
                          badge: 'LEWRA HARDWARE & SPATIAL PRODUCTS STORE',
                          title: 'Explore Our Spatial Ecosystem Products',
                          subtitle: 'Order next-gen hardware HUDs, neural edge gateways, and developer kits directly with real-time tracking.'
                        },
                        {
                          name: '⚡ Official Tech Store',
                          badge: 'OFFICIAL CERTIFIED GADGETS & HARDWARE',
                          title: 'Premium Gadgets & Hardware Store',
                          subtitle: 'Authentic tech products with official brand warranty and same-day express shipping.'
                        },
                        {
                          name: '🛍️ Exclusive Tech Deals',
                          badge: 'HOT PICKS & BESTSELLING DEVICES',
                          title: 'Trending Hardware & Innovation Hub',
                          subtitle: 'Get genuine high-performance gear with cash on delivery and easy return policy.'
                        },
                        {
                          name: '🇧🇩 Bangladesh Tech Hub',
                          badge: 'LEWRA WORLD BANGLADESH STORE',
                          title: 'অফিসিয়াল হার্ডওয়্যার ও গ্যাজেট শপ',
                          subtitle: 'সারা বাংলাদেশে হোম ডেলিভারি ও ক্যাশ অন ডেলিভারি সুবিধা সহ জেনুইন প্রোডাক্ট কিনুন।'
                        }
                      ].map((tpl, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => {
                            setEditAbout({
                              ...editAbout,
                              storeBadge: tpl.badge,
                              storeTitle: tpl.title,
                              storeSubtitle: tpl.subtitle
                            });
                          }}
                          className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800 hover:border-amber-400 hover:bg-slate-900 text-left transition-all group"
                        >
                          <div className="font-bold text-amber-300 group-hover:text-amber-200 text-xs">{tpl.name}</div>
                          <div className="text-[10px] text-slate-400 truncate mt-1">{tpl.title}</div>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Real-time Interactive Store Header Preview */}
                  <div className="space-y-1.5">
                    <span className="text-[11px] font-mono font-bold text-cyan-300 flex items-center gap-1.5">
                      <Eye className="w-3.5 h-3.5 text-cyan-400" />
                      LIVE STORE HEADER PREVIEW (ওয়েবসাইটে যেমন দেখাবে):
                    </span>
                    <div className="p-4 rounded-xl bg-black border border-zinc-800 shadow-inner space-y-2">
                      <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-zinc-900 border border-zinc-800 text-zinc-300 text-[11px] font-mono font-semibold uppercase tracking-wider">
                        <ShoppingBag className="w-3 h-3 text-amber-400" />
                        {editAbout.storeBadge || 'LEWRA HARDWARE & SPATIAL PRODUCTS STORE'}
                      </div>
                      <h3 className="text-xl sm:text-2xl font-extrabold text-white font-['Space_Grotesk'] tracking-tight">
                        {editAbout.storeTitle || 'Explore Our Spatial Ecosystem Products'}
                      </h3>
                      <p className="text-zinc-400 text-xs max-w-xl font-sans">
                        {editAbout.storeSubtitle || 'Order next-gen hardware HUDs, neural edge gateways, and developer kits directly with real-time tracking.'}
                      </p>
                    </div>
                  </div>

                  {/* Input Fields */}
                  <div className="space-y-3 pt-2 border-t border-slate-800/80">
                    <div>
                      <label className="text-xs font-mono text-slate-200 block mb-1 font-bold">
                        1. Store Badge Label (স্টোর সেকশনের উপরের ছোট ব্যাজ টেক্সট)
                      </label>
                      <input
                        type="text"
                        value={editAbout.storeBadge || ''}
                        onChange={(e) => setEditAbout({ ...editAbout, storeBadge: e.target.value })}
                        placeholder="e.g. LEWRA HARDWARE & SPATIAL PRODUCTS STORE"
                        className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-amber-300 font-bold focus:outline-none focus:border-amber-400 font-mono"
                      />
                    </div>

                    <div>
                      <label className="text-xs font-mono text-slate-200 block mb-1 font-bold">
                        2. Store Main Title / Heading (স্টোরের প্রধান শিরোনাম / হেডিং) *
                      </label>
                      <input
                        type="text"
                        value={editAbout.storeTitle || ''}
                        onChange={(e) => setEditAbout({ ...editAbout, storeTitle: e.target.value })}
                        placeholder="e.g. Explore Our Spatial Ecosystem Products"
                        className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white font-bold focus:outline-none focus:border-amber-400 font-mono shadow-inner"
                      />
                      <p className="text-[11px] text-slate-400 mt-1">
                        এটি প্রোডাক্ট স্টোরের সবচেয়ে বড় প্রধান শিরোনাম হিসেবে প্রদর্শিত হবে।
                      </p>
                    </div>

                    <div>
                      <label className="text-xs font-mono text-slate-200 block mb-1 font-bold">
                        3. Store Subtitle / Description (স্টোরের সাবটাইটেল বা বিবরণী টেক্সট)
                      </label>
                      <textarea
                        rows={2}
                        value={editAbout.storeSubtitle || ''}
                        onChange={(e) => setEditAbout({ ...editAbout, storeSubtitle: e.target.value })}
                        placeholder="e.g. Order next-gen hardware HUDs, neural edge gateways, and developer kits directly with real-time tracking."
                        className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-amber-400 leading-relaxed font-mono shadow-inner"
                      />
                      <p className="text-[11px] text-slate-400 mt-1">
                        এটি শিরোনামের নিচে বিবরণ বা অফারের নোট হিসেবে প্রদর্শিত হবে।
                      </p>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-mono text-slate-300 block mb-1">Company / Business Name *</label>
                    <input
                      type="text"
                      required
                      value={editAbout.companyName}
                      onChange={(e) => setEditAbout({ ...editAbout, companyName: e.target.value })}
                      placeholder="e.g. Lewra World"
                      className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-mono text-slate-300 block mb-1">Tagline / Subtitle</label>
                    <input
                      type="text"
                      value={editAbout.tagline}
                      onChange={(e) => setEditAbout({ ...editAbout, tagline: e.target.value })}
                      placeholder="e.g. Leading Tech & Hardware Store"
                      className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-mono text-slate-300 block mb-1">Owner / Founder Name *</label>
                    <input
                      type="text"
                      required
                      value={editAbout.ownerName}
                      onChange={(e) => setEditAbout({ ...editAbout, ownerName: e.target.value })}
                      placeholder="Your Name / Founder Name"
                      className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-mono text-slate-300 block mb-1">Owner / Founder Role</label>
                    <input
                      type="text"
                      value={editAbout.ownerRole}
                      onChange={(e) => setEditAbout({ ...editAbout, ownerRole: e.target.value })}
                      placeholder="e.g. Founder & Managing Director"
                      className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs font-mono text-slate-300 block mb-1">About Us Bio / Details (বিস্তারিত বিবরণ) *</label>
                  <textarea
                    rows={4}
                    required
                    value={editAbout.bio}
                    onChange={(e) => setEditAbout({ ...editAbout, bio: e.target.value })}
                    placeholder="Write detailed info about your business, background, mission..."
                    className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-400 leading-relaxed"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="text-xs font-mono text-slate-300 block mb-1">Contact Email *</label>
                    <input
                      type="email"
                      required
                      value={editAbout.email}
                      onChange={(e) => setEditAbout({ ...editAbout, email: e.target.value })}
                      placeholder="email@example.com"
                      className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-mono text-slate-300 block mb-1">Phone Number *</label>
                    <input
                      type="text"
                      required
                      value={editAbout.phone}
                      onChange={(e) => setEditAbout({ ...editAbout, phone: e.target.value })}
                      placeholder="+880 1700-000000"
                      className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-mono text-slate-300 block mb-1">WhatsApp Number</label>
                    <input
                      type="text"
                      value={editAbout.whatsapp || ''}
                      onChange={(e) => setEditAbout({ ...editAbout, whatsapp: e.target.value })}
                      placeholder="+8801700000000"
                      className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-400 font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs font-mono text-slate-300 block mb-1">Office Address *</label>
                  <input
                    type="text"
                    required
                    value={editAbout.address}
                    onChange={(e) => setEditAbout({ ...editAbout, address: e.target.value })}
                    placeholder="e.g. Dhaka, Bangladesh"
                    className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-mono text-slate-300 block mb-1">Facebook Link</label>
                    <input
                      type="text"
                      value={editAbout.facebook || ''}
                      onChange={(e) => setEditAbout({ ...editAbout, facebook: e.target.value })}
                      placeholder="https://facebook.com/..."
                      className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-400 font-mono"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-mono text-slate-300 block mb-1">YouTube Link</label>
                    <input
                      type="text"
                      value={editAbout.youtube || ''}
                      onChange={(e) => setEditAbout({ ...editAbout, youtube: e.target.value })}
                      placeholder="https://youtube.com/..."
                      className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-400 font-mono"
                    />
                  </div>
                </div>

                {/* Platform & Developer Company Options */}
                <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-3">
                  <span className="text-xs font-bold font-mono text-cyan-400 uppercase block">
                    Platform & Developer Company Details (প্ল্যাটফর্ম ও ডেভলপার কোম্পানি অপশন)
                  </span>
                  
                  <div>
                    <label className="text-xs font-mono text-slate-300 block mb-1">Platform Company Name (প্ল্যাটফর্ম কোম্পানি নাম)</label>
                    <input
                      type="text"
                      value={editAbout.platformCompany || ''}
                      onChange={(e) => setEditAbout({ ...editAbout, platformCompany: e.target.value })}
                      placeholder="e.g. Lewra Global Platform Ltd."
                      className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="text-xs font-mono text-slate-300 block mb-1">Developer / Agency Name (ডেভলপার নাম)</label>
                      <input
                        type="text"
                        value={editAbout.developerName || ''}
                        onChange={(e) => setEditAbout({ ...editAbout, developerName: e.target.value })}
                        placeholder="e.g. Lewra Tech Developers"
                        className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                      />
                    </div>

                    <div>
                      <label className="text-xs font-mono text-slate-300 block mb-1">Developer Phone / Contact (ডেভলপার ফোন নম্বর)</label>
                      <input
                        type="text"
                        value={editAbout.developerPhone || ''}
                        onChange={(e) => setEditAbout({ ...editAbout, developerPhone: e.target.value })}
                        placeholder="e.g. +880 1700-112233"
                        className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-400 font-mono"
                      />
                    </div>

                    <div>
                      <label className="text-xs font-mono text-slate-300 block mb-1">Developer Website / Portfolio URL</label>
                      <input
                        type="text"
                        value={editAbout.developerWebsite || ''}
                        onChange={(e) => setEditAbout({ ...editAbout, developerWebsite: e.target.value })}
                        placeholder="https://example.com/developers"
                        className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-400 font-mono"
                      />
                    </div>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 rounded-xl bg-gradient-to-r from-emerald-400 via-cyan-400 to-indigo-500 hover:from-emerald-300 hover:to-indigo-400 text-slate-950 font-extrabold text-xs flex items-center justify-center gap-2 transition-all shadow-lg shadow-cyan-500/20 hover:scale-[1.01]"
                >
                  <Save className="w-4 h-4" />
                  Save All Website Settings, Name & Payment Logos (সকল সেটিংস সেভ করুন)
                </button>
              </form>
            </div>
          )}

          {/* TAB: SUPPORT & SOCIAL HOURS MANAGER (সাপোর্ট ও যোগাযোগ সেটিংস) */}
          {activeTab === 'support' && (
            <div className="max-w-4xl mx-auto space-y-6">
              
              {/* Header Title */}
              <div className="p-6 rounded-2xl bg-gradient-to-r from-emerald-950/60 via-slate-900/90 to-cyan-950/60 border border-emerald-500/30 space-y-2 shadow-xl">
                <div className="flex items-center gap-2.5">
                  <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
                    <Headphones className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-white font-['Space_Grotesk']">
                      Customer Support & Live Communication (কাস্টমার সাপোর্ট ও সময়সূচি)
                    </h3>
                    <p className="text-xs text-slate-300">
                      হোয়াটসঅ্যাপ ও ফেসবুক মেসেঞ্জারে কাস্টমারদের কয়টা থেকে কয়টা পর্যন্ত সাপোর্ট দেওয়া যাবে তা এখান থেকে সেট করুন।
                    </p>
                  </div>
                </div>
              </div>

              {supportSavedMessage && (
                <div className="p-4 rounded-xl bg-emerald-500/20 border border-emerald-500/50 text-emerald-300 text-xs font-mono font-bold flex items-center gap-2 animate-in fade-in">
                  <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0" />
                  <span>সাপোর্ট ও স্টোর সেটিংস সফলভাবে সেভ হয়েছে! (Settings Saved Successfully)</span>
                </div>
              )}

              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  onUpdateAboutInfo(editAbout);
                  setSupportSavedMessage(true);
                  setTimeout(() => setSupportSavedMessage(false), 3000);
                }}
                className="space-y-6"
              >
                {/* 1. WhatsApp Support Settings */}
                <div className="p-6 rounded-2xl bg-slate-900/90 border border-emerald-500/30 space-y-4 shadow-lg">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-800">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-lg bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
                        <MessageCircle className="w-4 h-4" />
                      </div>
                      <span className="font-bold text-white text-sm font-['Space_Grotesk']">
                        1. WhatsApp Customer Support (হোয়াটসঅ্যাপ সাপোর্ট)
                      </span>
                    </div>

                    <label className="flex items-center gap-2 cursor-pointer text-xs font-mono text-emerald-300">
                      <input
                        type="checkbox"
                        checked={editAbout.whatsappEnabled !== false}
                        onChange={(e) => setEditAbout({ ...editAbout, whatsappEnabled: e.target.checked })}
                        className="rounded border-slate-700 text-emerald-500 focus:ring-emerald-400 h-4 w-4 bg-slate-950"
                      />
                      <span>WhatsApp বাটন সক্রিয় রাখুন (Active)</span>
                    </label>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-mono">
                    <div>
                      <label className="text-slate-300 block mb-1 font-bold">WhatsApp Number (হোয়াটসঅ্যাপ নম্বর) *</label>
                      <input
                        type="text"
                        value={editAbout.whatsapp || ''}
                        onChange={(e) => setEditAbout({ ...editAbout, whatsapp: e.target.value })}
                        placeholder="+880 1700-000000"
                        className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-white font-mono focus:outline-none focus:border-emerald-400"
                      />
                      <span className="text-[11px] text-slate-500 block mt-1">
                        দেশের কোড সহ নম্বর লিখুন (যেমন: +8801700000000)
                      </span>
                    </div>

                    <div>
                      <label className="text-slate-300 block mb-1 font-bold">
                        WhatsApp Support Hours (হোয়াটসঅ্যাপে কতক্ষণ সাপোর্ট চালু থাকে) *
                      </label>
                      <input
                        type="text"
                        value={editAbout.whatsappSupportHours || editAbout.supportHours || 'সকাল ১০:০০ AM - রাত ১০:০০ PM'}
                        onChange={(e) => setEditAbout({ ...editAbout, whatsappSupportHours: e.target.value })}
                        placeholder="যেমন: সকাল ১০:০০ AM - রাত ১০:০০ PM (প্রতিদিন)"
                        className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-emerald-300 font-bold focus:outline-none focus:border-emerald-400"
                      />
                      <div className="flex flex-wrap items-center gap-1.5 mt-2">
                        <span className="text-[10px] text-slate-500">Presets:</span>
                        {[
                          'সকাল ১০:০০ AM - রাত ১০:০০ PM',
                          'সকাল ০৯:০০ AM - রাত ১১:০০ PM',
                          '24/7 সবসময় খোলা',
                          'সকাল ১০:০০ AM - সন্ধ্যা ০৮:০০ PM'
                        ].map((preset) => (
                          <button
                            key={preset}
                            type="button"
                            onClick={() => setEditAbout({ ...editAbout, whatsappSupportHours: preset })}
                            className="px-2 py-0.5 rounded-lg bg-slate-950 border border-slate-800 text-[10px] text-emerald-400 hover:border-emerald-500"
                          >
                            {preset}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* 2. Facebook Messenger Support Settings */}
                <div className="p-6 rounded-2xl bg-slate-900/90 border border-cyan-500/30 space-y-4 shadow-lg">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-800">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-lg bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400">
                        <Facebook className="w-4 h-4" />
                      </div>
                      <span className="font-bold text-white text-sm font-['Space_Grotesk']">
                        2. Facebook Messenger Support (মেসেঞ্জার সাপোর্ট)
                      </span>
                    </div>

                    <label className="flex items-center gap-2 cursor-pointer text-xs font-mono text-cyan-300">
                      <input
                        type="checkbox"
                        checked={editAbout.messengerEnabled !== false}
                        onChange={(e) => setEditAbout({ ...editAbout, messengerEnabled: e.target.checked })}
                        className="rounded border-slate-700 text-cyan-500 focus:ring-cyan-400 h-4 w-4 bg-slate-950"
                      />
                      <span>Messenger বাটন সক্রিয় রাখুন (Active)</span>
                    </label>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-mono">
                    <div>
                      <label className="text-slate-300 block mb-1 font-bold">
                        Facebook Page URL / m.me Link (ফেসবুক পেজ লিংক)
                      </label>
                      <input
                        type="text"
                        value={editAbout.facebook || ''}
                        onChange={(e) => setEditAbout({ ...editAbout, facebook: e.target.value })}
                        placeholder="https://facebook.com/yourpage অথবা https://m.me/yourpage"
                        className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-white font-mono focus:outline-none focus:border-cyan-400"
                      />
                      <span className="text-[11px] text-slate-500 block mt-1">
                        কাস্টমার ক্লিক করলে সরাসরি আপনার ফেসবুক পেজ মেসেঞ্জারে চ্যাট খুলবে
                      </span>
                    </div>

                    <div>
                      <label className="text-slate-300 block mb-1 font-bold">
                        Messenger Support Hours (মেসেঞ্জারে কতক্ষণ সাপোর্ট চালু থাকে) *
                      </label>
                      <input
                        type="text"
                        value={editAbout.messengerSupportHours || editAbout.supportHours || 'সকাল ০৯:০০ AM - রাত ১১:০০ PM'}
                        onChange={(e) => setEditAbout({ ...editAbout, messengerSupportHours: e.target.value })}
                        placeholder="যেমন: সকাল ০৯:০০ AM - রাত ১১:০০ PM"
                        className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-cyan-300 font-bold focus:outline-none focus:border-cyan-400"
                      />
                      <div className="flex flex-wrap items-center gap-1.5 mt-2">
                        <span className="text-[10px] text-slate-500">Presets:</span>
                        {[
                          'সকাল ০৯:০০ AM - রাত ১১:০০ PM',
                          'সকাল ১০:০০ AM - রাত ১০:০০ PM',
                          '24/7 সার্বক্ষণিক মেসেজ সাপোর্ট',
                          'সকাল ১০:০০ AM - রাত ১২:০০ AM'
                        ].map((preset) => (
                          <button
                            key={preset}
                            type="button"
                            onClick={() => setEditAbout({ ...editAbout, messengerSupportHours: preset })}
                            className="px-2 py-0.5 rounded-lg bg-slate-950 border border-slate-800 text-[10px] text-cyan-400 hover:border-cyan-500"
                          >
                            {preset}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* 3. Phone & Telegram Support Options */}
                <div className="p-6 rounded-2xl bg-slate-900/90 border border-indigo-500/30 space-y-4 shadow-lg">
                  <div className="flex items-center gap-2.5 pb-3 border-b border-slate-800">
                    <div className="w-8 h-8 rounded-lg bg-indigo-500/20 border border-indigo-500/40 flex items-center justify-center text-indigo-400">
                      <Phone className="w-4 h-4" />
                    </div>
                    <span className="font-bold text-white text-sm font-['Space_Grotesk']">
                      3. Direct Phone Call & Telegram Support (কল ও টেলিগ্রাম সাপোর্ট)
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs font-mono">
                    <div>
                      <label className="text-slate-300 block mb-1 font-bold">Direct Phone Number (সরাসরি কল)</label>
                      <input
                        type="text"
                        value={editAbout.phone || ''}
                        onChange={(e) => setEditAbout({ ...editAbout, phone: e.target.value })}
                        placeholder="+880 1700-000000"
                        className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-white font-mono focus:outline-none focus:border-indigo-400"
                      />
                    </div>

                    <div>
                      <label className="text-slate-300 block mb-1 font-bold">Call Support Hours (কল রিসিভের সময়)</label>
                      <input
                        type="text"
                        value={editAbout.callSupportHours || 'সকাল ১০:০০ AM - সন্ধ্যা ০৮:০০ PM'}
                        onChange={(e) => setEditAbout({ ...editAbout, callSupportHours: e.target.value })}
                        placeholder="e.g. 10:00 AM - 08:00 PM"
                        className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-indigo-300 font-mono focus:outline-none focus:border-indigo-400"
                      />
                    </div>

                    <div>
                      <label className="text-slate-300 block mb-1 font-bold">Telegram Link / Username</label>
                      <input
                        type="text"
                        value={editAbout.telegram || ''}
                        onChange={(e) => setEditAbout({ ...editAbout, telegram: e.target.value })}
                        placeholder="https://t.me/yourchannel"
                        className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-white font-mono focus:outline-none focus:border-indigo-400"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-slate-300 block mb-1 font-bold text-xs font-mono">
                      Offline / Out-of-Hours Notice (সাপোর্ট সময়ের বাইরে কাস্টমারদের জন্য মেসেজ)
                    </label>
                    <input
                      type="text"
                      value={editAbout.supportNotice || 'রাত ১০:০০ টার পর বার্তা পাঠালে পরবর্তী দিন সকাল ১০:০০ টায় রিপ্লাই দেওয়া হবে। জরুরি প্রয়োজনে সরাসরি হোয়াটসঅ্যাপে মেসেজ দিয়ে রাখুন।'}
                      onChange={(e) => setEditAbout({ ...editAbout, supportNotice: e.target.value })}
                      placeholder="অফলাইন নোটিশ..."
                      className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-amber-200 text-xs font-mono focus:outline-none focus:border-amber-400"
                    />
                  </div>
                </div>

                {/* 4. Store Conversion & Promotional Features */}
                <div className="p-6 rounded-2xl bg-slate-900/90 border border-purple-500/30 space-y-4 shadow-lg">
                  <div className="flex items-center gap-2.5 pb-3 border-b border-slate-800">
                    <div className="w-8 h-8 rounded-lg bg-purple-500/20 border border-purple-500/40 flex items-center justify-center text-purple-400">
                      <Sparkles className="w-4 h-4" />
                    </div>
                    <span className="font-bold text-white text-sm font-['Space_Grotesk']">
                      4. Store Promotion & Conversion Boosters (ফ্রি ডেলিভারি ও লাকি স্পিন)
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-mono">
                    <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                      <label className="text-purple-300 font-bold block">
                        Free Delivery Threshold (৳ কত টাকার অর্ডারে ফ্রি ডেলিভারি)
                      </label>
                      <div className="flex items-center gap-2">
                        <input
                          type="number"
                          min="0"
                          value={editAbout.freeDeliveryThreshold ?? 2000}
                          onChange={(e) => setEditAbout({ ...editAbout, freeDeliveryThreshold: Math.max(0, Number(e.target.value)) })}
                          className="w-full bg-[#070A12] border border-purple-500/40 rounded-xl px-3.5 py-2 text-purple-200 font-bold focus:outline-none focus:border-purple-400"
                        />
                        <span className="text-slate-400">BDT</span>
                      </div>
                      <span className="text-[10px] text-slate-500 block">
                        কাস্টমার কার্টে এই পরিমাণের বেশি পণ্য যোগ করলে ডেলিভারি চার্জ সম্পূর্ণ ফ্রি হয়ে যাবে
                      </span>
                    </div>

                    <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                      <div className="flex items-center justify-between">
                        <label className="text-amber-300 font-bold block">
                          Lucky Spin Wheel Feature (লাকি স্পিন হুইল)
                        </label>
                        <input
                          type="checkbox"
                          checked={Boolean(editAbout.enableSpinWheel)}
                          onChange={(e) => setEditAbout({ ...editAbout, enableSpinWheel: e.target.checked })}
                          className="rounded border-slate-700 text-amber-500 focus:ring-amber-400 h-4 w-4 bg-slate-900 cursor-pointer"
                        />
                      </div>
                      <p className="text-[11px] text-slate-400">
                        ওয়েবসাইটে একটি অ্যানিমেটেড লাকি স্পিন ডিসকাউন্ট হুইল সক্রিয় করুন। কাস্টমাররা স্পিন করে ডিসকাউন্ট জিততে পারবে।
                      </p>
                    </div>

                    <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                      <div className="flex items-center justify-between">
                        <label className="text-indigo-300 font-bold block">
                          Keynote Showcase Feature (কিনোট ভিডিও ও ডেমো)
                        </label>
                        <input
                          type="checkbox"
                          checked={Boolean(editAbout.enableKeynote)}
                          onChange={(e) => setEditAbout({ ...editAbout, enableKeynote: e.target.checked })}
                          className="rounded border-slate-700 text-indigo-500 focus:ring-indigo-400 h-4 w-4 bg-slate-900 cursor-pointer"
                        />
                      </div>
                      <p className="text-[11px] text-slate-400">
                        ওয়েবসাইটের হেডার এবং হিরো সেকশনে "Watch Keynote Demo" অপশন প্রদর্শন করুন।
                      </p>
                    </div>
                  </div>
                </div>

                {/* Save Support Button */}
                <button
                  type="submit"
                  className="w-full py-3.5 rounded-xl bg-gradient-to-r from-emerald-400 via-teal-400 to-cyan-500 hover:from-emerald-300 hover:to-cyan-400 text-slate-950 font-extrabold text-xs flex items-center justify-center gap-2 transition-all shadow-lg shadow-emerald-500/20 hover:scale-[1.01]"
                >
                  <Save className="w-4 h-4" />
                  Save Customer Support & Working Hours (সাপোর্টের সময়সূচি সেভ করুন)
                </button>
              </form>
            </div>
          )}

          {/* TAB 5: PROMO & DISCOUNT COUPONS MANAGER */}
          {activeTab === 'coupons' && (
            <div className="max-w-4xl mx-auto space-y-6">
              
              {/* Master Coupon Controls & Monthly Limits Card */}
              <div className="p-6 rounded-2xl bg-gradient-to-r from-amber-950/40 via-slate-900 to-indigo-950/40 border border-amber-500/40 space-y-4 shadow-xl">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-3 border-b border-slate-800">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center">
                      <Tag className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="text-base font-bold text-white font-['Space_Grotesk'] flex items-center gap-2">
                        কুপন কন্ট্রোল ও মাসিক ব্যবহারের নিয়ম (Coupon System Master Settings)
                      </h3>
                      <p className="text-xs text-slate-400">
                        কুপন অপশন অন/অফ করুন এবং প্রতিটি ইউজারের জন্য ১ মাসে ১টি কুপন ব্যবহারের সীমা নিয়ন্ত্রণ করুন।
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      onUpdateAboutInfo(editAbout);
                      alert('কুপন সিস্টেমের সেটিংস সফলভাবে সেভ করা হয়েছে!');
                    }}
                    className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 font-extrabold text-xs font-mono flex items-center gap-1.5 shadow-md shadow-amber-500/20 shrink-0 self-start sm:self-auto"
                  >
                    <Save className="w-4 h-4" />
                    সেটিংস সেভ করুন
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Master Switch */}
                  <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 flex items-center justify-between gap-3">
                    <div>
                      <span className="text-xs font-mono font-bold text-slate-200 block">
                        কুপন অপশন (Storewide Coupons Status)
                      </span>
                      <span className="text-[11px] text-slate-400">
                        {editAbout.enableCoupons !== false ? '✅ বর্তমানে স্টোরে কুপন চালু আছে' : '🛑 বর্তমানে স্টোরে কুপন সম্পূর্ণ বন্ধ আছে'}
                      </span>
                    </div>

                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={editAbout.enableCoupons !== false}
                        onChange={(e) => {
                          const updated = { ...editAbout, enableCoupons: e.target.checked };
                          setEditAbout(updated);
                          onUpdateAboutInfo(updated);
                        }}
                        className="sr-only peer"
                      />
                      <div className="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[4px] after:left-[4px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-amber-500"></div>
                    </label>
                  </div>

                  {/* Monthly Limit per User */}
                  <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-mono font-bold text-slate-200">
                        প্রতি ইউজার প্রতি মাসে কুপন সীমা:
                      </span>
                      <span className="text-xs font-mono font-bold text-amber-400 px-2 py-0.5 rounded bg-amber-500/10 border border-amber-500/30">
                        {editAbout.maxCouponsPerUserPerMonth ?? 1} বার / মাস
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      {[1, 2, 3, 5].map((num) => (
                        <button
                          key={num}
                          type="button"
                          onClick={() => {
                            const updated = { ...editAbout, maxCouponsPerUserPerMonth: num };
                            setEditAbout(updated);
                            onUpdateAboutInfo(updated);
                          }}
                          className={`flex-1 py-1.5 rounded-lg text-xs font-mono font-bold border transition-all ${
                            (editAbout.maxCouponsPerUserPerMonth ?? 1) === num
                              ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-md'
                              : 'bg-slate-900 text-slate-300 border-slate-700 hover:border-slate-500'
                          }`}
                        >
                          {num === 1 ? '১ বার (ডিফল্ট)' : `${num} বার`}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Create New Coupon Form */}
              <div className="p-6 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-4">
                <div>
                  <h3 className="text-lg font-bold text-white font-['Space_Grotesk'] flex items-center gap-2">
                    <Tag className="w-5 h-5 text-amber-400" />
                    Create Discount Coupon Code (ডিসকাউন্ট কুপন তৈরি ও মেয়াদ নির্ধারণ করুন)
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    কাস্টমাররা চেকআউট করার সময় এই কুপন কোড ব্যবহার করে ছাড় পাবে। আপনি কুপনটি কতদিন কার্যকর থাকবে তাও নির্ধারণ করতে পারেন।
                  </p>
                </div>

                <form onSubmit={handleAddCoupon} className="space-y-3">
                  <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-end">
                    <div className="sm:col-span-4">
                      <label className="text-xs font-mono text-slate-300 block mb-1 font-bold">Coupon Code (কুপন কোড) *</label>
                      <input
                        type="text"
                        required
                        value={newCouponCode}
                        onChange={(e) => setNewCouponCode(e.target.value)}
                        placeholder="e.g. SPECIAL20"
                        className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white uppercase font-mono focus:outline-none focus:border-amber-400 font-bold"
                      />
                    </div>

                    <div className="sm:col-span-3">
                      <label className="text-xs font-mono text-slate-300 block mb-1 font-bold">Discount Type (টাইপ)</label>
                      <select
                        value={newCouponType}
                        onChange={(e) => setNewCouponType(e.target.value as 'percent' | 'bdt')}
                        className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                      >
                        <option value="percent">Percentage (% ছাড়)</option>
                        <option value="bdt">Flat BDT (৳ টাকা ছাড়)</option>
                      </select>
                    </div>

                    <div className="sm:col-span-3">
                      <label className="text-xs font-mono text-slate-300 block mb-1 font-bold">Discount Amount *</label>
                      <input
                        type="number"
                        required
                        min="1"
                        value={newCouponValue}
                        onChange={(e) => setNewCouponValue(e.target.value)}
                        placeholder={newCouponType === 'percent' ? '20 (% Off)' : '200 (৳ Off)'}
                        className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-amber-300 font-mono font-bold focus:outline-none focus:border-amber-400"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <button
                        type="submit"
                        className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-lg shadow-amber-500/20"
                      >
                        <Plus className="w-4 h-4" />
                        Add Coupon
                      </button>
                    </div>
                  </div>

                  {/* Coupon Duration / Expiry Presets */}
                  <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-mono font-bold text-cyan-300 flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5 text-cyan-400" />
                        COUPON DURATION & VALIDITY (কুপনটির মেয়াদ কতদিন থাকবে)
                      </span>
                    </div>

                    <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5 text-[11px] font-mono">
                      {[
                        { label: '৩ দিন', days: 3, key: '3d' },
                        { label: '৭ দিন', days: 7, key: '7d' },
                        { label: '১৫ দিন', days: 15, key: '15d' },
                        { label: '৩০ দিন', days: 30, key: '30d' },
                        { label: 'Custom Date', days: 0, key: 'custom' },
                        { label: 'স্থায়ী (No Expiry)', days: 0, key: 'always' }
                      ].map((preset) => (
                        <button
                          key={preset.key}
                          type="button"
                          onClick={() => {
                            setNewCouponDuration(preset.key as any);
                            if (preset.days > 0) {
                              setNewCouponValidUntil(getExpiryDateFromDays(preset.days));
                            } else if (preset.key === 'always') {
                              setNewCouponValidUntil('');
                            }
                          }}
                          className={`py-1.5 px-2 rounded-lg border text-center font-bold transition-all ${
                            newCouponDuration === preset.key
                              ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-md shadow-amber-950/60 scale-105'
                              : 'bg-slate-900/90 text-slate-300 border-slate-700 hover:border-slate-500'
                          }`}
                        >
                          {preset.label}
                        </button>
                      ))}
                    </div>

                    {newCouponDuration !== 'always' && (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1 border-t border-slate-800/80">
                        <div>
                          <label className="text-[11px] font-mono text-slate-300 block mb-1">
                            মেয়াদ শেষের নির্দিষ্ট সময় (Expiry Date & Time):
                          </label>
                          <input
                            type="datetime-local"
                            value={newCouponValidUntil ? newCouponValidUntil.slice(0, 16) : ''}
                            onChange={(e) => {
                              setNewCouponValidUntil(e.target.value ? new Date(e.target.value).toISOString() : '');
                              setNewCouponDuration('custom');
                            }}
                            className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-amber-300 font-mono focus:outline-none focus:border-amber-400"
                          />
                        </div>
                        <div>
                          <label className="text-[11px] font-mono text-slate-300 block mb-1">
                            কুপন নোট / ক্যাম্পেইন নাম (ঐচ্ছিক):
                          </label>
                          <input
                            type="text"
                            value={newCouponNote}
                            onChange={(e) => setNewCouponNote(e.target.value)}
                            placeholder="e.g. Flash Weekend Promo"
                            className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-amber-400"
                          />
                        </div>
                      </div>
                    )}
                  </div>
                </form>
              </div>

              {/* Existing Coupons List */}
              <div className="p-6 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-4">
                <h4 className="text-sm font-bold font-mono text-slate-300 uppercase tracking-wider">
                  Active Discount Coupons List ({coupons.length})
                </h4>

                {coupons.length === 0 ? (
                  <p className="text-xs text-slate-500 italic py-4">No coupons created yet.</p>
                ) : (
                  <div className="space-y-3">
                    {coupons.map((coupon) => {
                      const validity = checkCouponValidity(coupon);
                      const remaining = coupon.validUntil ? getRemainingTime(coupon.validUntil) : null;
                      return (
                        <div
                          key={coupon.id}
                          className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                        >
                          <div className="flex items-center gap-3">
                            <div className={`p-2.5 rounded-xl border ${validity.valid ? 'bg-amber-500/10 text-amber-400 border-amber-500/20' : 'bg-rose-500/10 text-rose-400 border-rose-500/20'}`}>
                              <Tag className="w-5 h-5" />
                            </div>
                            <div className="space-y-1">
                              <div className="flex flex-wrap items-center gap-2">
                                <span className="text-base font-bold font-mono text-white tracking-wider">
                                  {coupon.code}
                                </span>
                                <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full font-bold ${
                                  !coupon.active
                                    ? 'bg-slate-800 text-slate-400 border border-slate-700'
                                    : validity.valid
                                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                                    : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                                }`}>
                                  {!coupon.active ? 'INACTIVE' : validity.valid ? 'ACTIVE' : 'EXPIRED'}
                                </span>
                                {coupon.validUntil && (
                                  <span className={`text-[10px] font-mono px-2 py-0.5 rounded border flex items-center gap-1 ${
                                    validity.valid
                                      ? 'bg-cyan-950/60 text-cyan-300 border-cyan-500/30'
                                      : 'bg-rose-950/60 text-rose-300 border-rose-500/30'
                                  }`}>
                                    <Clock className="w-2.5 h-2.5" />
                                    {validity.valid && remaining ? remaining.formattedText : 'মেয়াদ শেষ'}
                                  </span>
                                )}
                                {!coupon.validUntil && (
                                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700">
                                    স্থায়ী (No Expiry)
                                  </span>
                                )}
                              </div>
                              <div className="flex flex-wrap items-center gap-3 text-xs font-mono text-slate-400">
                                <span className="text-amber-300 font-bold">
                                  Discount: {coupon.discountPercent ? `${coupon.discountPercent}% OFF` : `৳${coupon.discountBDT} BDT OFF`}
                                </span>
                                {coupon.note && (
                                  <span className="text-slate-300 italic">
                                    • {coupon.note}
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>

                          <div className="flex items-center gap-2 self-end sm:self-auto">
                            <button
                              type="button"
                              onClick={() => handleToggleCoupon(coupon.id)}
                              className={`px-3 py-1.5 rounded-lg text-xs font-mono font-semibold border transition-all ${
                                coupon.active
                                  ? 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
                                  : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 hover:bg-emerald-500/30'
                              }`}
                            >
                              {coupon.active ? 'Deactivate' : 'Activate'}
                            </button>

                            <button
                              type="button"
                              onClick={() => handleDeleteCoupon(coupon.id)}
                              className="p-2 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 transition-colors"
                              title="Delete Coupon"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

            </div>
          )}

          {/* TAB: REGISTERED CUSTOMERS LIST */}
          {activeTab === 'customers' && (
            <div className="space-y-6">
              
              {/* Header Title & Search */}
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
                    <Users className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-white font-['Space_Grotesk']">
                      Registered Customers List (নিবন্ধিত কাস্টমার তালিকা)
                    </h3>
                    <p className="text-xs text-slate-400">
                      ওয়েবসাইটে জিমেইল দিয়ে খোলা মোট নিবন্ধিত আইডি তালিকা ও কন্ট্রোল প্যানেল
                    </p>
                  </div>
                </div>

                {/* Search Bar */}
                <div className="relative w-full md:w-72">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={customerSearchQuery}
                    onChange={(e) => setCustomerSearchQuery(e.target.value)}
                    placeholder="Search by name or email..."
                    className="w-full bg-[#070A12] border border-slate-700 focus:border-emerald-400 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 font-mono focus:outline-none"
                  />
                  {customerSearchQuery && (
                    <button
                      type="button"
                      onClick={() => setCustomerSearchQuery('')}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>

              {/* Stat Summary Cards Row */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="p-4 rounded-2xl bg-slate-900/90 border border-emerald-500/30 flex items-center gap-4 shadow-lg">
                  <div className="w-12 h-12 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-xl">
                    {users.length}
                  </div>
                  <div>
                    <span className="text-xs font-mono text-slate-400 block">সর্বমোট নিবন্ধিত আইডি</span>
                    <span className="text-lg font-bold text-emerald-400 font-mono">{users.length} জন কাস্টমার</span>
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-slate-900/90 border border-cyan-500/30 flex items-center gap-4 shadow-lg">
                  <div className="w-12 h-12 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center font-bold text-xl">
                    {users.filter(u => orders.some(o => o.customerEmail.toLowerCase() === u.email.toLowerCase())).length}
                  </div>
                  <div>
                    <span className="text-xs font-mono text-slate-400 block">অর্ডারকারী কাস্টমার</span>
                    <span className="text-lg font-bold text-cyan-400 font-mono">
                      {users.filter(u => orders.some(o => o.customerEmail.toLowerCase() === u.email.toLowerCase())).length} জন
                    </span>
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-slate-900/90 border border-purple-500/30 flex items-center gap-4 shadow-lg">
                  <div className="w-12 h-12 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center font-bold text-xl">
                    <ShoppingBag className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs font-mono text-slate-400 block">কাস্টমারদের মোট অর্ডার মূল্য</span>
                    <span className="text-lg font-bold text-purple-300 font-mono">
                      ৳{users.reduce((sum, u) => {
                        const uOrders = orders.filter(o => o.customerEmail.toLowerCase() === u.email.toLowerCase());
                        return sum + uOrders.reduce((s, o) => s + o.totalAmount, 0);
                      }, 0).toLocaleString()}
                    </span>
                  </div>
                </div>
              </div>

              {/* Customers Cards Grid */}
              {users.length === 0 ? (
                <div className="text-center py-16 px-4 rounded-2xl bg-slate-900/50 border border-slate-800 space-y-3">
                  <Users className="w-10 h-10 text-slate-600 mx-auto" />
                  <p className="text-xs text-slate-400">No registered customer accounts found yet.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {users
                    .filter(u => {
                      const q = customerSearchQuery.trim().toLowerCase();
                      return !q || u.name.toLowerCase().includes(q) || u.email.toLowerCase().includes(q);
                    })
                    .map((user) => {
                      const userOrdersList = orders.filter(o => o.customerEmail.toLowerCase() === user.email.toLowerCase());
                      const totalMoneySpent = userOrdersList.reduce((sum, o) => sum + o.totalAmount, 0);

                      return (
                        <div key={user.id} className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-emerald-500/40 transition-all space-y-4 shadow-lg">
                          
                          {/* User Info Header */}
                          <div className="flex items-start justify-between gap-3 pb-3 border-b border-slate-800">
                            <div className="flex items-center gap-3">
                              {user.avatar ? (
                                <img
                                  src={user.avatar}
                                  alt={user.name}
                                  referrerPolicy="no-referrer"
                                  className="w-11 h-11 rounded-2xl object-cover border-2 border-emerald-400/80 shadow-md bg-slate-950"
                                />
                              ) : (
                                <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-emerald-400 to-teal-600 text-slate-950 font-bold font-mono text-base flex items-center justify-center shadow-md">
                                  {user.name.slice(0, 2).toUpperCase()}
                                </div>
                              )}
                              <div>
                                <h4 className="text-sm font-bold text-white flex items-center gap-2">
                                  {user.name}
                                </h4>
                                <p className="text-xs text-emerald-400 font-mono flex items-center gap-1 mt-0.5">
                                  <Mail className="w-3 h-3 text-emerald-500 shrink-0" />
                                  {user.email}
                                </p>
                              </div>
                            </div>

                            <span className="px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-mono font-bold whitespace-nowrap">
                              Gmail Verified ID
                            </span>
                          </div>

                          {/* Stats Row */}
                          <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                            <div className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800">
                              <span className="text-slate-400 block text-[10px]">Total Orders Placed</span>
                              <span className="text-cyan-300 font-bold text-sm">{userOrdersList.length} Orders</span>
                            </div>
                            <div className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800">
                              <span className="text-slate-400 block text-[10px]">Total Spent Amount</span>
                              <span className="text-emerald-400 font-bold text-sm">৳{totalMoneySpent} BDT</span>
                            </div>
                          </div>

                          {/* Account Meta */}
                          <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 pt-1">
                            <span>Joined: {new Date(user.createdAt).toLocaleDateString()}</span>
                            {user.phone && <span>Phone: {user.phone}</span>}
                          </div>

                          {/* Order History Summary for this customer */}
                          {userOrdersList.length > 0 && (
                            <div className="pt-2 border-t border-slate-800/80 space-y-2">
                              <span className="text-[11px] font-mono text-slate-300 font-bold block">
                                Customer Orders History ({userOrdersList.length}):
                              </span>
                              <div className="space-y-2 max-h-48 overflow-y-auto custom-scrollbar pr-1">
                                {userOrdersList.map(ord => (
                                  <div key={ord.id} className="p-2.5 rounded-xl bg-slate-950 border border-slate-800/80 flex items-center justify-between text-xs font-mono">
                                    <div>
                                      <span className="font-bold text-cyan-400">{ord.id}</span>
                                      <span className="text-slate-500 mx-1.5">•</span>
                                      <span className="text-slate-300">৳{ord.totalAmount}</span>
                                    </div>
                                    <div className="flex items-center gap-2">
                                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                        ord.status === 'Completed' ? 'bg-emerald-500/20 text-emerald-300' :
                                        ord.status === 'Cancelled' ? 'bg-rose-500/20 text-rose-300' :
                                        'bg-amber-500/20 text-amber-300'
                                      }`}>
                                        {ord.status}
                                      </span>
                                      <button
                                        type="button"
                                        onClick={() => setViewingOrderReceipt(ord)}
                                        className="p-1 rounded bg-cyan-500/20 text-cyan-300 hover:bg-cyan-500/30"
                                        title="View Receipt"
                                      >
                                        <Receipt className="w-3.5 h-3.5" />
                                      </button>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}

                          {/* Customer Actions & ID Footer */}
                          {deletingUserId === user.id ? (
                            <div className="pt-3 border-t border-rose-500/40 bg-rose-950/40 p-3 rounded-xl space-y-2 animate-in fade-in">
                              <div className="flex items-center gap-1.5 text-rose-300 font-bold text-xs font-mono">
                                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                                <span>কাস্টমার আইডি ডিলেট করার কনফার্মেশন:</span>
                              </div>
                              <p className="text-[11px] text-slate-300 font-mono">
                                আপনি কি সত্যি <strong className="text-white">"{user.name}"</strong> ({user.email}) এর একাউন্ট আইডিটি স্থায়ীভাবে ডিলেট করে দিতে চান?
                              </p>
                              <div className="flex items-center justify-end gap-2 pt-1">
                                <button
                                  type="button"
                                  onClick={() => setDeletingUserId(null)}
                                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-mono"
                                >
                                  বাতিল (Cancel)
                                </button>
                                {onDeleteUser && (
                                  <button
                                    type="button"
                                    onClick={() => {
                                      onDeleteUser(user.id);
                                      setDeletingUserId(null);
                                    }}
                                    className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-mono font-bold flex items-center gap-1 shadow-md"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                    হ্যাঁ, আইডি ডিলেট করুন
                                  </button>
                                )}
                              </div>
                            </div>
                          ) : (
                            <div className="pt-3 border-t border-slate-800 flex items-center justify-between gap-2">
                              <div className="text-[10px] font-mono text-slate-500 truncate max-w-[180px]" title={`User ID: ${user.id}`}>
                                ID: {user.id}
                              </div>
                              
                              <div className="flex items-center gap-2">
                                <span className="px-2 py-1 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[10px] font-mono font-bold">
                                  রাখা হয়েছে (Active)
                                </span>
                                {onDeleteUser && (
                                  <button
                                    type="button"
                                    onClick={() => setDeletingUserId(user.id)}
                                    className="px-3 py-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/30 text-xs font-mono font-bold flex items-center gap-1.5 transition-all shadow-sm"
                                    title="Delete Customer ID"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                    <span>আইডি ডিলেট করুন</span>
                                  </button>
                                )}
                              </div>
                            </div>
                          )}

                        </div>
                      );
                    })}
                </div>
              )}

            </div>
          )}

          {/* TAB 6: ADMIN SECURITY & PASSWORD MANAGEMENT */}
          {activeTab === 'security' && (
            <div className="max-w-2xl mx-auto space-y-6">
              
              {/* Active Security Status Card */}
              <div className="p-6 rounded-2xl bg-slate-900/90 border border-purple-500/30 space-y-4 shadow-xl">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-purple-500/20 border border-purple-500/30 flex items-center justify-center text-purple-400">
                      <ShieldCheck className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="text-base font-bold text-white font-['Space_Grotesk']">
                        Admin Security System (সিকিউরিটি স্ট্যাটাস)
                      </h3>
                      <span className="text-xs text-emerald-400 font-mono flex items-center gap-1 mt-0.5">
                        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                        Authenticated & Protected Session Active
                      </span>
                    </div>
                  </div>

                  <button
                    onClick={handleAdminLogout}
                    className="px-3.5 py-2 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 text-xs font-mono font-bold flex items-center gap-1.5 transition-all shadow-md self-start sm:self-auto"
                  >
                    <LogOut className="w-4 h-4" />
                    Logout Now (লগআউট)
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs font-mono">
                  <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                    <span className="text-slate-400 block text-[10px]">AUTH MODE</span>
                    <span className="text-cyan-400 font-bold">Password Encrypted Access</span>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                    <span className="text-slate-400 block text-[10px]">STORAGE LOCATION</span>
                    <span className="text-purple-300 font-bold">Local Storage Vault</span>
                  </div>
                </div>
              </div>

              {/* Change Admin Credentials Form */}
              <div className="p-6 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-4 shadow-xl">
                <div>
                  <h3 className="text-base font-bold text-white font-['Space_Grotesk'] flex items-center gap-2">
                    <Key className="w-5 h-5 text-purple-400" />
                    Change Admin Credentials (এডমিন জিমেইল ও পাসওয়ার্ড পরিবর্তন করুন)
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    এডমিন প্যানেলে নিরাপত্তার জন্য যেকোনো সময় জিমেইল অ্যাড্রেস বা পাসওয়ার্ড পরিবর্তন করতে পারেন।
                  </p>
                </div>

                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs font-mono text-slate-300">
                  <span className="text-slate-400">Current Registered Admin Gmail:</span>
                  <span className="text-purple-300 font-bold">{adminEmail}</span>
                </div>

                <form onSubmit={handleUpdatePassword} className="space-y-4">
                  <div>
                    <label className="text-xs font-mono text-slate-300 block mb-1">
                      Current Admin Password (বর্তমান সিকিউরিটি পাসওয়ার্ড) *
                    </label>
                    <input
                      type="password"
                      required
                      value={currentPassInput}
                      onChange={(e) => setCurrentPassInput(e.target.value)}
                      placeholder="Enter current password..."
                      className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs font-mono text-white focus:outline-none focus:border-purple-400"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-mono text-slate-300 block mb-1">
                      New Admin Gmail (নতুন এডমিন জিমেইল - ঐচ্ছিক)
                    </label>
                    <input
                      type="email"
                      value={newEmailInput}
                      onChange={(e) => setNewEmailInput(e.target.value)}
                      placeholder="Leave blank to keep current admin Gmail..."
                      className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs font-mono text-cyan-300 focus:outline-none focus:border-purple-400"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-xs font-mono text-slate-300 block mb-1">
                        New Password (নতুন পাসওয়ার্ড - ঐচ্ছিক)
                      </label>
                      <input
                        type="password"
                        value={newPassInput}
                        onChange={(e) => setNewPassInput(e.target.value)}
                        placeholder="Leave blank to keep current password..."
                        className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs font-mono text-cyan-300 focus:outline-none focus:border-purple-400"
                      />
                    </div>

                    <div>
                      <label className="text-xs font-mono text-slate-300 block mb-1">
                        Confirm New Password (পাসওয়ার্ড নিশ্চিত করুন)
                      </label>
                      <input
                        type="password"
                        value={confirmPassInput}
                        onChange={(e) => setConfirmPassInput(e.target.value)}
                        placeholder="Confirm new password..."
                        className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs font-mono text-cyan-300 focus:outline-none focus:border-purple-400"
                      />
                    </div>
                  </div>

                  {/* Security Message Toast */}
                  {securityMsg && (
                    <div
                      className={`p-3 rounded-xl border text-xs font-mono flex items-center gap-2 animate-in fade-in ${
                        securityMsg.type === 'success'
                          ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/40'
                          : 'bg-rose-500/15 text-rose-300 border-rose-500/40'
                      }`}
                    >
                      {securityMsg.type === 'success' ? (
                        <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                      ) : (
                        <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                      )}
                      <span>{securityMsg.text}</span>
                    </div>
                  )}

                  <div className="pt-2 flex gap-3">
                    <button
                      type="submit"
                      className="w-full py-3 rounded-xl bg-gradient-to-r from-purple-500 to-indigo-500 hover:from-purple-400 hover:to-indigo-400 text-white font-bold text-xs font-mono uppercase tracking-wider flex items-center justify-center gap-2 transition-all shadow-lg shadow-purple-500/20"
                    >
                      <Lock className="w-4 h-4" />
                      Update Password (পাসওয়ার্ড সেভ করুন)
                    </button>
                  </div>
                </form>
              </div>

            </div>
          )}

          {/* TAB 8: AI STORE ASSISTANT COMMAND CENTER */}
          {activeTab === 'ai_assistant' && (
            <div className="max-w-4xl mx-auto space-y-6 animate-in fade-in">
              
              {/* Header Box */}
              <div className="p-6 rounded-2xl bg-gradient-to-br from-amber-950/40 via-purple-950/40 to-slate-900 border border-amber-500/40 relative overflow-hidden shadow-2xl">
                <div className="absolute top-0 right-0 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
                <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2">
                      <Sparkles className="w-6 h-6 text-amber-400 animate-spin-slow" />
                      <h3 className="text-xl font-extrabold text-white font-['Space_Grotesk'] tracking-wide">
                        AI Store Manager & Command Hub
                      </h3>
                    </div>
                    <p className="text-xs text-amber-200/80 mt-1">
                      পাবলিশ করার পরও আপনার অ্যাডমিন প্যানেল থেকে টেক্সট কমান্ড দিয়ে স্টোরের কুপন, ডেলিভারি চার্জ, নোটিশ, পেমেন্ট নম্বর বা নতুন প্রোডাক্ট সরাসরি আপডেট করুন।
                    </p>
                  </div>

                  <div className="px-3.5 py-1.5 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-300 text-xs font-mono font-bold flex items-center gap-2 shrink-0">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                    <span>AI Engine Active</span>
                  </div>
                </div>
              </div>

              {/* Quick Command Presets */}
              <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
                <span className="text-xs font-bold font-mono text-cyan-400 uppercase tracking-wider block">
                  ⚡ Quick Command Shortcuts (এক ক্লিকে কমান্ড দিন)
                </span>
                
                <div className="flex flex-wrap gap-2 text-xs">
                  <button
                    type="button"
                    onClick={() => handleExecuteAiCommand("Create a 20% discount coupon named EID20")}
                    className="px-3 py-2 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-amber-300 font-mono transition-all flex items-center gap-1.5 hover:scale-[1.02]"
                  >
                    <Tag className="w-3.5 h-3.5" />
                    <span>🏷️ "Create coupon EID20 (20% OFF)"</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleExecuteAiCommand("Set delivery charge inside dhaka 70 BDT and outside dhaka 130 BDT")}
                    className="px-3 py-2 rounded-xl bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/30 text-cyan-300 font-mono transition-all flex items-center gap-1.5 hover:scale-[1.02]"
                  >
                    <Truck className="w-3.5 h-3.5" />
                    <span>🚚 "Delivery charge: Dhaka ৳70, Outside ৳130"</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleExecuteAiCommand("Set notice 'Eid Special Mega Discount running on all products!'")}
                    className="px-3 py-2 rounded-xl bg-purple-500/10 hover:bg-purple-500/20 border border-purple-500/30 text-purple-300 font-mono transition-all flex items-center gap-1.5 hover:scale-[1.02]"
                  >
                    <FileText className="w-3.5 h-3.5" />
                    <span>📢 "Set Eid Offer Notice Banner"</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleExecuteAiCommand("Add bKash and Nagad payment number 01800000000")}
                    className="px-3 py-2 rounded-xl bg-pink-500/10 hover:bg-pink-500/20 border border-pink-500/30 text-pink-300 font-mono transition-all flex items-center gap-1.5 hover:scale-[1.02]"
                  >
                    <Smartphone className="w-3.5 h-3.5" />
                    <span>💳 "Update Payment Gateway Phone Numbers"</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleExecuteAiCommand("Add product Xiaomi Wireless Earbuds price 1200 BDT in Gadgets category")}
                    className="px-3 py-2 rounded-xl bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 font-mono transition-all flex items-center gap-1.5 hover:scale-[1.02]"
                  >
                    <Package className="w-3.5 h-3.5" />
                    <span>📦 "Add Wireless Earbuds (৳1200 BDT)"</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleExecuteAiCommand(aboutInfo.hideHeroShowcase ? "Show workspace showcase on homepage" : "Hide workspace showcase from homepage")}
                    className="px-3 py-2 rounded-xl bg-indigo-500/10 hover:bg-indigo-500/20 border border-indigo-500/30 text-indigo-300 font-mono transition-all flex items-center gap-1.5 hover:scale-[1.02]"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>🖥️ {aboutInfo.hideHeroShowcase ? '"Show Workspace Showcase"' : '"Hide Workspace Showcase"'}</span>
                  </button>
                </div>
              </div>

              {/* Main AI Command Console Box */}
              <div className="p-6 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-4">
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    handleExecuteAiCommand();
                  }}
                  className="space-y-3"
                >
                  <label className="text-xs font-mono text-slate-300 block font-bold flex items-center justify-between">
                    <span>Type Command for AI Store Assistant (এখানে আপনার ইচ্ছা বা নির্দেশনা লিখুন):</span>
                    <span className="text-[10px] text-cyan-400 font-normal">Bangla & English Supported</span>
                  </label>

                  <div className="flex gap-2">
                    <div className="relative flex-1">
                      <input
                        type="text"
                        value={aiInput}
                        onChange={(e) => setAiInput(e.target.value)}
                        placeholder="যেমন: কুপন তৈরি করো SPECIAL10, অথবা ডেলিভারি চার্জ ৮০ টাকা করো..."
                        className="w-full bg-[#070A12] border border-amber-500/40 focus:border-amber-400 rounded-xl pl-4 pr-10 py-3 text-xs font-mono text-amber-200 placeholder:text-slate-500 focus:outline-none transition-colors shadow-inner"
                      />
                      {aiInput && (
                        <button
                          type="button"
                          onClick={() => setAiInput('')}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      )}
                    </div>

                    <button
                      type="submit"
                      disabled={!aiInput.trim() || isAiProcessing}
                      className="px-5 py-3 rounded-xl bg-gradient-to-r from-amber-500 via-purple-500 to-indigo-500 hover:from-amber-400 hover:to-indigo-400 disabled:opacity-50 text-slate-950 font-extrabold text-xs font-mono uppercase tracking-wider flex items-center gap-2 transition-all shadow-lg shrink-0"
                    >
                      {isAiProcessing ? (
                        <>
                          <Clock className="w-4 h-4 animate-spin" />
                          <span>Processing...</span>
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-4 h-4" />
                          <span>Execute Command</span>
                        </>
                      )}
                    </button>
                  </div>
                </form>

                {/* AI Activity Log History */}
                <div className="pt-4 border-t border-slate-800/80 space-y-3">
                  <h4 className="text-xs font-bold font-mono text-slate-300 uppercase tracking-wider flex items-center justify-between">
                    <span>Command Execution Logs (এআই কমান্ড ইতিহাস)</span>
                    <span className="text-[10px] text-slate-500 font-normal">{aiLogs.length} Records</span>
                  </h4>

                  <div className="space-y-2.5 max-h-80 overflow-y-auto pr-1">
                    {aiLogs.map((log) => (
                      <div
                        key={log.id}
                        className="p-3.5 rounded-xl bg-[#070A12] border border-slate-800/80 text-xs font-mono space-y-1.5 animate-in fade-in"
                      >
                        <div className="flex items-center justify-between text-[11px] border-b border-slate-800/60 pb-1">
                          <span className="font-bold text-amber-300 flex items-center gap-1">
                            <Sparkles className="w-3 h-3 text-amber-400" />
                            Command: <span className="text-white font-mono">{log.command}</span>
                          </span>
                          <span className="text-[10px] text-slate-500">{log.timestamp}</span>
                        </div>

                        <p className="text-emerald-300 text-[11px] leading-relaxed pt-0.5">
                          {log.response}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>

              </div>

            </div>
          )}

          {/* TAB: ANALYTICS & REVENUE DASHBOARD */}
          {activeTab === 'analytics' && (
            <AdminAnalytics orders={orders} products={products} users={users} />
          )}

        </div>

      </div>

      {/* MODAL 1: EDIT PRODUCT DETAILS, CATEGORY, PRICE & STOCK */}
      {editingProduct && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in overflow-y-auto max-h-screen py-8">
          <div className="glass-card max-w-lg w-full rounded-2xl border border-slate-700 p-6 relative shadow-2xl text-white my-auto">
            <button
              onClick={() => setEditingProduct(null)}
              className="absolute top-4 right-4 p-1.5 rounded-lg bg-slate-900 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2 mb-4">
              <Package className="w-5 h-5 text-cyan-400" />
              <h3 className="text-base font-bold font-['Space_Grotesk']">
                Edit Product Details ({editingProduct.name})
              </h3>
            </div>

            <form onSubmit={handleSaveProductEdit} className="space-y-4 text-xs font-mono">
              <div>
                <label className="text-slate-300 block mb-1 font-bold">Product Name (পণ্যের নাম) *</label>
                <input
                  type="text"
                  required
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-white font-bold focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-slate-300 block font-bold">Category (ক্যাটাগরি) *</label>
                  <button
                    type="button"
                    onClick={() => setIsEditCategoryCustom(!isEditCategoryCustom)}
                    className="text-[10px] text-cyan-400 hover:text-cyan-300 underline"
                  >
                    {isEditCategoryCustom ? '← Select Existing' : '+ Custom Category'}
                  </button>
                </div>

                {!isEditCategoryCustom ? (
                  <select
                    value={editCategory}
                    onChange={(e) => {
                      if (e.target.value === 'CUSTOM') {
                        setIsEditCategoryCustom(true);
                      } else {
                        setEditCategory(e.target.value);
                      }
                    }}
                    className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-white focus:outline-none focus:border-cyan-400"
                  >
                    {Array.from(
                      new Set([
                        'Spatial Hardware',
                        'AI Hardware',
                        'Developer Tools',
                        'Security',
                        'Software License',
                        'Gadgets',
                        'Accessories',
                        ...products.map((p) => p.category)
                      ])
                    ).map((cat) => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                    <option value="CUSTOM">+ Type New Custom Category</option>
                  </select>
                ) : (
                  <input
                    type="text"
                    required
                    value={editCustomCategory}
                    onChange={(e) => setEditCustomCategory(e.target.value)}
                    placeholder="Enter custom category..."
                    className="w-full bg-[#070A12] border border-cyan-500/50 rounded-xl px-3.5 py-2 text-cyan-300 font-bold focus:outline-none focus:border-cyan-400"
                  />
                )}
              </div>

              {/* Stock Quantity Control */}
              <div className="p-3 rounded-xl bg-slate-950/90 border border-slate-800 space-y-2">
                <label className="text-cyan-300 font-bold block">
                  Stock Quantity (স্টক সংখ্যা / পরিমাণ) *
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    required
                    min="0"
                    value={editStock}
                    onChange={(e) => setEditStock(Math.max(0, Number(e.target.value)))}
                    className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-cyan-300 font-bold focus:outline-none focus:border-cyan-400"
                  />
                  <span className="text-slate-400 shrink-0">Units</span>
                </div>
                <div className="flex flex-wrap items-center gap-1.5 pt-1">
                  <span className="text-[10px] text-slate-400">Quick Preset:</span>
                  <button
                    type="button"
                    onClick={() => setEditStock(0)}
                    className="px-2 py-0.5 rounded bg-rose-500/20 text-rose-300 text-[10px] border border-rose-500/30 hover:bg-rose-500/30"
                  >
                    0 (Stock Out)
                  </button>
                  {[5, 10, 25, 50, 100].map((num) => (
                    <button
                      key={num}
                      type="button"
                      onClick={() => setEditStock(num)}
                      className={`px-2 py-0.5 rounded text-[10px] border ${
                        editStock === num
                          ? 'bg-cyan-500/30 text-cyan-300 border-cyan-400'
                          : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
                      }`}
                    >
                      {num}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-200 block mb-1 font-bold text-xs flex items-center justify-between">
                    <span>Selling Price (বিক্রয় মূল্য ৳) *</span>
                    <span className="text-emerald-400 font-mono text-[10px]">Active Price</span>
                  </label>
                  <input
                    type="number"
                    required
                    min="1"
                    value={editPrice === 0 ? '' : editPrice}
                    onChange={(e) => {
                      const val = e.target.value === '' ? 0 : Number(e.target.value);
                      setEditPrice(val);
                    }}
                    placeholder="e.g. 500"
                    className="w-full bg-[#070A12] border border-cyan-500/50 focus:border-cyan-400 rounded-xl px-3.5 py-2 text-emerald-300 font-bold font-mono text-lg focus:outline-none shadow-inner"
                  />
                  <div className="flex items-center gap-1 mt-1.5 font-mono text-[10px]">
                    <span className="text-slate-500">Quick:</span>
                    {[-500, -100, 100, 500].map(diff => (
                      <button
                        key={`diff-${diff}`}
                        type="button"
                        onClick={() => setEditPrice(Math.max(1, editPrice + diff))}
                        className="px-1.5 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700"
                      >
                        {diff > 0 ? `+${diff}` : diff}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="text-slate-200 block mb-1 font-bold text-xs flex items-center justify-between">
                    <span>Original Price (আগের আসল মূল্য ৳)</span>
                    <span className="text-slate-400 font-mono text-[10px]">Optional</span>
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={editOriginalPrice === 0 ? '' : editOriginalPrice}
                    onChange={(e) => {
                      const val = e.target.value === '' ? 0 : Number(e.target.value);
                      setEditOriginalPrice(val);
                    }}
                    placeholder="e.g. 650 (ঐচ্ছিক)"
                    className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-slate-300 font-bold font-mono text-base focus:outline-none focus:border-cyan-400"
                  />
                  <span className="text-[10px] text-slate-500 font-mono mt-1 block">
                    {editOriginalPrice > editPrice && editPrice > 0 
                      ? `ছাড়: ৳${editOriginalPrice - editPrice} (${Math.round(((editOriginalPrice - editPrice) / editOriginalPrice) * 100)}% OFF)`
                      : 'আসল দাম বেশি হলে ডিসকাউন্ট দেখাবে'}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-200 block mb-1 font-bold text-xs">
                    Discount (%) ছাড়ের শতকরা হার
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="99"
                    value={editDiscountPercent === 0 ? '' : editDiscountPercent}
                    onChange={(e) => {
                      const dVal = e.target.value === '' ? 0 : Number(e.target.value);
                      setEditDiscountPercent(dVal);
                      if (dVal > 0) {
                        const basePrice = editOriginalPrice > 0 ? editOriginalPrice : editPrice;
                        if (editOriginalPrice === 0) setEditOriginalPrice(basePrice);
                        setEditPrice(Math.round(basePrice * (1 - dVal / 100)));
                        if (editDiscountPreset === 'always' && !editDiscountValidUntil) {
                          setEditDiscountPreset('7d');
                          setEditDiscountValidUntil(getExpiryDateFromDays(7));
                        }
                      } else if (dVal === 0 && editOriginalPrice > 0) {
                        setEditPrice(editOriginalPrice);
                      }
                    }}
                    placeholder="e.g. 20"
                    className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-rose-300 font-bold font-mono focus:outline-none focus:border-cyan-400"
                  />
                </div>

                <div>
                  <label className="text-slate-300 block mb-1">Badge Tag</label>
                  <input
                    type="text"
                    value={editTag}
                    onChange={(e) => setEditTag(e.target.value)}
                    placeholder="e.g. Best Seller"
                    className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-white focus:outline-none focus:border-cyan-400"
                  />
                </div>
              </div>

              {/* Discount Duration & Expiry Configuration */}
              {editDiscountPercent > 0 && (
                <div className="p-3.5 rounded-xl bg-gradient-to-r from-rose-950/40 via-purple-950/30 to-slate-900 border border-rose-500/40 space-y-2.5 animate-in fade-in">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono font-bold text-rose-300 flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-rose-400" />
                      DISCOUNT DURATION (ডিসকাউন্ট কত দিন থাকবে)
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        setEditDiscountPercent(0);
                        setEditDiscountValidUntil('');
                        setEditDiscountPreset('always');
                        if (editOriginalPrice > 0) setEditPrice(editOriginalPrice);
                      }}
                      className="text-[10px] font-mono text-rose-400 hover:text-rose-300 underline"
                    >
                      Remove Discount (ছাড় মুছুন)
                    </button>
                  </div>

                  {/* Quick Duration Preset Pills */}
                  <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5 text-[11px] font-mono">
                    {[
                      { label: '১ দিন', days: 1, key: '1d' },
                      { label: '৩ দিন', days: 3, key: '3d' },
                      { label: '৭ দিন', days: 7, key: '7d' },
                      { label: '১৫ দিন', days: 15, key: '15d' },
                      { label: '৩০ দিন', days: 30, key: '30d' },
                      { label: 'স্থায়ী', days: 0, key: 'always' }
                    ].map((preset) => (
                      <button
                        key={preset.key}
                        type="button"
                        onClick={() => {
                          setEditDiscountPreset(preset.key as any);
                          if (preset.days > 0) {
                            setEditDiscountValidUntil(getExpiryDateFromDays(preset.days));
                          } else {
                            setEditDiscountValidUntil('');
                          }
                        }}
                        className={`py-1.5 px-2 rounded-lg border text-center font-bold transition-all ${
                          editDiscountPreset === preset.key
                            ? 'bg-rose-500 text-slate-950 border-rose-400 shadow-md shadow-rose-950/60 scale-105'
                            : 'bg-slate-900/90 text-slate-300 border-slate-700 hover:border-slate-500'
                        }`}
                      >
                        {preset.label}
                      </button>
                    ))}
                  </div>

                  {/* Custom Expiry Date Selector or Status */}
                  {editDiscountPreset !== 'always' && (
                    <div className="space-y-1.5 pt-1 border-t border-slate-800/80">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 text-[11px] font-mono">
                        <label className="text-slate-300">
                          নির্দিষ্ট শেষ তারিখ ও সময় (Offer Expiry Date & Time):
                        </label>
                        {editDiscountValidUntil && getRemainingTime(editDiscountValidUntil) && (
                          <span className="text-amber-300 font-bold">
                            ⏳ {getRemainingTime(editDiscountValidUntil)?.formattedText}
                          </span>
                        )}
                      </div>
                      <input
                        type="datetime-local"
                        value={editDiscountValidUntil ? editDiscountValidUntil.slice(0, 16) : ''}
                        onChange={(e) => {
                          setEditDiscountValidUntil(e.target.value ? new Date(e.target.value).toISOString() : '');
                          setEditDiscountPreset('custom');
                        }}
                        className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-rose-300 font-mono focus:outline-none focus:border-rose-400"
                      />
                    </div>
                  )}

                  {editDiscountPreset === 'always' && (
                    <p className="text-[10px] text-slate-400 font-mono italic">
                      ✓ স্থায়ী ডিসকাউন্ট (No Expiry Date) — যতক্ষণ না আপনি পরিবর্তন করবেন ততক্ষণ এই ছাড় সক্রিয় থাকবে।
                    </p>
                  )}
                </div>
              )}

              {/* Multi-Photo & Multi-Video Media Editor */}
              <div className="space-y-4 p-4 rounded-xl bg-slate-950/90 border border-slate-800">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold text-cyan-300 flex items-center gap-1.5">
                    <ImageIcon className="w-4 h-4 text-cyan-400" />
                    PRODUCT PHOTOS & GALLERY ({1 + editImagesList.length} Pics)
                  </span>
                </div>

                {/* Primary Main Image */}
                <div>
                  <label className="text-slate-300 block mb-1 font-bold">
                    Primary Main Photo (মূল প্রধান ছবি) *
                  </label>
                  <input
                    type="text"
                    value={editImage}
                    onChange={(e) => setEditImage(e.target.value)}
                    placeholder="https://..."
                    className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-white focus:outline-none focus:border-cyan-400 font-mono text-xs"
                  />
                  <div className="flex items-center gap-2 mt-2">
                    <label className="cursor-pointer px-3 py-1.5 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/40 text-cyan-300 text-xs font-mono font-bold flex items-center gap-1.5 transition-all">
                      <Upload className="w-3.5 h-3.5 text-cyan-400" />
                      Upload New Main Pic (নতুন মূল ছবি ফাইল)
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            const reader = new FileReader();
                            reader.onloadend = () => {
                              if (typeof reader.result === 'string') {
                                setEditImage(reader.result);
                              }
                            };
                            reader.readAsDataURL(file);
                          }
                        }}
                      />
                    </label>
                    {editImage && (
                      <img src={editImage} alt="Main Preview" referrerPolicy="no-referrer" className="w-8 h-8 rounded border border-slate-700 object-cover shrink-0" />
                    )}
                  </div>
                </div>

                {/* Additional Gallery Photos */}
                <div className="pt-2 border-t border-slate-800 space-y-2">
                  <label className="text-slate-300 block font-bold">
                    Extra Gallery Photos (অতিরিক্ত ছবি - ২য়, ৩য়, ৭ম বা যত ইচ্ছা)
                  </label>

                  {/* Existing Extra Images Thumbnails */}
                  {editImagesList.length > 0 && (
                    <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 pt-1">
                      {editImagesList.map((imgUrl, idx) => (
                        <div key={idx} className="relative group rounded-lg overflow-hidden border border-slate-700 bg-slate-900 aspect-square">
                          <img src={imgUrl} alt={`Photo ${idx + 2}`} referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                          <button
                            type="button"
                            onClick={() => setEditImagesList(editImagesList.filter((_, i) => i !== idx))}
                            className="absolute top-1 right-1 p-1 rounded-full bg-rose-950/80 text-rose-300 border border-rose-500/40 hover:bg-rose-900 transition-all opacity-90 group-hover:opacity-100"
                            title="Delete photo"
                          >
                            <X className="w-3 h-3" />
                          </button>
                          <span className="absolute bottom-1 left-1 px-1.5 py-0.5 rounded bg-black/70 text-[9px] font-mono text-cyan-300 font-bold">
                            #{idx + 2}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Add Extra Image Inputs */}
                  <div className="flex flex-col sm:flex-row gap-2 pt-1">
                    <input
                      type="text"
                      value={newEditImageInput}
                      onChange={(e) => setNewEditImageInput(e.target.value)}
                      placeholder="Paste extra photo URL..."
                      className="flex-1 bg-[#070A12] border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-400 font-mono"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        if (newEditImageInput.trim()) {
                          setEditImagesList([...editImagesList, newEditImageInput.trim()]);
                          setNewEditImageInput('');
                        }
                      }}
                      className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 font-mono text-xs font-bold shrink-0 border border-slate-700"
                    >
                      + Add URL
                    </button>
                    <label className="cursor-pointer px-3 py-1.5 rounded-xl bg-indigo-500/20 hover:bg-indigo-500/30 border border-indigo-500/40 text-indigo-300 text-xs font-mono font-bold flex items-center justify-center gap-1.5 transition-all shrink-0">
                      <Upload className="w-3.5 h-3.5 text-indigo-400" />
                      + Upload Pics
                      <input
                        type="file"
                        accept="image/*"
                        multiple
                        className="hidden"
                        onChange={(e) => {
                          const files = e.target.files;
                          if (files) {
                            Array.from(files).forEach((file: File) => {
                              const reader = new FileReader();
                              reader.onloadend = () => {
                                if (typeof reader.result === 'string') {
                                  setEditImagesList((prev) => [...prev, reader.result as string]);
                                }
                              };
                              reader.readAsDataURL(file);
                            });
                          }
                        }}
                      />
                    </label>
                  </div>
                </div>

                {/* Product Videos Section */}
                <div className="pt-3 border-t border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono font-bold text-indigo-300 flex items-center gap-1.5">
                      <Play className="w-4 h-4 text-indigo-400 fill-indigo-400" />
                      PRODUCT VIDEOS & DEMOS (ভিডিও ডেমো)
                    </span>
                    <span className="text-[10px] font-mono text-slate-400">
                      Total: {(editVideoUrl ? 1 : 0) + editVideosList.length} Vids
                    </span>
                  </div>

                  {/* Primary Video */}
                  <div>
                    <label className="text-[11px] font-mono text-slate-300 block mb-1 font-bold">
                      Primary Video (১ম ভিডিও - সরাসরি MP4 ফাইল আপলোড বা লিঙ্ক)
                    </label>
                    <input
                      type="text"
                      value={editVideoUrl}
                      onChange={(e) => setEditVideoUrl(e.target.value)}
                      placeholder="Direct video link (.mp4/webm), video URL or choose file below..."
                      className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-400 font-mono"
                    />
                    <div className="flex items-center gap-2 mt-1.5">
                      <label className="cursor-pointer px-3 py-1.5 rounded-xl bg-indigo-500/20 hover:bg-indigo-500/30 border border-indigo-500/40 text-indigo-300 text-xs font-mono font-bold flex items-center gap-1.5 transition-all">
                        <Upload className="w-3.5 h-3.5 text-indigo-400" />
                        Upload Video File (সরাসরি ভিডিও ফাইল আপলোড)
                        <input
                          type="file"
                          accept="video/*"
                          className="hidden"
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) {
                              const reader = new FileReader();
                              reader.onloadend = () => {
                                if (typeof reader.result === 'string') {
                                  setEditVideoUrl(reader.result);
                                }
                              };
                              reader.readAsDataURL(file);
                            }
                          }}
                        />
                      </label>
                      {editVideoUrl && (
                        <span className="text-[10px] font-mono text-emerald-400 flex items-center gap-1">
                          <Check className="w-3 h-3" /> Video Loaded
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Extra Videos List */}
                  {editVideosList.length > 0 && (
                    <div className="space-y-1.5 pt-1">
                      {editVideosList.map((vUrl, idx) => (
                        <div key={idx} className="flex items-center justify-between p-2 rounded-lg bg-slate-900 border border-slate-800 text-xs font-mono text-slate-300">
                          <span className="truncate max-w-[80%] flex items-center gap-1.5 text-indigo-300">
                            <Play className="w-3 h-3 fill-indigo-400 shrink-0" />
                            Video #{idx + 2}: {vUrl.startsWith('data:video') ? 'Uploaded Video File' : vUrl}
                          </span>
                          <button
                            type="button"
                            onClick={() => setEditVideosList(editVideosList.filter((_, i) => i !== idx))}
                            className="p-1 rounded bg-rose-950 text-rose-400 hover:bg-rose-900 border border-rose-500/40"
                            title="Delete video"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Add extra video input (Direct Link & Direct File Upload) */}
                  <div className="flex flex-col sm:flex-row gap-2 pt-1">
                    <input
                      type="text"
                      value={newEditVideoInput}
                      onChange={(e) => setNewEditVideoInput(e.target.value)}
                      placeholder="Add 2nd/3rd video link or direct URL..."
                      className="flex-1 bg-[#070A12] border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-indigo-400 font-mono"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        if (newEditVideoInput.trim()) {
                          setEditVideosList([...editVideosList, newEditVideoInput.trim()]);
                          setNewEditVideoInput('');
                        }
                      }}
                      className="px-3 py-1.5 rounded-xl bg-indigo-600/30 hover:bg-indigo-600/40 border border-indigo-500/40 text-indigo-300 font-mono text-xs font-bold shrink-0"
                    >
                      + Add Link
                    </button>
                    <label className="cursor-pointer px-3 py-1.5 rounded-xl bg-indigo-500/20 hover:bg-indigo-500/30 border border-indigo-500/40 text-indigo-300 text-xs font-mono font-bold flex items-center justify-center gap-1.5 transition-all shrink-0">
                      <Upload className="w-3.5 h-3.5 text-indigo-400" />
                      + Upload Video
                      <input
                        type="file"
                        accept="video/*"
                        multiple
                        className="hidden"
                        onChange={(e) => {
                          const files = e.target.files;
                          if (files) {
                            Array.from(files).forEach((file: File) => {
                              const reader = new FileReader();
                              reader.onloadend = () => {
                                if (typeof reader.result === 'string') {
                                  setEditVideosList((prev) => [...prev, reader.result as string]);
                                }
                              };
                              reader.readAsDataURL(file);
                            });
                          }
                        }}
                      />
                    </label>
                  </div>
                </div>

              </div>

              <div>
                <label className="text-slate-300 block mb-1">Description</label>
                <textarea
                  rows={2}
                  value={editDescription}
                  onChange={(e) => setEditDescription(e.target.value)}
                  className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-white focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 space-y-1">
                <div>Price Preview:</div>
                <div className="flex items-center gap-2">
                  <span className="text-emerald-400 font-bold">৳{editPrice} BDT</span>
                  {editOriginalPrice > editPrice && (
                    <span className="line-through text-slate-500">৳{editOriginalPrice} BDT</span>
                  )}
                  {editDiscountPercent > 0 && (
                    <span className="px-1.5 py-0.5 rounded bg-rose-500/20 text-rose-300 font-bold">
                      -{editDiscountPercent}% OFF
                    </span>
                  )}
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingProduct(null)}
                  className="w-1/2 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="w-1/2 py-2.5 rounded-xl bg-gradient-to-r from-cyan-400 to-indigo-500 text-slate-950 font-bold text-xs"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: CONFIRM ORDER & SET ESTIMATED DELIVERY TIME */}
      {confirmingOrder && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in">
          <div className="glass-card max-w-md w-full rounded-2xl border border-slate-700 p-6 relative shadow-2xl text-white">
            <button
              onClick={() => setConfirmingOrder(null)}
              className="absolute top-4 right-4 p-1.5 rounded-lg bg-slate-900 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2 mb-2 text-emerald-400">
              <CheckCircle className="w-6 h-6" />
              <h3 className="text-base font-bold font-['Space_Grotesk']">
                Confirm Order #{confirmingOrder.id}
              </h3>
            </div>

            <p className="text-xs text-slate-300 mb-4">
              অর্ডারটি কনফার্ম করার সময় গ্রাহকের রসিদে নিশ্চিত করার তারিখ, সময় এবং ডেলিভারি আনুমানিক সময় যুক্ত হয়ে যাবে।
            </p>

            <div className="space-y-4">
              <div>
                <label className="text-xs font-mono text-slate-300 block mb-1">
                  Estimated Delivery Time (পণ্য ডেলিভারির আনুমানিক সময়) *
                </label>
                <input
                  type="text"
                  required
                  value={selectedDeliveryTime}
                  onChange={(e) => setSelectedDeliveryTime(e.target.value)}
                  placeholder="e.g. Dhaka: 24-48 Hours | Outside Dhaka: 3-5 Business Days"
                  className="w-full bg-[#070A12] border border-slate-700 rounded-xl px-3.5 py-2 text-xs font-mono text-cyan-300 focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-xs font-mono space-y-1 text-slate-300">
                <div className="flex justify-between">
                  <span>Customer:</span>
                  <span className="text-white font-bold">{confirmingOrder.customerName}</span>
                </div>
                <div className="flex justify-between">
                  <span>Phone:</span>
                  <span className="text-emerald-300">{confirmingOrder.customerPhone}</span>
                </div>
                <div className="flex justify-between">
                  <span>Total Amount:</span>
                  <span className="text-cyan-300 font-bold">৳{confirmingOrder.totalAmount} BDT</span>
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setConfirmingOrder(null)}
                  className="w-1/2 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => handleConfirmOrderWithDetails(confirmingOrder)}
                  className="w-1/2 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 font-bold text-xs shadow-lg"
                >
                  Confirm Order & Issue Receipt
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 3: VIEW & PRINT CUSTOMER OFFICIAL RECEIPT */}
      <OrderReceiptModal
        order={viewingOrderReceipt}
        onClose={() => setViewingOrderReceipt(null)}
      />

      {/* MODAL 4: VIEW & PRINT COURIER SHIPPING LABEL WITH BARCODE */}
      <ShippingLabelModal
        order={shippingLabelOrder}
        aboutInfo={aboutInfo}
        onClose={() => setShippingLabelOrder(null)}
      />

    </div>
  );
};
