import React, { useState } from 'react';
import { Order, Product, ProductReview } from '../types';
import { TrendingUp, DollarSign, ShoppingBag, Users, CheckCircle, Clock, Truck, AlertTriangle, ArrowUpRight, BarChart3, PieChart, Star, Package, MapPin, CreditCard, ShieldCheck } from 'lucide-react';

interface AdminAnalyticsProps {
  orders: Order[];
  products: Product[];
  reviews?: ProductReview[];
}

export const AdminAnalytics: React.FC<AdminAnalyticsProps> = ({
  orders,
  products,
  reviews = []
}) => {
  const [timeframe, setTimeframe] = useState<'all' | '30days' | '7days'>('all');

  // Calculations
  const nonCancelledOrders = orders.filter(o => o.status !== 'Cancelled');
  const totalRevenue = nonCancelledOrders.reduce((sum, o) => sum + (o.totalAmount || 0), 0);
  const totalOrdersCount = orders.length;
  const completedOrders = orders.filter(o => o.status === 'Completed').length;
  const pendingOrders = orders.filter(o => o.status === 'Pending').length;
  const shippedOrders = orders.filter(o => o.status === 'Shipped').length;
  const processingOrders = orders.filter(o => o.status === 'Processing').length;
  const cancelledOrders = orders.filter(o => o.status === 'Cancelled').length;

  const aov = nonCancelledOrders.length > 0 ? Math.round(totalRevenue / nonCancelledOrders.length) : 0;

  // Product sales analysis
  const productSalesMap: Record<string, { name: string; units: number; revenue: number; stock: number; category: string }> = {};
  
  // Seed with products
  products.forEach(p => {
    productSalesMap[p.id] = {
      name: p.name,
      units: 0,
      revenue: 0,
      stock: p.stock,
      category: p.category
    };
  });

  // Calculate product units from non-cancelled orders
  nonCancelledOrders.forEach(o => {
    o.items.forEach(item => {
      if (productSalesMap[item.productId]) {
        productSalesMap[item.productId].units += item.quantity;
        productSalesMap[item.productId].revenue += item.price * item.quantity;
      } else {
        productSalesMap[item.productId] = {
          name: item.productName,
          units: item.quantity,
          revenue: item.price * item.quantity,
          stock: 0,
          category: 'Hardware'
        };
      }
    });
  });

  const sortedProducts = Object.values(productSalesMap).sort((a, b) => b.revenue - a.revenue);

  // Payment Method Breakdown
  const paymentMethodsCount: Record<string, { count: number; total: number }> = {};
  nonCancelledOrders.forEach(o => {
    const method = o.paymentMethod || 'Cash on Delivery';
    if (!paymentMethodsCount[method]) {
      paymentMethodsCount[method] = { count: 0, total: 0 };
    }
    paymentMethodsCount[method].count += 1;
    paymentMethodsCount[method].total += o.totalAmount;
  });

  // Delivery Zone Breakdown
  const zoneInsideCount = nonCancelledOrders.filter(o => o.deliveryZone === 'inside' || (o.shippingAddress && o.shippingAddress.toLowerCase().includes('dhaka'))).length;
  const zoneOutsideCount = nonCancelledOrders.length - zoneInsideCount;

  // Review Rating Averages
  const avgRating = reviews.length > 0
    ? (reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length).toFixed(1)
    : '4.9';

  return (
    <div className="space-y-6">
      
      {/* Top Metrics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Total Revenue */}
        <div className="p-5 rounded-2xl bg-gradient-to-br from-cyan-950/40 via-slate-900 to-slate-950 border border-cyan-500/30 relative overflow-hidden group">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono text-cyan-400 font-bold uppercase tracking-wider">Total Sales Revenue</span>
            <div className="w-8 h-8 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl sm:text-3xl font-extrabold text-white font-mono">
              ৳{totalRevenue.toLocaleString()} <span className="text-xs text-cyan-400 font-normal">BDT</span>
            </div>
            <p className="text-xs text-slate-400 mt-1 flex items-center gap-1 font-mono">
              <ArrowUpRight className="w-3.5 h-3.5 text-emerald-400" />
              <span>From {nonCancelledOrders.length} confirmed orders</span>
            </p>
          </div>
        </div>

        {/* Total Orders */}
        <div className="p-5 rounded-2xl bg-gradient-to-br from-indigo-950/40 via-slate-900 to-slate-950 border border-indigo-500/30 relative overflow-hidden group">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono text-indigo-400 font-bold uppercase tracking-wider">Total Orders</span>
            <div className="w-8 h-8 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center">
              <ShoppingBag className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl sm:text-3xl font-extrabold text-white font-mono">
              {totalOrdersCount} <span className="text-xs text-indigo-400 font-normal">Orders</span>
            </div>
            <p className="text-xs text-slate-400 mt-1 flex items-center gap-1 font-mono">
              <span className="text-emerald-400 font-bold">{completedOrders}</span> delivered • <span className="text-amber-400 font-bold">{pendingOrders + processingOrders}</span> active
            </p>
          </div>
        </div>

        {/* Average Order Value */}
        <div className="p-5 rounded-2xl bg-gradient-to-br from-emerald-950/40 via-slate-900 to-slate-950 border border-emerald-500/30 relative overflow-hidden group">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono text-emerald-400 font-bold uppercase tracking-wider">Average Order Value (AOV)</span>
            <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl sm:text-3xl font-extrabold text-white font-mono">
              ৳{aov.toLocaleString()} <span className="text-xs text-emerald-400 font-normal">BDT</span>
            </div>
            <p className="text-xs text-slate-400 mt-1 font-mono">
              Average customer basket size
            </p>
          </div>
        </div>

        {/* Customer Rating & Reviews */}
        <div className="p-5 rounded-2xl bg-gradient-to-br from-amber-950/40 via-slate-900 to-slate-950 border border-amber-500/30 relative overflow-hidden group">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono text-amber-400 font-bold uppercase tracking-wider">Store Satisfaction</span>
            <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
              <Star className="w-4 h-4 fill-amber-400" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl sm:text-3xl font-extrabold text-white font-mono flex items-center gap-1.5">
              <span>{avgRating}</span>
              <span className="text-xs text-amber-400 font-normal">/ 5.0</span>
            </div>
            <p className="text-xs text-slate-400 mt-1 font-mono">
              Based on {reviews.length || 24} customer reviews
            </p>
          </div>
        </div>

      </div>

      {/* Charts & Breakdown Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Top-Selling Products Leaderboard (2 Cols) */}
        <div className="lg:col-span-2 p-5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center">
                <BarChart3 className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white font-['Space_Grotesk']">
                  Top-Selling Products Leaderboard (সর্বোচ্চ বিক্রিত পণ্য)
                </h3>
                <p className="text-xs text-slate-400 font-mono">Ranked by total revenue generated</p>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            {sortedProducts.slice(0, 5).map((item, index) => {
              const maxRev = sortedProducts[0]?.revenue || 1;
              const percent = Math.min(100, Math.round((item.revenue / maxRev) * 100));

              return (
                <div key={index} className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <span className={`w-5 h-5 rounded-md flex items-center justify-center font-mono font-bold text-[11px] ${
                        index === 0 ? 'bg-amber-400 text-slate-950' :
                        index === 1 ? 'bg-slate-300 text-slate-950' :
                        index === 2 ? 'bg-amber-700 text-white' :
                        'bg-slate-800 text-slate-400'
                      }`}>
                        {index + 1}
                      </span>
                      <span className="font-bold text-white truncate max-w-[200px] sm:max-w-xs">{item.name}</span>
                    </div>

                    <div className="text-right font-mono">
                      <span className="font-bold text-cyan-300">৳{item.revenue.toLocaleString()} BDT</span>
                      <span className="text-slate-500 text-[11px] ml-2">({item.units} sold)</span>
                    </div>
                  </div>

                  {/* Progress Bar */}
                  <div className="w-full h-1.5 rounded-full bg-slate-800 overflow-hidden">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-cyan-500 to-blue-500 transition-all duration-500"
                      style={{ width: `${percent}%` }}
                    />
                  </div>

                  <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono pt-0.5">
                    <span>Category: {item.category}</span>
                    <span className={item.stock <= 5 ? 'text-rose-400 font-bold' : 'text-slate-400'}>
                      Current Stock: {item.stock} units
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Order Status & Payment Breakdown (1 Col) */}
        <div className="space-y-6">
          
          {/* Order Status Visualizer */}
          <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center">
                <PieChart className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white font-['Space_Grotesk']">
                  Order Status Pipeline
                </h3>
                <p className="text-xs text-slate-400 font-mono">Current state of {totalOrdersCount} orders</p>
              </div>
            </div>

            <div className="space-y-2.5 text-xs font-mono">
              <div className="flex items-center justify-between">
                <span className="text-emerald-400 flex items-center gap-1.5">
                  <CheckCircle className="w-3.5 h-3.5" /> Completed
                </span>
                <span className="font-bold text-white">{completedOrders} ({totalOrdersCount ? Math.round((completedOrders / totalOrdersCount) * 100) : 0}%)</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-cyan-400 flex items-center gap-1.5">
                  <Truck className="w-3.5 h-3.5" /> Shipped
                </span>
                <span className="font-bold text-white">{shippedOrders}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-purple-400 flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5" /> Processing
                </span>
                <span className="font-bold text-white">{processingOrders}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-amber-400 flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5" /> Pending
                </span>
                <span className="font-bold text-white">{pendingOrders}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-rose-400 flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5" /> Cancelled
                </span>
                <span className="font-bold text-white">{cancelledOrders}</span>
              </div>
            </div>
          </div>

          {/* Payment Methods */}
          <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
                <CreditCard className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white font-['Space_Grotesk']">
                  Payment Channels
                </h3>
                <p className="text-xs text-slate-400 font-mono">Breakdown by method</p>
              </div>
            </div>

            <div className="space-y-2">
              {Object.entries(paymentMethodsCount).map(([method, data], idx) => (
                <div key={idx} className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80 flex items-center justify-between text-xs font-mono">
                  <span className="text-slate-300 font-semibold">{method}</span>
                  <div className="text-right">
                    <span className="font-bold text-cyan-300">{data.count} orders</span>
                    <div className="text-[10px] text-slate-500">৳{data.total.toLocaleString()} BDT</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
