export interface FeatureItem {
  id: string;
  title: string;
  category: 'Spatial AI' | 'Autonomous Workflows' | 'Quantum Security' | 'Real-time Analytics';
  description: string;
  iconName: string;
  tag: string;
  accentColor: string;
  metrics: string;
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  company: string;
  avatar: string;
  quote: string;
  rating: number;
  highlight: string;
}

export interface PricingPlan {
  id: string;
  name: string;
  tagline: string;
  monthlyPrice: number;
  annualPrice: number;
  badge?: string;
  popular?: boolean;
  features: string[];
  ctaText: string;
}

export interface FAQItem {
  id: string;
  question: string;
  answer: string;
  category: 'General' | 'API & Integration' | 'Security' | 'Billing';
}

export interface ProductReview {
  id: string;
  productId: string;
  userName: string;
  userEmail?: string;
  rating: number; // 1 to 5
  title?: string;
  comment: string;
  createdAt: string;
  verifiedBuyer?: boolean;
  likes?: number;
  avatar?: string;
}

export interface ProductVariant {
  colors?: { name: string; hex: string; image?: string }[];
  sizes?: string[];
  specs?: string[];
}

export interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  originalPrice?: number;
  discountPercent?: number;
  discountValidUntil?: string;
  description: string;
  image: string;
  images?: string[];
  videoUrl?: string;
  videoUrls?: string[];
  features?: string[];
  specs?: { label: string; value: string }[];
  stock: number;
  tag?: string;
  featured?: boolean;
  variants?: ProductVariant;
  reviewsCount?: number;
  averageRating?: number;
}

export interface AboutInfo {
  companyName: string;
  tagline: string;
  brandOriginCountry?: string; // e.g. Bangladesh, USA, Germany, Japan, etc.
  brandOriginFlag?: string; // e.g. 🇧🇩, 🇺🇸, 🇯🇵, 🇩🇪, etc.
  brandOriginStory?: string;
  brandEstablishedYear?: string;
  logoUrl?: string;
  bkashNumber?: string;
  bkashLogoUrl?: string;
  nagadNumber?: string;
  nagadLogoUrl?: string;
  rocketNumber?: string;
  rocketLogoUrl?: string;
  paymentInstructions?: string;
  enableCashOnDelivery?: boolean;
  enableCardPayment?: boolean;
  hideAdminButton?: boolean;
  deliveryChargeInsideDhaka?: number;
  deliveryChargeOutsideDhaka?: number;
  deliveryNote?: string;
  heroTitle?: string;
  heroSubtitle?: string;
  heroWorkspaceTitle?: string;
  heroSystemStatus?: string;
  heroShowcaseImage?: string;
  heroShowcaseAlt?: string;
  hideHeroShowcase?: boolean;
  hideHeroWorkspaceTitle?: boolean;
  hideHeroSystemStatus?: boolean;
  storeBadge?: string;
  storeTitle?: string;
  storeSubtitle?: string;
  // Banner & Promotion Customization
  flashSaleActive?: boolean;
  flashSaleTitle?: string;
  flashSaleSubtitle?: string;
  flashSaleBadgeText?: string;
  flashSaleDiscountPercent?: number;
  flashSaleValidUntil?: string;
  flashSaleTheme?: 'fire' | 'gold' | 'cyber' | 'emerald' | 'purple' | 'sunset' | 'midnight';
  flashSaleButtonText?: string;
  flashSaleButtonAction?: 'scroll_products' | 'scroll_pricing' | 'scroll_features' | 'custom_url';
  flashSaleButtonUrl?: string;
  flashSaleHideButton?: boolean;
  flashSaleHideTimer?: boolean;
  flashSaleBgImage?: string;
  flashSaleMarquee?: boolean;
  heroTopBadgeText?: string;
  heroTopBadgeLink?: string;
  ownerName: string;
  ownerRole: string;
  bio: string;
  email: string;
  phone: string;
  supportPhoneSecondary?: string;
  address: string;
  whatsapp?: string;
  whatsappMessage?: string;
  facebook?: string;
  facebookMessenger?: string;
  facebookGroup?: string;
  instagram?: string;
  telegram?: string;
  youtube?: string;
  website?: string;
  supportHours?: string;
  whatsappSupportHours?: string;
  messengerSupportHours?: string;
  callSupportHours?: string;
  supportNotice?: string;
  showFloatingSupport?: boolean;
  enableWhatsAppSupport?: boolean;
  enableFacebookSupport?: boolean;
  enableCallSupport?: boolean;
  whatsappEnabled?: boolean;
  messengerEnabled?: boolean;
  developerName?: string;
  developerWebsite?: string;
  developerPhone?: string;
  platformCompany?: string;
  freeDeliveryThreshold?: number;
  enableKeynote?: boolean;
  enableSpinWheel?: boolean;
  enableCoupons?: boolean; // Admin master switch to enable/disable coupons
  maxCouponsPerUserPerMonth?: number; // Coupon usage limit per user per month (default 1)
  lowStockThreshold?: number;
}

export interface Coupon {
  id: string;
  code: string;
  discountPercent?: number;
  discountBDT?: number;
  active: boolean;
  validUntil?: string;
  note?: string;
}

export interface UserAccount {
  id: string;
  name: string;
  email: string;
  password: string;
  createdAt: string;
  phone?: string;
  avatar?: string; // Base64 data URL or external image URL
  rewardPoints?: number;
  referralCode?: string;
  referredBy?: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
  selectedColor?: string;
  selectedSize?: string;
  selectedSpec?: string;
}

export interface OrderItem {
  productId: string;
  productName: string;
  quantity: number;
  price: number;
  selectedColor?: string;
  selectedSize?: string;
  selectedSpec?: string;
}

export interface Order {
  id: string;
  customerName: string;
  customerEmail: string;
  customerPhone?: string;
  shippingAddress?: string;
  items: OrderItem[];
  totalAmount: number;
  paymentMethod?: 'bKash' | 'Nagad' | 'Rocket' | 'Cash on Delivery' | 'Card / Bank Transfer' | string;
  paymentTrxId?: string;
  paymentSenderPhone?: string;
  deliveryZone?: string;
  deliveryCharge?: number;
  advancePaid?: number;
  dueAmount?: number;
  couponCode?: string;
  couponDiscount?: number;
  isManualAdminCoupon?: boolean;
  status: 'Pending' | 'Processing' | 'Shipped' | 'Completed' | 'Cancelled';
  cancelledBy?: 'Admin' | 'Customer';
  refundRequestedNumber?: string;
  customerRefundChoice?: 'original' | 'custom';
  customerRefundMethod?: string;
  refundSubmittedAt?: string;
  adminRefundMethod?: string;
  adminRefundSenderNumber?: string;
  adminRefundTrxId?: string;
  refundStatus?: 'Pending Customer Action' | 'Awaiting Admin Refund' | 'Refund Completed';
  createdAt: string;
  confirmedAt?: string;
  estimatedDeliveryTime?: string;
  trackingCourier?: string;
  trackingNumber?: string;
  notes?: string;
  confirmationMessage?: string;
  customerReceived?: boolean;
  customerReceivedAt?: string;
  customerRating?: number;
  customerReview?: string;
  referredBy?: string;
  rewardPointsEarned?: number;
}
