import { FeatureItem, Testimonial, PricingPlan, FAQItem, Product, Order, AboutInfo, Coupon, UserAccount, ProductReview } from '../types';

export const FEATURES_DATA: FeatureItem[] = [
  {
    id: 'feat-1',
    title: 'Neural Spatial Processing',
    category: 'Spatial AI',
    description: 'Ultra-low latency 3D coordinate processing engine with automated environment mesh synthesis.',
    iconName: 'Cpu',
    tag: '1.2ms Latency',
    accentColor: 'from-cyan-500 to-blue-600',
    metrics: '99.98% Accuracy'
  },
  {
    id: 'feat-2',
    title: 'High-Density Compute Orchestration',
    category: 'Autonomous Workflows',
    description: 'Deploy specialized hardware modules that self-coordinate to execute complex real-time computing tasks.',
    iconName: 'Bot',
    tag: 'Self-healing',
    accentColor: 'from-purple-500 to-pink-600',
    metrics: '10k+ Parallel Nodes'
  },
  {
    id: 'feat-3',
    title: 'Post-Quantum Cryptographic Guard',
    category: 'Quantum Security',
    description: 'Military-grade end-to-end encryption with zero-trust key rotation and hardware enclave isolation.',
    iconName: 'ShieldCheck',
    tag: 'FIPS 140-3 Compliant',
    accentColor: 'from-emerald-400 to-teal-600',
    metrics: 'Zero-Leak SLA'
  },
  {
    id: 'feat-4',
    title: 'Real-time Telemetry Analytics',
    category: 'Real-time Analytics',
    description: 'High-frequency event stream ingestion powering instant predictive heatmaps and latency distribution.',
    iconName: 'Activity',
    tag: '50M Events/sec',
    accentColor: 'from-amber-400 to-orange-600',
    metrics: '<5ms Edge Routing'
  },
  {
    id: 'feat-5',
    title: 'Generative Spatial UI Composer',
    category: 'Spatial AI',
    description: 'Instantly render adaptive glassmorphic spatial interfaces from simple natural language prompts.',
    iconName: 'Layout',
    tag: 'Instant Render',
    accentColor: 'from-indigo-400 to-purple-600',
    metrics: '60 FPS Smooth Rendering'
  },
  {
    id: 'feat-6',
    title: 'Global Mesh Edge Synchronization',
    category: 'Autonomous Workflows',
    description: 'Decentralized distributed state replication across 300+ global edge locations in sub-10 milliseconds.',
    iconName: 'Globe',
    tag: '300+ Edge Nodes',
    accentColor: 'from-blue-400 to-cyan-500',
    metrics: '100% Data Consistency'
  }
];

export const TESTIMONIALS_DATA: Testimonial[] = [
  {
    id: 'test-1',
    name: 'Elena Rostova',
    role: 'Chief Technology Officer',
    company: 'Aetheria Spatial Labs',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    quote: 'Lewra World transformed our spatial intelligence pipeline overnight. The sub-millisecond execution and seamless glass UI integration saved our engineering team 6 months of hard development.',
    rating: 5,
    highlight: 'Reduced latency by 84%'
  },
  {
    id: 'test-2',
    name: 'Dr. Marcus Vance',
    role: 'Head of AI Infrastructure',
    company: 'Nexus Cybernetics',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    quote: 'The hardware computing engine in Lewra World allowed us to deploy 500+ synchronized microservices effortlessly. The quantum security stack gives us total confidence.',
    rating: 5,
    highlight: 'Scaled to 10M daily events'
  },
  {
    id: 'test-3',
    name: 'Sarah Chen',
    role: 'Lead Product Architect',
    company: 'Vanguard Digital',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
    quote: 'The design aesthetic of Lewra World is light years ahead. Our spatial dashboard conversion rates jumped by 142% after switching to Lewra UI components.',
    rating: 5,
    highlight: '+142% conversion boost'
  }
];

export const PRICING_PLANS: PricingPlan[] = [
  {
    id: 'plan-starter',
    name: 'Starter Package',
    tagline: 'Ideal for small businesses and personal projects looking for genuine tech hardware.',
    monthlyPrice: 1500,
    annualPrice: 1200,
    features: [
      'Standard Tech & Hardware Access',
      'Fast Delivery Across Bangladesh',
      'Official Store Warranty',
      'Customer Care & Call Support',
      'Basic Order Tracking'
    ],
    ctaText: 'Select Starter Plan'
  },
  {
    id: 'plan-pro',
    name: 'Pro Tech Ecosystem',
    tagline: 'For power users and businesses requiring high-performance tech hardware.',
    monthlyPrice: 3500,
    annualPrice: 2800,
    popular: true,
    badge: 'Most Popular',
    features: [
      'Priority Hardware Allocation',
      'Express 24-Hour Dhaka Delivery',
      'Extended Store Warranty',
      'Exclusive Discount Coupon Access',
      'Dedicated Account Manager Support',
      '24/7 Phone & WhatsApp Support'
    ],
    ctaText: 'Get Started with Pro'
  },
  {
    id: 'plan-enterprise',
    name: 'Enterprise Bulk Store',
    tagline: 'Custom corporate tech procurement with bulk discounts and zero-latency support.',
    monthlyPrice: 9900,
    annualPrice: 7900,
    features: [
      'Unlimited Wholesale Procurement',
      'Dedicated Custom Stock Allocation',
      'Custom Corporate Invoice & BDT Billing',
      'Direct On-Site Hardware Setup',
      'Dedicated Account Director',
      'Full Genuine Product Guarantee Package'
    ],
    ctaText: 'Contact Store Sales'
  }
];

export const FAQ_DATA: FAQItem[] = [
  {
    id: 'faq-1',
    question: 'What is Lewra World and how does it work?',
    answer: 'Lewra World is a next-generation Spatial AI and Autonomous Workflow platform that allows developers, designers, and enterprises to build immersive, real-time spatial interfaces and AI agent networks with sub-millisecond edge latency.',
    category: 'General'
  },
  {
    id: 'faq-2',
    question: 'How easy is it to integrate Lewra World into an existing React/Next.js codebase?',
    answer: 'Integration takes less than 5 minutes. You can install our npm SDK (`@lewra/spatial-sdk`) or connect via standard REST/WebSocket endpoints. We also provide pre-built Tailwind and React glassmorphism UI components.',
    category: 'API & Integration'
  },
  {
    id: 'faq-3',
    question: 'How does post-quantum cryptography protect user data?',
    answer: 'Lewra World uses lattice-based cryptographic primitives that resist both classical and quantum computer decryption attacks. All agent communication passes through secure hardware enclaves with automated ephemeral key destruction.',
    category: 'Security'
  },
  {
    id: 'faq-4',
    question: 'Can I upgrade or downgrade my subscription plan at any time?',
    answer: 'Yes! You can switch between Monthly and Annual billing or upgrade your plan directly from the Lewra Console. Unused credits automatically roll over to the next billing cycle.',
    category: 'Billing'
  },
  {
    id: 'faq-5',
    question: 'How do I place an order and track my delivery status?',
    answer: 'You can easily browse products, select quantity, enter your delivery address and checkout with bKash, Nagad, Rocket, or Cash on Delivery. Order tracking is available in your account profile.',
    category: 'General'
  }
];

export const PARTNERS = [
  { name: 'NVIDIA', logo: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=120&auto=format&fit=crop&q=80' },
  { name: 'Google Cloud', logo: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=120&auto=format&fit=crop&q=80' },
  { name: 'Microsoft Azure', logo: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=120&auto=format&fit=crop&q=80' },
  { name: 'Apple Vision Labs', logo: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=120&auto=format&fit=crop&q=80' },
  { name: 'Stripe', logo: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=120&auto=format&fit=crop&q=80' },
  { name: 'OpenAI', logo: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=120&auto=format&fit=crop&q=80' }
];

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'prod-1',
    name: 'Lewra Spatial Vision Glass HUD',
    category: 'Spatial Hardware',
    price: 35000,
    originalPrice: 45000,
    discountPercent: 22,
    description: 'Next-gen spatial headset with integrated OLED display and real-time head tracking.',
    image: 'https://images.unsplash.com/photo-1593508512255-86ab42a8e620?w=600&auto=format&fit=crop&q=80',
    videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    stock: 4, // Low stock demo!
    tag: 'Best Seller',
    featured: true,
    averageRating: 4.9,
    reviewsCount: 18,
    variants: {
      colors: [
        { name: 'Obsidian Black', hex: '#18181b' },
        { name: 'Cyber Silver', hex: '#94a3b8' },
        { name: 'Deep Space Blue', hex: '#1e3a8a' }
      ],
      sizes: ['Standard Fit', 'Pro Comfort Cushion'],
      specs: ['128GB Internal', '256GB Spatial Pro']
    }
  },
  {
    id: 'prod-2',
    name: 'Neural Processing Edge Gateway (v3)',
    category: 'Hardware Systems',
    price: 65000,
    originalPrice: 75000,
    discountPercent: 13,
    description: 'Dedicated edge hardware module for high-speed hardware acceleration with 0.8ms latency.',
    image: 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=600&auto=format&fit=crop&q=80',
    videoUrl: '',
    stock: 14,
    tag: 'Quantum Safe',
    featured: true,
    averageRating: 4.8,
    reviewsCount: 12,
    variants: {
      colors: [
        { name: 'Matte Titanium', hex: '#475569' },
        { name: 'Stealth Black', hex: '#0f172a' }
      ],
      specs: ['32GB RAM / 500GB SSD', '64GB RAM / 1TB NVMe']
    }
  },
  {
    id: 'prod-3',
    name: 'Lewra Tech Developer Pro Kit',
    category: 'Developer Tools',
    price: 15000,
    originalPrice: 18000,
    discountPercent: 16,
    description: 'Complete SDK bundle including spatial UI components and official store accessories.',
    image: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=600&auto=format&fit=crop&q=80',
    videoUrl: '',
    stock: 100,
    tag: 'Instant Digital Access',
    featured: false,
    averageRating: 5.0,
    reviewsCount: 24,
    variants: {
      specs: ['Standard Developer Kit', 'Enterprise Full Suite License']
    }
  },
  {
    id: 'prod-4',
    name: 'Quantum Security Hardware Key Enclave',
    category: 'Security',
    price: 22000,
    originalPrice: 26000,
    discountPercent: 15,
    description: 'USB-C / Wireless physical HSM for encrypted key storage and hardware protection.',
    image: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?w=600&auto=format&fit=crop&q=80',
    videoUrl: '',
    stock: 3, // Low stock demo!
    tag: 'FIPS Certified',
    featured: false,
    averageRating: 4.7,
    reviewsCount: 9,
    variants: {
      colors: [
        { name: 'Anodized Silver', hex: '#cbd5e1' },
        { name: 'Rose Gold Enclave', hex: '#fda4af' }
      ],
      specs: ['USB-C + NFC', 'USB-A + Lightning & NFC']
    }
  }
];

export const INITIAL_REVIEWS: ProductReview[] = [
  {
    id: 'rev-1',
    productId: 'prod-1',
    userName: 'Kazi Shakil Ahmed',
    userEmail: 'shakil@vrdev.bd',
    rating: 5,
    title: 'অসাধারণ কোয়ালিটি এবং দারুণ হেড ট্র্যাকিং!',
    comment: 'ঢাকা ধানমন্ডি থেকে অর্ডার দিয়েছিলাম, মাত্র ২৪ ঘণ্টার মধ্যেই অক্ষত অবস্থায় ডেলিভারি পেয়েছি। ডিসপ্লে রেজোলিউশন এবং ফিনিশিং অসাধারণ!',
    createdAt: '2026-08-10T14:20:00Z',
    verifiedBuyer: true,
    likes: 14
  },
  {
    id: 'rev-2',
    productId: 'prod-1',
    userName: 'Nafis Imtiaz',
    userEmail: 'nafis@techhub.io',
    rating: 5,
    title: 'Top notch hardware performance',
    comment: 'The OLED panel clarity is unbelievable for this price point. Packaging was robust and genuine warranty card included.',
    createdAt: '2026-08-12T09:15:00Z',
    verifiedBuyer: true,
    likes: 8
  },
  {
    id: 'rev-3',
    productId: 'prod-2',
    userName: 'Sadia Sultana',
    userEmail: 'sadia@researchlab.edu',
    rating: 5,
    title: 'Fast computing & zero throttling',
    comment: 'We use this in our university robotics lab. 0.8ms latency claim is 100% accurate. Very impressed with the build.',
    createdAt: '2026-08-14T11:45:00Z',
    verifiedBuyer: true,
    likes: 11
  },
  {
    id: 'rev-4',
    productId: 'prod-3',
    userName: 'Mahmudur Rahman',
    userEmail: 'mahmud@devstudios.com',
    rating: 5,
    title: 'Everything a developer needs!',
    comment: 'Clean documentation, instant component imports, and active WhatsApp support from the team.',
    createdAt: '2026-08-16T16:00:00Z',
    verifiedBuyer: true,
    likes: 19
  }
];

export const INITIAL_ABOUT_INFO: AboutInfo = {
  companyName: 'Lewra World',
  tagline: 'Leading Hardware & Technology Solutions',
  brandOriginCountry: 'Bangladesh',
  brandOriginFlag: '🇧🇩',
  brandOriginStory: 'Proudly founded & engineered in Bangladesh, providing premium hardware solutions for global tech enthusiasts.',
  brandEstablishedYear: '2024',
  logoUrl: '',
  bkashNumber: '01700-000000 (Personal)',
  bkashLogoUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=100&auto=format&fit=crop&q=80',
  nagadNumber: '01800-000000 (Personal)',
  nagadLogoUrl: '',
  rocketNumber: '01900-000000 (Personal)',
  rocketLogoUrl: '',
  paymentInstructions: 'Send Money or Cash Out to our official bKash / Nagad / Rocket number, then enter your TrxID & Mobile Number below.',
  enableCashOnDelivery: true,
  enableCardPayment: true,
  deliveryChargeInsideDhaka: 60,
  deliveryChargeOutsideDhaka: 130,
  deliveryNote: 'Home delivery available in 1-2 days within Dhaka, and 2-4 days outside Dhaka.',
  heroTitle: 'Lewra World Tech & Hardware Ecosystem Platform',
  heroSubtitle: 'Discover cutting-edge spatial devices, premium hardware tech, and high-performance digital tools engineered for the future of interactive computing.',
  heroWorkspaceTitle: 'Lewra World Workspace',
  heroSystemStatus: 'System Active',
  heroShowcaseImage: '/src/assets/images/lewra_hero_3d_1785996301280.jpg',
  heroShowcaseAlt: 'Lewra World Products & Ecosystem',
  hideHeroShowcase: false,
  hideHeroWorkspaceTitle: false,
  hideHeroSystemStatus: false,
  flashSaleActive: false,
  flashSaleTitle: '⚡ Flash Discount Sale Live - Up to 20% OFF on All Hardware!',
  flashSaleSubtitle: 'Limited time promotional campaign. Order before timer runs out to claim instant discounts.',
  flashSaleDiscountPercent: 15,
  flashSaleValidUntil: '',
  storeBadge: 'LEWRA HARDWARE & SPATIAL PRODUCTS STORE',
  storeTitle: 'Explore Our Spatial Ecosystem Products',
  storeSubtitle: 'Order next-gen hardware HUDs, neural edge gateways, and developer kits directly with real-time tracking.',
  ownerName: 'Lewra World Founder & Team',
  ownerRole: 'Founder & Managing Director',
  bio: 'Welcome to Lewra World. We provide cutting-edge hardware products, spatial gadgets, and modern tech tools designed to empower your digital life and business growth.',
  email: 'contact@lewra.world',
  phone: '+880 1700-000000',
  supportPhoneSecondary: '+880 1800-000000',
  address: 'Dhaka, Bangladesh',
  whatsapp: '+8801700000000',
  whatsappMessage: 'Hello Lewra Support, I want to inquire about products and delivery.',
  facebook: 'https://facebook.com/lewra.world',
  facebookMessenger: 'https://m.me/lewra.world',
  facebookGroup: 'https://facebook.com/groups/lewra.community',
  instagram: 'https://instagram.com/lewra.world',
  telegram: 'https://t.me/lewra_support',
  youtube: 'https://youtube.com/@lewra_world',
  website: 'https://lewra.world',
  supportHours: '10:00 AM - 10:00 PM (Everyday)',
  supportNotice: 'যেকোনো জিজ্ঞাসা, অর্ডার হেল্প বা ওয়ারেন্টির জন্য আমাদের সরাসরি কল করুন অথবা হোয়াটসঅ্যাপ/ফেসবুক ইনবক্সে যোগাযোগ করুন।',
  showFloatingSupport: true,
  enableWhatsAppSupport: true,
  enableFacebookSupport: true,
  enableCallSupport: true,
  enableKeynote: false, // Keynote option turned OFF
  enableSpinWheel: false, // Spin & Win option turned OFF
  enableCoupons: true, // Coupon option turned ON
  maxCouponsPerUserPerMonth: 1,
  developerName: 'Lewra Tech Developers',
  developerWebsite: 'https://lewra.world/developers',
  developerPhone: '+880 1700-112233',
  platformCompany: 'Lewra Global Platform Ltd.'
};

export const INITIAL_ORDERS: Order[] = [
  {
    id: 'ORD-9821',
    customerName: 'Tanvir Hossain',
    customerEmail: 'tanvir@techmail.bd',
    customerPhone: '+880 1712-345678',
    shippingAddress: 'House 42, Road 11, Banani, Dhaka, Bangladesh',
    items: [
      {
        productId: 'prod-1',
        productName: 'Lewra Spatial Vision Glass HUD',
        quantity: 1,
        price: 35000
      }
    ],
    totalAmount: 35000,
    paymentMethod: 'bKash',
    paymentTrxId: 'BK8923179X',
    paymentSenderPhone: '01712345678',
    status: 'Processing',
    createdAt: '2026-08-05T14:32:00Z',
    notes: 'Please deliver between 10am - 4pm.'
  },
  {
    id: 'ORD-9822',
    customerName: 'Ayesha Rahman',
    customerEmail: 'ayesha.r@innovate.io',
    customerPhone: '+880 1819-876543',
    shippingAddress: 'Plot 14, Sector 7, Uttara, Dhaka',
    items: [
      {
        productId: 'prod-2',
        productName: 'Neural Processing Edge Gateway (v3)',
        quantity: 1,
        price: 65000
      },
      {
        productId: 'prod-3',
        productName: 'Lewra Tech Developer Pro Kit',
        quantity: 1,
        price: 15000
      }
    ],
    totalAmount: 80000,
    paymentMethod: 'Cash on Delivery',
    status: 'Pending',
    createdAt: '2026-08-05T18:15:00Z',
    notes: 'Urgent setup required for research lab.'
  }
];

export const INITIAL_COUPONS: Coupon[] = [
  { id: 'c-1', code: 'LEWRA10', discountPercent: 10, active: true },
  { id: 'c-2', code: 'DISCOUNT20', discountPercent: 20, active: true },
  { id: 'c-3', code: 'SPECIAL500', discountBDT: 500, active: true }
];

export const INITIAL_USERS: UserAccount[] = [
  {
    id: 'user-1',
    name: 'Tanvir Hossain',
    email: 'tanvir@techmail.bd',
    password: 'password123',
    createdAt: '2026-08-01T10:00:00Z',
    phone: '+880 1712-345678'
  },
  {
    id: 'user-2',
    name: 'Ayesha Rahman',
    email: 'ayesha.r@innovate.io',
    password: 'password123',
    createdAt: '2026-08-02T12:30:00Z',
    phone: '+880 1819-876543'
  }
];
