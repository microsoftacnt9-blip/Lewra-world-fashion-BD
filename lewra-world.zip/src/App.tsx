import React, { useState, useEffect, useRef } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Footer } from './components/Footer';
import { DemoModal } from './components/DemoModal';
import { ProductStore } from './components/ProductStore';
import { AdminPanel } from './components/AdminPanel';
import { UserProfileModal } from './components/UserProfileModal';
import { OrderReceiptModal } from './components/OrderReceiptModal';
import { CartDrawer } from './components/CartDrawer';
import { WishlistDrawer } from './components/WishlistDrawer';
import { OrderTrackingModal } from './components/OrderTrackingModal';
import { WhatsAppWidget } from './components/WhatsAppWidget';
import { FlashSaleBanner } from './components/FlashSaleBanner';
import { LuckySpinModal } from './components/LuckySpinModal';
import { Product, Order, AboutInfo, Coupon, UserAccount, CartItem, ProductReview } from './types';
import { INITIAL_PRODUCTS, INITIAL_ORDERS, INITIAL_ABOUT_INFO, INITIAL_COUPONS, INITIAL_USERS, INITIAL_REVIEWS } from './data/mockData';
import { ShoppingCart, Gift, ShoppingBag, Truck, User, Settings } from 'lucide-react';

export default function App() {
  const [modalMode, setModalMode] = useState<'keynote' | 'get-started' | null>(null);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isWishlistOpen, setIsWishlistOpen] = useState(false);
  const [isTrackingOpen, setIsTrackingOpen] = useState(false);
  const [isSpinOpen, setIsSpinOpen] = useState(false);
  const [trackingOrderId, setTrackingOrderId] = useState<string | undefined>(undefined);
  const [receiptModalOrder, setReceiptModalOrder] = useState<Order | null>(null);
  const lastLogoClickRef = useRef<number>(0);

  // Load Cart from localStorage
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('lewra_cart');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to load cart from localStorage', e);
    }
    return [];
  });

  // Load Wishlist product IDs from localStorage
  const [wishlistIds, setWishlistIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('lewra_wishlist');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          return parsed
            .map(item => (typeof item === 'string' ? item : item?.id))
            .filter((id): id is string => typeof id === 'string' && id.trim().length > 0);
        }
      }
    } catch (e) {
      console.error('Failed to load wishlist from localStorage', e);
    }
    return [];
  });

  // Load Reviews from localStorage or initial mock data
  const [reviews, setReviews] = useState<ProductReview[]>(() => {
    try {
      const saved = localStorage.getItem('lewra_reviews');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to load reviews from localStorage', e);
    }
    return INITIAL_REVIEWS;
  });

  // Load registered users from localStorage or initial mock data
  const [users, setUsers] = useState<UserAccount[]>(() => {
    try {
      const saved = localStorage.getItem('lewra_users');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to load users from localStorage', e);
    }
    return INITIAL_USERS;
  });

  // Load logged in user from localStorage
  const [currentUser, setCurrentUser] = useState<UserAccount | null>(() => {
    try {
      const saved = localStorage.getItem('lewra_current_user');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to load current user from localStorage', e);
    }
    return null;
  });

  // Load products from localStorage or initial mock data
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem('lewra_products');
      if (saved) {
        const parsed: Product[] = JSON.parse(saved);
        return parsed.map(p => {
          if (p.description && p.description.includes('Auto generated product by AI Store Assistant')) {
            return {
              ...p,
              description: `High quality ${p.name} featuring premium design, verified authenticity, official warranty, and fast home delivery across Bangladesh.`
            };
          }
          return p;
        });
      }
    } catch (e) {
      console.error('Failed to load products from localStorage', e);
    }
    return INITIAL_PRODUCTS;
  });

  // Load orders from localStorage or initial mock data
  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const saved = localStorage.getItem('lewra_orders');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to load orders from localStorage', e);
    }
    return INITIAL_ORDERS;
  });

  // Load About Info from localStorage or initial mock data
  const [aboutInfo, setAboutInfo] = useState<AboutInfo>(() => {
    try {
      const saved = localStorage.getItem('lewra_about_info');
      if (saved) {
        const parsed = JSON.parse(saved);
        return {
          ...INITIAL_ABOUT_INFO,
          ...parsed,
          enableCoupons: parsed.enableCoupons !== false, // Coupon option ON by default
          enableSpinWheel: parsed.enableSpinWheel === true, // Spin & Win OFF by default
          enableKeynote: parsed.enableKeynote === true // Keynote OFF by default
        };
      }
    } catch (e) {
      console.error('Failed to load About Info from localStorage', e);
    }
    return { ...INITIAL_ABOUT_INFO, enableCoupons: true, enableSpinWheel: false, enableKeynote: false };
  });

  // Load Coupons from localStorage
  const [coupons, setCoupons] = useState<Coupon[]>(() => {
    try {
      const saved = localStorage.getItem('lewra_coupons');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to load coupons from localStorage', e);
    }
    return INITIAL_COUPONS;
  });

  // Load deleted user emails from localStorage
  const [deletedUserEmails, setDeletedUserEmails] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('lewra_deleted_user_emails');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to load deleted user emails', e);
    }
    return [];
  });

  // Persist Cart
  useEffect(() => {
    try {
      localStorage.setItem('lewra_cart', JSON.stringify(cart));
    } catch (e) {
      console.error('Failed to save Cart', e);
    }
  }, [cart]);

  // Persist products
  useEffect(() => {
    try {
      localStorage.setItem('lewra_products', JSON.stringify(products));
    } catch (e) {
      console.error('Failed to save products', e);
    }
  }, [products]);

  // Persist orders
  useEffect(() => {
    try {
      localStorage.setItem('lewra_orders', JSON.stringify(orders));
    } catch (e) {
      console.error('Failed to save orders', e);
    }
  }, [orders]);

  // Update browser tab title dynamically
  useEffect(() => {
    if (aboutInfo?.companyName) {
      document.title = `${aboutInfo.companyName} | ${aboutInfo.tagline || 'Official Store'}`;
    }
  }, [aboutInfo]);

  // Persist About Info
  useEffect(() => {
    try {
      localStorage.setItem('lewra_about_info', JSON.stringify(aboutInfo));
    } catch (e) {
      console.error('Failed to save About Info', e);
    }
  }, [aboutInfo]);

  // Persist Coupons
  useEffect(() => {
    try {
      localStorage.setItem('lewra_coupons', JSON.stringify(coupons));
    } catch (e) {
      console.error('Failed to save Coupons', e);
    }
  }, [coupons]);

  // Persist Users
  useEffect(() => {
    try {
      localStorage.setItem('lewra_users', JSON.stringify(users));
    } catch (e) {
      console.error('Failed to save Users', e);
    }
  }, [users]);

  // Persist Current User
  useEffect(() => {
    try {
      if (currentUser) {
        localStorage.setItem('lewra_current_user', JSON.stringify(currentUser));
      } else {
        localStorage.removeItem('lewra_current_user');
      }
    } catch (e) {
      console.error('Failed to save Current User', e);
    }
  }, [currentUser]);

  // Persist Wishlist
  useEffect(() => {
    try {
      localStorage.setItem('lewra_wishlist', JSON.stringify(wishlistIds));
    } catch (e) {
      console.error('Failed to save Wishlist', e);
    }
  }, [wishlistIds]);

  // Persist Reviews
  useEffect(() => {
    try {
      localStorage.setItem('lewra_reviews', JSON.stringify(reviews));
    } catch (e) {
      console.error('Failed to save Reviews', e);
    }
  }, [reviews]);

  // Persist Deleted User Emails
  useEffect(() => {
    try {
      localStorage.setItem('lewra_deleted_user_emails', JSON.stringify(deletedUserEmails));
    } catch (e) {
      console.error('Failed to save Deleted User Emails', e);
    }
  }, [deletedUserEmails]);

  // Listen for secret admin access: Logo Click + Ctrl+A sequence, or URL route (?admin=true or #admin)
  useEffect(() => {
    const checkAdminUrl = () => {
      const search = window.location.search.toLowerCase();
      const hash = window.location.hash.toLowerCase();
      if (hash === '#admin' || search.includes('admin=') || search.includes('secret=admin')) {
        setIsAdminOpen(true);
      }
    };
    checkAdminUrl();
    window.addEventListener('hashchange', checkAdminUrl);

    const handleLogoClickedEvent = () => {
      lastLogoClickRef.current = Date.now();
    };
    window.addEventListener('lewra-logo-clicked', handleLogoClickedEvent);

    // Secret Key Sequence Handler
    const handleKeyDown = (e: KeyboardEvent) => {
      const isAKey = e.key === 'a' || e.key === 'A' || e.code === 'KeyA';
      const isCtrlOrCmd = e.ctrlKey || e.metaKey;

      // 1. Primary Secret: User clicks logo once -> then presses Ctrl + A (or Cmd + A) within 20 seconds
      const isLogoRecentlyClicked = Date.now() - lastLogoClickRef.current < 20000;
      if (isCtrlOrCmd && isAKey && !e.shiftKey && !e.altKey && isLogoRecentlyClicked) {
        e.preventDefault();
        lastLogoClickRef.current = 0;
        setIsAdminOpen(true);
        return;
      }

      // 2. Direct Keyboard Shortcut backup: Ctrl + Shift + A or Alt + A
      if ((e.ctrlKey && e.shiftKey && isAKey) || (e.altKey && isAKey)) {
        e.preventDefault();
        setIsAdminOpen(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);

    return () => {
      window.removeEventListener('hashchange', checkAdminUrl);
      window.removeEventListener('lewra-logo-clicked', handleLogoClickedEvent);
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, []);

  const handleRegisterUser = (newUser: UserAccount) => {
    setUsers(prev => [newUser, ...prev]);
    setDeletedUserEmails(prev => prev.filter(e => e.toLowerCase() !== newUser.email.toLowerCase()));
  };

  const handleUpdateUser = (updatedUser: UserAccount) => {
    setUsers(prev => prev.map(u => u.id === updatedUser.id ? updatedUser : u));
    if (currentUser && currentUser.id === updatedUser.id) {
      setCurrentUser(updatedUser);
    }
  };

  const handleLoginUser = (user: UserAccount) => {
    setCurrentUser(user);
  };

  const handleLogoutUser = () => {
    setCurrentUser(null);
  };

  const handleResetUserPassword = (email: string, newPass: string) => {
    let success = false;
    setUsers(prev => prev.map(u => {
      if (u.email.toLowerCase() === email.toLowerCase()) {
        success = true;
        return { ...u, password: newPass };
      }
      return u;
    }));

    if (currentUser && currentUser.email.toLowerCase() === email.toLowerCase()) {
      setCurrentUser(prev => prev ? { ...prev, password: newPass } : null);
    }

    return success;
  };

  const handleDeleteUser = (userId: string) => {
    const targetUser = users.find(u => u.id === userId);
    if (targetUser) {
      setDeletedUserEmails(prev => [...new Set([...prev, targetUser.email.toLowerCase()])]);
    }
    setUsers(prev => prev.filter(u => u.id !== userId));
    if (currentUser && currentUser.id === userId) {
      setCurrentUser(null);
    }
  };

  const handleAddProduct = (newProduct: Product) => {
    setProducts(prev => [newProduct, ...prev]);
  };

  const handleDeleteProduct = (productId: string) => {
    setProducts(prev => prev.filter(p => p.id !== productId));
  };

  const handlePlaceOrder = (newOrder: Order) => {
    setOrders(prev => [newOrder, ...prev]);
    
    // Automatically reduce product stock when an order is placed
    setProducts(prevProducts => {
      return prevProducts.map(product => {
        const item = newOrder.items.find(i => i.productId === product.id);
        if (item) {
          const newStock = Math.max(0, product.stock - item.quantity);
          return { ...product, stock: newStock };
        }
        return product;
      });
    });

    // Award loyalty reward points to the customer account (5% of order value)
    const earnedPoints = Math.max(10, Math.floor(newOrder.totalAmount * 0.05));
    const customerEmail = newOrder.customerEmail?.toLowerCase();

    setUsers(prevUsers => {
      return prevUsers.map(user => {
        // Credit the buyer
        if (customerEmail && user.email.toLowerCase() === customerEmail) {
          return {
            ...user,
            rewardPoints: (user.rewardPoints || 0) + earnedPoints
          };
        }
        // Credit the referrer bonus (+100 points) if referral code matches
        if (newOrder.referredBy && user.referralCode && user.referralCode.toUpperCase() === newOrder.referredBy.toUpperCase()) {
          return {
            ...user,
            rewardPoints: (user.rewardPoints || 0) + 100
          };
        }
        return user;
      });
    });

    if (currentUser && customerEmail && currentUser.email.toLowerCase() === customerEmail) {
      setCurrentUser(prev => prev ? {
        ...prev,
        rewardPoints: (prev.rewardPoints || 0) + earnedPoints
      } : null);
    }
  };

  const handleUpdateProduct = (updatedProduct: Product) => {
    setProducts(prev => prev.map(p => p.id === updatedProduct.id ? updatedProduct : p));
  };

  const handleUpdateOrder = (updatedOrder: Order) => {
    const targetOrder = orders.find(o => o.id === updatedOrder.id);
    
    // Return stock if order becomes Cancelled
    if (targetOrder && targetOrder.status !== 'Cancelled' && updatedOrder.status === 'Cancelled') {
      setProducts(prevProducts => prevProducts.map(product => {
        const item = updatedOrder.items.find(i => i.productId === product.id);
        if (item) {
          return { ...product, stock: product.stock + item.quantity };
        }
        return product;
      }));
    }

    // If customer confirms delivery receipt, award +50 bonus delivery confirmation points
    if (targetOrder && !targetOrder.customerReceived && updatedOrder.customerReceived) {
      const customerEmail = updatedOrder.customerEmail?.toLowerCase();
      if (customerEmail) {
        setUsers(prevUsers => prevUsers.map(u => {
          if (u.email.toLowerCase() === customerEmail) {
            return { ...u, rewardPoints: (u.rewardPoints || 0) + 50 };
          }
          return u;
        }));
        if (currentUser && currentUser.email.toLowerCase() === customerEmail) {
          setCurrentUser(prev => prev ? { ...prev, rewardPoints: (prev.rewardPoints || 0) + 50 } : null);
        }
      }
    }

    setOrders(prev => prev.map(o => o.id === updatedOrder.id ? updatedOrder : o));
    // Also keep receiptModalOrder up to date if currently open
    if (receiptModalOrder && receiptModalOrder.id === updatedOrder.id) {
      setReceiptModalOrder(updatedOrder);
    }
  };

  const handleUpdateOrderStatus = (
    orderId: string,
    status: Order['status'],
    confirmedAt?: string,
    estimatedDeliveryTime?: string
  ) => {
    const targetOrder = orders.find(o => o.id === orderId);
    if (!targetOrder) return;

    const oldStatus = targetOrder.status;

    // Update order status
    setOrders(prev => prev.map(o => {
      if (o.id === orderId) {
        return {
          ...o,
          status,
          ...(status === 'Cancelled' ? { cancelledBy: 'Admin', refundStatus: o.refundStatus || 'Pending Customer Action' } : {}),
          ...(confirmedAt ? { confirmedAt } : {}),
          ...(estimatedDeliveryTime ? { estimatedDeliveryTime } : {})
        };
      }
      return o;
    }));

    if (receiptModalOrder && receiptModalOrder.id === orderId) {
      setReceiptModalOrder(prev => prev ? {
        ...prev,
        status,
        ...(status === 'Cancelled' ? { cancelledBy: 'Admin', refundStatus: prev.refundStatus || 'Pending Customer Action' } : {}),
        ...(confirmedAt ? { confirmedAt } : {}),
        ...(estimatedDeliveryTime ? { estimatedDeliveryTime } : {})
      } : null);
    }

    // If order status changes to Cancelled, return stock
    if (oldStatus !== 'Cancelled' && status === 'Cancelled') {
      setProducts(prevProducts => prevProducts.map(product => {
        const item = targetOrder.items.find(i => i.productId === product.id);
        if (item) {
          return { ...product, stock: product.stock + item.quantity };
        }
        return product;
      }));
    }
    // If order was Cancelled and is now un-cancelled, deduct stock again
    else if (oldStatus === 'Cancelled' && status !== 'Cancelled') {
      setProducts(prevProducts => prevProducts.map(product => {
        const item = targetOrder.items.find(i => i.productId === product.id);
        if (item) {
          return { ...product, stock: Math.max(0, product.stock - item.quantity) };
        }
        return product;
      }));
    }
  };

  const handleDeleteOrder = (orderId: string) => {
    const targetOrder = orders.find(o => o.id === orderId);
    if (!targetOrder) return;

    // Return stock if active order is deleted (was not cancelled yet)
    if (targetOrder.status !== 'Cancelled') {
      setProducts(prevProducts => prevProducts.map(product => {
        const item = targetOrder.items.find(i => i.productId === product.id);
        if (item) {
          return { ...product, stock: product.stock + item.quantity };
        }
        return product;
      }));
    }

    // Permanently remove the order from orders list
    setOrders(prev => prev.filter(o => o.id !== orderId));

    if (receiptModalOrder && receiptModalOrder.id === orderId) {
      setReceiptModalOrder(null);
    }
  };

  const handleAddToCart = (product: Product, quantity = 1) => {
    setCart(prev => {
      const existing = prev.find(item => item.product.id === product.id);
      if (existing) {
        return prev.map(item =>
          item.product.id === product.id
            ? { ...item, quantity: Math.min(product.stock, item.quantity + quantity) }
            : item
        );
      }
      return [...prev, { product, quantity: Math.min(product.stock, quantity) }];
    });
  };

  const handleUpdateCartQuantity = (productId: string, newQuantity: number) => {
    if (newQuantity <= 0) {
      handleRemoveFromCart(productId);
      return;
    }
    setCart(prev =>
      prev.map(item =>
        item.product.id === productId
          ? { ...item, quantity: Math.min(item.product.stock, newQuantity) }
          : item
      )
    );
  };

  const handleRemoveFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.product.id !== productId));
  };

  const handleClearCart = () => {
    setCart([]);
  };

  const handleToggleWishlist = (target: string | Product) => {
    const id = typeof target === 'string' ? target : target?.id;
    if (!id) return;
    setWishlistIds(prev => {
      const cleanPrev = prev
        .map(item => (typeof item === 'string' ? item : (item as any)?.id))
        .filter((i): i is string => typeof i === 'string' && i.trim().length > 0);
      return cleanPrev.includes(id) ? cleanPrev.filter(item => item !== id) : [...cleanPrev, id];
    });
  };

  const handleClearWishlist = () => {
    setWishlistIds([]);
  };

  const handleAddReview = (newReview: ProductReview) => {
    setReviews(prev => [newReview, ...prev]);
  };

  const isAdminUser = Boolean(
    currentUser?.email && (
      currentUser.email.toLowerCase().trim() === 'microsoftacnt9@gmail.com' ||
      currentUser.email.toLowerCase().trim().startsWith('microsoftacnt9@') ||
      currentUser.email.toLowerCase().trim() === 'admin@gmail.com'
    )
  );

  const totalCartCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const validWishlistIds = wishlistIds.filter(id => typeof id === 'string' && products.some(p => p.id === id));

  return (
    <div className="min-h-screen pb-20 md:pb-0 bg-[#0B0705] text-[#F5EBE0] font-['Plus_Jakarta_Sans',sans-serif] relative overflow-x-hidden selection:bg-[#D4A373]/30 selection:text-[#FFF1E6]">
      
      {/* Top Navbar */}
      <Navbar
        aboutInfo={aboutInfo}
        currentUser={currentUser}
        onOpenGetStarted={() => setModalMode('get-started')}
        onOpenKeynote={() => setModalMode('keynote')}
        onOpenAdmin={() => setIsAdminOpen(true)}
        onOpenProfile={() => setIsProfileOpen(true)}
        ordersCount={orders.length}
        cartItemsCount={totalCartCount}
        onOpenCart={() => setIsCartOpen(true)}
        wishlistCount={validWishlistIds.length}
        onOpenWishlist={() => setIsWishlistOpen(true)}
        onOpenLuckySpin={() => setIsSpinOpen(true)}
        onOpenTracking={() => {
          setTrackingOrderId(undefined);
          setIsTrackingOpen(true);
        }}
        onLogoClick={() => {
          lastLogoClickRef.current = Date.now();
        }}
      />

      {/* Main Content */}
      <main>
        <Hero
          aboutInfo={aboutInfo}
          onOpenGetStarted={() => setModalMode('get-started')}
          onOpenKeynote={() => setModalMode('keynote')}
        />

        {/* Promotional Flash Sale / Discount Campaign Banner */}
        <FlashSaleBanner aboutInfo={aboutInfo} />

        {/* Product Store Section */}
        <ProductStore
          products={products}
          coupons={coupons}
          aboutInfo={aboutInfo}
          currentUser={currentUser}
          orders={orders}
          onPlaceOrder={handlePlaceOrder}
          onOpenAdmin={() => setIsAdminOpen(true)}
          onAddToCart={handleAddToCart}
          onOpenCart={() => setIsCartOpen(true)}
          cartItemsCount={totalCartCount}
          wishlistIds={validWishlistIds}
          onToggleWishlist={handleToggleWishlist}
          onOpenWishlist={() => setIsWishlistOpen(true)}
          onOpenTracking={(orderId) => {
            setTrackingOrderId(orderId);
            setIsTrackingOpen(true);
          }}
          reviews={reviews}
          onAddReview={handleAddReview}
        />
      </main>

      {/* Footer */}
      <Footer aboutInfo={aboutInfo} onOpenAdmin={() => setIsAdminOpen(true)} />

      {/* Shopping Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cart={cart}
        coupons={coupons}
        aboutInfo={aboutInfo}
        currentUser={currentUser}
        orders={orders}
        onUpdateQuantity={handleUpdateCartQuantity}
        onRemoveItem={handleRemoveFromCart}
        onClearCart={handleClearCart}
        onPlaceOrder={(order) => {
          handlePlaceOrder(order);
        }}
        onOrderSuccess={(order) => {
          setReceiptModalOrder(order);
        }}
      />

      {/* Saved Wishlist Drawer */}
      <WishlistDrawer
        isOpen={isWishlistOpen}
        onClose={() => setIsWishlistOpen(false)}
        wishlistIds={validWishlistIds}
        products={products}
        onToggleWishlist={handleToggleWishlist}
        onClearWishlist={handleClearWishlist}
        onAddToCart={(prod) => {
          handleAddToCart(prod, 1);
        }}
      />

      {/* Live Order Tracking Modal */}
      <OrderTrackingModal
        isOpen={isTrackingOpen}
        onClose={() => setIsTrackingOpen(false)}
        orders={orders}
        aboutInfo={aboutInfo}
        initialOrderId={trackingOrderId}
        onViewInvoice={(ord) => {
          setReceiptModalOrder(ord);
        }}
      />

      {/* Floating 24/7 WhatsApp & Live Support Widget */}
      <WhatsAppWidget aboutInfo={aboutInfo} />

      {/* Admin Panel Modal */}
      <AdminPanel
        isOpen={isAdminOpen}
        onClose={() => setIsAdminOpen(false)}
        currentUser={currentUser}
        onOpenProfile={() => setIsProfileOpen(true)}
        products={products}
        orders={orders}
        users={users}
        aboutInfo={aboutInfo}
        coupons={coupons}
        onAddProduct={handleAddProduct}
        onUpdateProduct={handleUpdateProduct}
        onDeleteProduct={handleDeleteProduct}
        onUpdateOrderStatus={handleUpdateOrderStatus}
        onDeleteOrder={handleDeleteOrder}
        onUpdateOrder={handleUpdateOrder}
        onUpdateAboutInfo={setAboutInfo}
        onUpdateCoupons={setCoupons}
        onDeleteUser={handleDeleteUser}
      />

      {/* Customer User Profile Modal */}
      <UserProfileModal
        isOpen={isProfileOpen}
        onClose={() => setIsProfileOpen(false)}
        currentUser={currentUser}
        users={users}
        orders={orders}
        deletedUserEmails={deletedUserEmails}
        onLogin={handleLoginUser}
        onLogout={handleLogoutUser}
        onRegister={handleRegisterUser}
        onUpdateUser={handleUpdateUser}
        onResetPassword={handleResetUserPassword}
        onViewReceipt={(order) => setReceiptModalOrder(order)}
        onUpdateOrder={handleUpdateOrder}
        onOpenTracking={(orderId) => {
          setIsProfileOpen(false);
          setTrackingOrderId(orderId);
          setIsTrackingOpen(true);
        }}
      />

      {/* Order Receipt Modal triggered from User Profile */}
      <OrderReceiptModal
        order={receiptModalOrder}
        aboutInfo={aboutInfo}
        onClose={() => setReceiptModalOrder(null)}
        onUpdateOrder={handleUpdateOrder}
      />

      {/* Floating Lucky Spin Wheel Trigger Button */}
      {Boolean(aboutInfo?.enableSpinWheel) && (
        <button
          type="button"
          onClick={() => setIsSpinOpen(true)}
          className="fixed bottom-5 left-5 z-40 px-3.5 py-2.5 rounded-2xl bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 text-slate-950 font-extrabold text-xs flex items-center gap-2 shadow-2xl shadow-amber-500/40 hover:scale-105 active:scale-95 transition-all border border-amber-300/40 animate-bounce"
          title="Spin the Wheel to Win Discount Coupons (লাকি স্পিন হুইল)"
        >
          <Gift className="w-4 h-4 text-slate-950 animate-spin-slow" />
          <span className="font-['Space_Grotesk'] tracking-wide">Spin & Win (ডিসকাউন্ট জিতুন)</span>
        </button>
      )}

      {/* Lucky Spin to Win Discount Modal */}
      <LuckySpinModal
        isOpen={isSpinOpen}
        onClose={() => setIsSpinOpen(false)}
        onApplyCoupon={(couponCode) => {
          // If the coupon does not exist in coupons list, add it automatically
          setCoupons(prev => {
            if (!prev.some(c => c.code.toUpperCase() === couponCode.toUpperCase())) {
              return [
                {
                  id: `spin-${Date.now()}`,
                  code: couponCode.toUpperCase(),
                  active: true,
                  discountPercent: 10,
                  note: 'Lucky Spin Winner Coupon'
                },
                ...prev
              ];
            }
            return prev;
          });
          setIsSpinOpen(false);
          setIsCartOpen(true);
        }}
      />

      {/* Demo / Get Started Modal */}
      <DemoModal
        mode={modalMode}
        onClose={() => setModalMode(null)}
      />

      {/* Mobile Bottom Quick Navigation & Admin Control Bar */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#070A12]/95 backdrop-blur-xl border-t border-slate-800/90 px-3 py-1.5 flex items-center justify-around shadow-2xl safe-area-bottom">
        <a
          href="#store"
          className="flex flex-col items-center justify-center py-1 px-1.5 text-slate-400 hover:text-cyan-400 active:scale-90 transition-all text-center min-w-[50px]"
        >
          <ShoppingBag className="w-5 h-5 mb-0.5 text-cyan-400" />
          <span className="text-[10px] font-medium font-['Space_Grotesk']">স্টোর</span>
        </a>

        <button
          type="button"
          onClick={() => {
            setTrackingOrderId(undefined);
            setIsTrackingOpen(true);
          }}
          className="flex flex-col items-center justify-center py-1 px-1.5 text-slate-400 hover:text-cyan-400 active:scale-90 transition-all text-center min-w-[50px]"
        >
          <Truck className="w-5 h-5 mb-0.5 text-cyan-400" />
          <span className="text-[10px] font-medium font-['Space_Grotesk']">ট্র্যাকিং</span>
        </button>

        <button
          type="button"
          onClick={() => setIsCartOpen(true)}
          className="flex flex-col items-center justify-center py-1 px-1.5 text-slate-400 hover:text-white active:scale-90 transition-all text-center relative min-w-[50px]"
        >
          <div className="relative">
            <ShoppingCart className="w-5 h-5 mb-0.5 text-white" />
            {totalCartCount > 0 && (
              <span className="absolute -top-1.5 -right-2 px-1.5 py-0.2 rounded-full bg-white text-black font-mono text-[9px] font-black animate-pulse">
                {totalCartCount}
              </span>
            )}
          </div>
          <span className="text-[10px] font-medium font-['Space_Grotesk'] text-white">কার্ট</span>
        </button>

        <button
          type="button"
          onClick={() => setIsProfileOpen(true)}
          className="flex flex-col items-center justify-center py-1 px-1.5 text-slate-400 hover:text-emerald-400 active:scale-90 transition-all text-center min-w-[50px]"
        >
          <User className="w-5 h-5 mb-0.5 text-emerald-400" />
          <span className="text-[10px] font-medium font-['Space_Grotesk']">প্রোফাইল</span>
        </button>

        {isAdminUser && !aboutInfo?.hideAdminButton && (
          <button
            type="button"
            onClick={() => setIsAdminOpen(true)}
            className="flex flex-col items-center justify-center py-1 px-2.5 text-purple-300 hover:text-purple-200 active:scale-90 transition-all text-center relative min-w-[54px] rounded-xl bg-purple-950/60 border border-purple-500/40 shadow-lg shadow-purple-950/50"
            title="Open Mobile Admin Panel (এডমিন প্যানেল)"
          >
            <div className="relative">
              <Settings className="w-5 h-5 mb-0.5 text-purple-400" />
              {orders.length > 0 && (
                <span className="absolute -top-1.5 -right-2.5 px-1.5 py-0.2 rounded-full bg-purple-500 text-white font-mono text-[9px] font-black animate-pulse">
                  {orders.length}
                </span>
              )}
            </div>
            <span className="text-[10px] font-bold font-['Space_Grotesk'] text-purple-300">এডমিন</span>
          </button>
        )}
      </div>

    </div>
  );
}


